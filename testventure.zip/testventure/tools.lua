

--
--darkwood set
--

minetest.register_tool("testventure:pick_darkwood", {
			description = "".. core.colorize("#00eaff", "darkwood pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 4\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.7\n")..core.colorize("#FFFFFF", "Range: 4.1\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV2):[1]=4.75, [2]=2.0, [3]=1.0\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV2): [1]=2.0, [2]=1.10, [3]=0.50"),
	inventory_image = "testventure_darkwood_pick.png",
	range = 4.1,
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=4.75, [2]=2.0, [3]=1.0}, uses=15, maxlevel=2},
			crumbly = {times={[1]=2.0, [2]=1.10, [3]=0.50}, uses=15, maxlevel=2},
		},
		damage_groups = {fleshy=4},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:sword_darkwood", {
			description = "".. core.colorize("#00eaff", "darkwood sword\n")..core.colorize("#FFFFFF", "Melee damage: 5\n")..core.colorize("#FFFFFF", "Knockback: 6\n")..core.colorize("#FFFFFF", "Full punch interval: 0.60\n")..core.colorize("#FFFFFF", "Range: 4.15\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV2): [1]=3.0, [2]=1.5, [3]=0.4"),
	inventory_image = "testventure_darkwood_sword.png",
	range = 4.15,
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=3.0, [2]=1.5, [3]=0.4}, uses=20, maxlevel=2},
		},
		damage_groups = {fleshy=5, knockback=6},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:axe_darkwood", {
			description = "".. core.colorize("#00eaff", "darkwood axe\n")..core.colorize("#FFFFFF", "Melee damage: 4\n")..core.colorize("#FFFFFF", "Knockback: 9\n")..core.colorize("#FFFFFF", "Full punch interval: 0.70\n")..core.colorize("#FFFFFF", "Range: 4.1\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV2): [1]=3.0, [2]=1.60, [3]=1.20"),
	inventory_image = "testventure_darkwood_axe.png",
	range = 4.1,
	tool_capabilities = {
		full_punch_interval = 0.70,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=3.0, [2]=1.60, [3]=1.20}, uses=15, maxlevel=2},
		},
		damage_groups = {fleshy=4,knockback=9},
	},
	sound = {breaks = "default_tool_breaks"},
})

--
--skywood set
--

minetest.register_tool("testventure:pick_skywood", {
			description = "".. core.colorize("#00eaff", "skywood pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 6\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.7\n")..core.colorize("#FFFFFF", "Range: 4.20\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV3):[1]=4.50, [2]=1.9, [3]=1.0\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV3): [1]=2.1, [2]=1.25, [3]=0.5"),
	inventory_image = "testventure_skywood_pick.png",
	range = 4.2,
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=4.50, [2]=1.9, [3]=1.0}, uses=25, maxlevel=3},
			crumbly = {times={[1]=2.1, [2]=1.25, [3]=0.5}, uses=25, maxlevel=3},
		},
		damage_groups = {fleshy=6},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:sword_skywood", {
			description = "".. core.colorize("#00eaff", "skywood sword\n")..core.colorize("#FFFFFF", "Melee damage: 7\n")..core.colorize("#FFFFFF", "Knockback: 6\n")..core.colorize("#FFFFFF", "Full punch interval: 0.60\n")..core.colorize("#FFFFFF", "Range: 4.25\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=2.0, [2]=1.0, [3]=0.3"),
	inventory_image = "testventure_skywood_sword.png",
	range = 4.25,
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=2.0, [2]=1.0, [3]=0.3}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=7, knockback=6},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:axe_skywood", {
			description = "".. core.colorize("#00eaff", "skywood axe\n")..core.colorize("#FFFFFF", "Melee damage: 6\n")..core.colorize("#FFFFFF", "Knockback: 9\n")..core.colorize("#FFFFFF", "Full punch interval: 0.70\n")..core.colorize("#FFFFFF", "Range: 4.2\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV3): [1]=2.5, [2]=1.80, [3]=1.20"),
	inventory_image = "testventure_skywood_axe.png",
	range = 4.2,
	tool_capabilities = {
		full_punch_interval = 0.70,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=2.5, [2]=1.80, [3]=1.20}, uses=25, maxlevel=2},
		},
		damage_groups = {fleshy=6,knockback=9},
	},
	sound = {breaks = "default_tool_breaks"},
})


--
--skystone set
--

minetest.register_tool("testventure:pick_skystone", {
			description = "".. core.colorize("#00eaff", "skystone pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 8\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.9\n")..core.colorize("#FFFFFF", "Range: 4.20\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV3):[1]=4.10, [2]=1.65, [3]=0.8\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV3): [1]=1.7, [2]=1.0, [3]=0.420"),
	inventory_image = "testventure_skystone_pick.png",
	range = 4.2,
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=4.10, [2]=1.65, [3]=0.8}, uses=35, maxlevel=3},
			crumbly = {times={[1]=1.7, [2]=1.0, [3]=0.420}, uses=35, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:sword_skystone", {
			description = "".. core.colorize("#00eaff", "skystone sword\n")..core.colorize("#FFFFFF", "Melee damage: 9\n")..core.colorize("#FFFFFF", "Knockback: 9\n")..core.colorize("#FFFFFF", "Full punch interval: 0.80\n")..core.colorize("#FFFFFF", "Range: 4.25\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.75, [2]=0.85, [3]=0.26"),
	inventory_image = "testventure_skystone_sword.png",
	range = 4.25,
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.75, [2]=0.85, [3]=0.26}, uses=40, maxlevel=3},
		},
		damage_groups = {fleshy=9, knockback=9},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:axe_skystone", {
			description = "".. core.colorize("#00eaff", "skystone axe\n")..core.colorize("#FFFFFF", "Melee damage: 8\n")..core.colorize("#FFFFFF", "Knockback: 12\n")..core.colorize("#FFFFFF", "Full punch interval: 0.90\n")..core.colorize("#FFFFFF", "Range: 4.2\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV3): [1]=2.0, [2]=1.50, [3]=1.05"),
	inventory_image = "testventure_skystone_axe.png",
	range = 4.2,
	tool_capabilities = {
		full_punch_interval = 0.90,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=2.0, [2]=1.50, [3]=1.05}, uses=35, maxlevel=2},
		},
		damage_groups = {fleshy=8,knockback=12},
	},
	sound = {breaks = "default_tool_breaks"},
})


--
--cloudantite set
--

minetest.register_tool("testventure:pick_cloudantite", {
			description = "".. core.colorize("#00eaff", "cloudantite pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 12\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.6\n")..core.colorize("#FFFFFF", "Range: 4.4\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV3):[4]=3.33, [1]=2.50, [2]=1.0, [3]=0.5\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV3): [1]=1.0, [2]=0.6, [3]=0.360"),
	inventory_image = "testventure_cloudantite_pick.png",
	range = 4.4,
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[4]=3.33, [1]=2.50, [2]=1.0, [3]=0.5}, uses=35, maxlevel=3},
			crumbly = {times={[1]=1.0, [2]=0.6, [3]=0.360}, uses=60, maxlevel=3},
		},
		damage_groups = {fleshy=12},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:sword_cloudantite", {
			description = "".. core.colorize("#00eaff", "cloudantite sword\n")..core.colorize("#FFFFFF", "Melee damage: 14\n")..core.colorize("#FFFFFF", "Knockback: 9\n")..core.colorize("#FFFFFF", "Full punch interval: 0.5\n")..core.colorize("#FFFFFF", "Range: 4.4\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.0, [2]=0.50, [3]=0.20"),
	inventory_image = "testventure_cloudantite_sword.png",
	range = 4.4,
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.0, [2]=0.50, [3]=0.20}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=14, knockback=9},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:axe_cloudantite", {
			description = "".. core.colorize("#00eaff", "cloudantite axe\n")..core.colorize("#FFFFFF", "Melee damage: 13\n")..core.colorize("#FFFFFF", "Knockback: 12\n")..core.colorize("#FFFFFF", "Full punch interval: 0.6\n")..core.colorize("#FFFFFF", "Range: 4.4\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV3): [1]=1.35, [2]=1.1, [3]=0.75"),
	inventory_image = "testventure_cloudantite_axe.png",
	range = 4.4,
	tool_capabilities = {
		full_punch_interval = 0.60,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=1.35, [2]=1.1, [3]=0.75}, uses=60, maxlevel=2},
		},
		damage_groups = {fleshy=13,knockback=12},
	},
	sound = {breaks = "default_tool_breaks"},
})

--
--aqua set
--

minetest.register_tool("testventure:pick_aqua", {
			description = "".. core.colorize("#00eaff", "Aqua pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 6\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.85\n")..core.colorize("#FFFFFF", "Range: 4.25\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV3):[4]=4.00, [1]=1.70, [2]=0.85, [3]=0.425\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV3): [1]=0.95, [2]=0.40, [3]=0.26\n")..core.colorize("#FFFFFF", "Reduces suffocation while wielded."),
	inventory_image = "testventure_aqua_pick.png",
	range = 4.25,
	tool_capabilities = {
		full_punch_interval = 0.85,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[4]=4.0, [1]=1.7, [2]=0.85, [3]=0.425}, uses=45, maxlevel=3},
			crumbly = {times={[1]=0.95, [2]=0.40, [3]=0.26}, uses=45, maxlevel=3},
		},
		damage_groups = {fleshy=6},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:sword_aqua", {
			description = "".. core.colorize("#00eaff", "Aqua sword\n")..core.colorize("#FFFFFF", "Melee damage: 9\n")..core.colorize("#FFFFFF", "Knockback: 6\n")..core.colorize("#FFFFFF", "Full punch interval: 0.65\n")..core.colorize("#FFFFFF", "Range: 4.25\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.60, [2]=0.75, [3]=0.25\n")..core.colorize("#FFFFFF", "Reduces suffocation while wielded."),
	inventory_image = "testventure_aqua_sword.png",
	range = 4.25,
	tool_capabilities = {
		full_punch_interval = 0.65,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.60, [2]=0.75, [3]=0.25}, uses=55, maxlevel=3},
		},
		damage_groups = {fleshy=9,knockback=6},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:axe_aqua", {
			description = "".. core.colorize("#00eaff", "Aqua axe\n")..core.colorize("#FFFFFF", "Melee damage: 10\n")..core.colorize("#FFFFFF", "Critical chance: 4%\n")..core.colorize("#FFFFFF", "Knockback: 10\n")..core.colorize("#FFFFFF", "Full punch interval: 0.75\n")..core.colorize("#FFFFFF", "Range: 4.25\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV3): [1]=1.80, [2]=0.70, [3]=0.40\n")..core.colorize("#FFFFFF", "Reduces suffocation while wielded."),
	inventory_image = "testventure_aqua_axe.png",
	range = 4.25,
	tool_capabilities = {
		full_punch_interval = 0.75,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=1.80, [2]=0.70, [3]=0.40}, uses=45, maxlevel=3},
		},
		damage_groups = {fleshy=10,knockback=10,critical=4},
	},
	sound = {breaks = "default_tool_breaks"},
})

--
--smaranium set
--

minetest.register_tool("testventure:pick_smaranium", {
			description = "".. core.colorize("#00eaff", "smaranium pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 7\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.825\n")..core.colorize("#FFFFFF", "Range: 4.3\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV3):[4]=3.75, [1]=1.58, [2]=0.77, [3]=0.38\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV3): [1]=0.83, [2]=0.34, [3]=0.22"),
	inventory_image = "testventure_smaranium_pick.png",
	range = 4.3,
	tool_capabilities = {
		full_punch_interval = 0.825,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[4]=3.75, [1]=1.58, [2]=0.77, [3]=0.38}, uses=49, maxlevel=3},
			crumbly = {times={[1]=0.83, [2]=0.34, [3]=0.22}, uses=49, maxlevel=3},
		},
		damage_groups = {fleshy=7},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:sword_smaranium", {
			description = "".. core.colorize("#00eaff", "smaranium sword\n")..core.colorize("#FFFFFF", "Melee damage: 10\n")..core.colorize("#FFFFFF", "Critical chance: 4%\n")..core.colorize("#FFFFFF", "Knockback: 6\n")..core.colorize("#FFFFFF", "Full punch interval: 0.625\n")..core.colorize("#FFFFFF", "Range: 4.3\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.48, [2]=0.69, [3]=0.21"),
	inventory_image = "testventure_smaranium_sword.png",
	range = 4.3,
	tool_capabilities = {
		full_punch_interval = 0.625,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.48, [2]=0.69, [3]=0.21}, uses=59, maxlevel=3},
		},
		damage_groups = {fleshy=10,knockback=6,critical=4},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:axe_smaranium", {
			description = "".. core.colorize("#00eaff", "smaranium axe\n")..core.colorize("#FFFFFF", "Melee damage: 11\n") ..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Knockback: 10\n")..core.colorize("#FFFFFF", "Full punch interval: 0.725\n")..core.colorize("#FFFFFF", "Range: 4.3\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV3): [1]=1.68, [2]=0.62, [3]=0.36"),
	inventory_image = "testventure_smaranium_axe.png",
	range = 4.3,
	tool_capabilities = {
		full_punch_interval = 0.725,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=1.68, [2]=0.62, [3]=0.36}, uses=49, maxlevel=3},
		},
		damage_groups = {fleshy=11,knockback=10,critical=5},
	},
	sound = {breaks = "default_tool_breaks"},
})


--
--shadow set
--

minetest.register_tool("testventure:pick_shadow", {
			description = "".. core.colorize("#00eaff", "shadow pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 8\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.8\n")..core.colorize("#FFFFFF", "Range: 4.35\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV3):[5]=6.00, [4]=3.25, [1]=1.45, [2]=0.7, [3]=0.38\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV3): [1]=0.8, [2]=0.35, [3]=0.20"),
	inventory_image = "testventure_shadow_pick.png",
	range = 4.35,
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[5]=6.0, [4]=3.25, [1]=1.45, [2]=0.7, [3]=0.38}, uses=60, maxlevel=3},
			crumbly = {times={[1]=0.8, [2]=0.35, [3]=0.20}, uses=60, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:sword_shadow", {
			description = "".. core.colorize("#00eaff", "shadow sword\n")..core.colorize("#FFFFFF", "Melee damage: 14\n")..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Knockback: 8\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.75\n")..core.colorize("#FFFFFF", "Range: 4.10\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.40, [2]=0.6, [3]=0.20"),
	inventory_image = "testventure_shadow_sword.png",
	range = 4.10,
	tool_capabilities = {
		full_punch_interval = 0.75,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.40, [2]=0.6, [3]=0.20}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=14, knockback=8,critical=5},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:axe_shadow", {
			description = "".. core.colorize("#00eaff", "shadow axe\n")..core.colorize("#FFFFFF", "Melee damage: 19\n")..core.colorize("#FFFFFF", "Critical chance: 8%\n")..core.colorize("#FFFFFF", "Knockback: 12\n")..core.colorize("#FFFFFF", "Full punch interval: 1.1\n")..core.colorize("#FFFFFF", "Range: 4.0\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV3): [1]=1.60, [2]=0.60, [3]=0.35"),
	inventory_image = "testventure_shadow_axe.png",
	range = 4.0,
	tool_capabilities = {
		full_punch_interval = 1.1,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=1.60, [2]=0.60, [3]=0.35}, uses=60, maxlevel=3},
		},
		damage_groups = {fleshy=19,knockback=12,critical=8},
	},
	sound = {breaks = "default_tool_breaks"},
})

--
--crimson set
--

minetest.register_tool("testventure:pick_crimson", {
			description = "".. core.colorize("#00eaff", "crimson pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 8\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.7\n")..core.colorize("#FFFFFF", "Range: 4.4\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV3):[5]=5.5, [4]=3.0, [1]=1.3, [2]=0.6, [3]=0.32\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV3): [1]=0.7, [2]=0.29, [3]=0.16"),
	inventory_image = "testventure_crimson_pick.png",
	range = 4.4,
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[5]=5.5, [4]=3.0, [1]=1.3, [2]=0.6, [3]=0.32}, uses=60, maxlevel=3},
			crumbly = {times={[1]=0.7, [2]=0.29, [3]=0.16}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:sword_crimson", {
			description = "".. core.colorize("#00eaff", "crimson sword\n")..core.colorize("#FFFFFF", "Melee damage: 13\n")..core.colorize("#FFFFFF", "Critical chance: 8%\n") ..core.colorize("#FFFFFF", "Knockback: 7\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.675\n")..core.colorize("#FFFFFF", "Range: 4.75\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.25, [2]=0.5, [3]=0.16"),
	inventory_image = "testventure_crimson_sword.png",
	wield_scale = {x=1.65,y=1.65,z=1.0},
	range = 4.75,
	tool_capabilities = {
		full_punch_interval = 0.675,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.25, [2]=0.5, [3]=0.16}, uses=80, maxlevel=3},
		},
		damage_groups = {fleshy=13, knockback=7,critical=8},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:axe_crimson", {
			description = "".. core.colorize("#00eaff", "crimson axe\n")..core.colorize("#FFFFFF", "Melee damage: 18\n")..core.colorize("#FFFFFF", "Critical chance: 10%\n")..core.colorize("#FFFFFF", "Knockback: 11\n")..core.colorize("#FFFFFF", "Full punch interval: 0.95\n")..core.colorize("#FFFFFF", "Range: 4.75\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV3): [1]=1.45, [2]=0.50, [3]=0.30"),
	inventory_image = "testventure_crimson_axe.png",
	wield_scale = {x=1.65,y=1.65,z=1.0},
	range = 4.75,
	tool_capabilities = {
		full_punch_interval = 0.95,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=1.45, [2]=0.50, [3]=0.30}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=18,knockback=11,critical=10},
	},
	sound = {breaks = "default_tool_breaks"},
})

--
--black_silver set
--

minetest.register_tool("testventure:pick_black_silver", {
			description = "".. core.colorize("#00eaff", "Black silver pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 13\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.65\n")..core.colorize("#FFFFFF", "Range: 4.9\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV3):[5]=4.5, [4]=2.35, [1]=0.9, [2]=0.420, [3]=0.25\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV3): [1]=0.5, [2]=0.21, [3]=0.12"),
	inventory_image = "testventure_black_silver_pick.png",
	wield_scale = {x=1.75,y=1.75,z=1.0},
	range = 4.9,
	tool_capabilities = {
		full_punch_interval = 0.65,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[5]=4.5, [4]=2.35, [1]=0.9, [2]=0.420, [3]=0.25}, uses=115, maxlevel=3},
			crumbly = {times={[1]=0.5, [2]=0.21, [3]=0.12}, uses=150, maxlevel=3},
		},
		damage_groups = {fleshy=13},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:sword_black_silver", {
			description = "".. core.colorize("#00eaff", "Black silver sword\n")..core.colorize("#FFFFFF", "Melee damage: 20\n")..core.colorize("#FFFFFF", "Critical chance: 9%\n") ..core.colorize("#FFFFFF", "Knockback: 5\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.6\n")..core.colorize("#FFFFFF", "Range: 4.9\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.0, [2]=0.35, [3]=0.12"),
	inventory_image = "testventure_black_silver_sword.png",
	wield_scale = {x=1.75,y=1.75,z=1.0},
	range = 4.9,
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.0, [2]=0.35, [3]=0.12}, uses=125, maxlevel=3},
		},
		damage_groups = {fleshy=20, knockback=5,critical=9},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:axe_black_silver", {
			description = "".. core.colorize("#00eaff", "Black silver battleaxe\n")..core.colorize("#FFFFFF", "Melee damage: 22\n") ..core.colorize("#FFFFFF", "Critical chance: 12%\n") ..core.colorize("#FFFFFF", "Knockback: 11\n")..core.colorize("#FFFFFF", "Full punch interval: 0.825\n")..core.colorize("#FFFFFF", "Range: 4.9\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV3): [1]=1.10, [2]=0.37, [3]=0.20"),
	inventory_image = "testventure_black_silver_axe.png",
	wield_scale = {x=1.75,y=1.75,z=1.0},
	range = 4.9,
	tool_capabilities = {
		full_punch_interval = 0.825,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=1.10, [2]=0.37, [3]=0.20}, uses=110, maxlevel=3},
		},
		damage_groups = {fleshy=21,knockback=11,critical=12},
	},
	sound = {breaks = "default_tool_breaks"},
})



-------unusual-----------

minetest.register_tool("testventure:sword_basic", {
			description = "".. core.colorize("#00eaff", "Basic sword\n")..core.colorize("#FFFFFF", "Melee damage: 10\n")..core.colorize("#FFFFFF", "Critical chance: 4%\n")..core.colorize("#FFFFFF", "Knockback: 7\n")..core.colorize("#FFFFFF", "Full punch interval: 0.9\n")..core.colorize("#FFFFFF", "Range: 4.20\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV2): [1]=1.0, [2]=0.5, [3]=0.25"),
	inventory_image = "testventure_basic_sword.png",
	wield_scale = {x=1.2,y=1.2,z=1.0},
	range = 4.20,
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.0, [2]=0.5, [3]=0.25}, uses=60, maxlevel=2},
		},
		damage_groups = {fleshy=10, knockback=7, critical=4},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:thorny_whip", {
			description = "".. core.colorize("#00eaff", "Thorny whip\n")..core.colorize("#FFFFFF", "Melee damage: 2\n") ..core.colorize("#FFFFFF", "Critical chance: 9%\n") ..core.colorize("#FFFFFF", "Knockback: 1\n")..core.colorize("#FFFFFF", "Full punch interval: 0.4\n")..core.colorize("#FFFFFF", "Range: 5.5\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=3.20, [2]=2.0, [3]=1.00"),
	inventory_image = "testventure_thorny_whip.png",
	wield_scale = {x=2.5,y=2.5,z=1.0},
	range = 5.5,
	tool_capabilities = {
		full_punch_interval = 0.4,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.20, [2]=0.5, [3]=0.15}, uses=25, maxlevel=3},
		},
		damage_groups = {fleshy=2, knockback=1, critical=9},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_craftitem("testventure:bloodstone_club", {
			description = "".. core.colorize("#2a00ff", "Bloodstone club\n")..core.colorize("#FFFFFF", "Melee damage: 44\n") ..core.colorize("#FFFFFF", "Critical chance: 13%\n") ..core.colorize("#FFFFFF", "Knockback: 20\n")..core.colorize("#FFFFFF", "Full punch interval: 2.0\n")..core.colorize("#FFFFFF", "Range: 5.0\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=0.80, [2]=0.35, [3]=0.10"),
	inventory_image = "testventure_bloodstone_club.png",
	wield_scale = {x=2.25,y=2.25,z=3.5},
	range = 5.0,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 2.0,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=0.80, [2]=0.35, [3]=0.10}, uses=80, maxlevel=3},
		},
		damage_groups = {fleshy=44, knockback=20, critical=13},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:cactus_sword", {
			description = "".. core.colorize("#00eaff", "Cactus sword\n")..core.colorize("#FFFFFF", "Melee damage: 6\n") ..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Knockback: 10\n")..core.colorize("#FFFFFF", "Full punch interval: 1.0\n")..core.colorize("#FFFFFF", "Range: 4.75\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=3.20, [2]=2.0, [3]=1.00"),
	inventory_image = "testventure_cactus_sword.png",
	wield_scale = {x=2.0,y=2.0,z=2.5},
	range = 4.75,
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.20, [2]=0.5, [3]=0.15}, uses=25, maxlevel=3},
		},
		damage_groups = {fleshy=6, knockback=10, critical=5},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_craftitem("testventure:spear", {
			description = "".. core.colorize("#00eaff", "Spear\n")..core.colorize("#FFFFFF", "Melee damage: 12\n") ..core.colorize("#FFFFFF", "Critical chance: 6%\n") ..core.colorize("#FFFFFF", "Knockback: 13\n")..core.colorize("#FFFFFF", "Full punch interval: 1.5\n")..core.colorize("#FFFFFF", "Range: 5.75\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=2.50, [2]=1.25, [3]=0.5"),
	inventory_image = "testventure_spear.png",
	wield_scale = {x=2.5,y=2.5,z=1.1},
	range = 5.75,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 1.5,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=2.50, [2]=1.25, [3]=0.5}, uses=100, maxlevel=3},
		},
		damage_groups = {fleshy=12, knockback=13, critical=6},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:worm_dagger", {
			description = "".. core.colorize("#00eaff", "Worm tooth dagger\n")..core.colorize("#FFFFFF", "Melee damage: 11\n") ..core.colorize("#FFFFFF", "Critical chance: 17%\n") ..core.colorize("#FFFFFF", "Knockback: 1\n")..core.colorize("#FFFFFF", "Full punch interval: 0.36\n")..core.colorize("#FFFFFF", "Range: 3.0\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.20, [2]=0.5, [3]=0.15"),
	inventory_image = "testventure_worm_dagger.png",
	wield_scale = {x=0.9,y=0.9,z=1},
	range = 3.0,
	tool_capabilities = {
		full_punch_interval = 0.36,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.20, [2]=0.5, [3]=0.15}, uses=125, maxlevel=3},
		},
		damage_groups = {fleshy=11, knockback=1, critical=17},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_craftitem("testventure:shadow_dagger", {
			description = "".. core.colorize("#00eaff", "Shadow dagger\n")..core.colorize("#FFFFFF", "Melee damage: 20\n") ..core.colorize("#FFFFFF", "Critical chance: 15%\n") ..core.colorize("#FFFFFF", "Knockback: 1\n")..core.colorize("#FFFFFF", "Full punch interval: 0.33\n")..core.colorize("#FFFFFF", "Range: 3.10\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=0.80, [2]=0.3, [3]=0.12"),
	inventory_image = "testventure_shadow_dagger.png",
	wield_scale = {x=0.9,y=0.9,z=1},
	range = 3.10,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 0.33,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=0.80, [2]=0.3, [3]=0.12}, uses=175, maxlevel=3},
		},
		damage_groups = {fleshy=20, knockback=1, critical=15},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_craftitem("testventure:fancy_dagger", {
			description = "".. core.colorize("#00eaff", "Fancy dagger\n")..core.colorize("#FFFFFF", "Melee damage: 13\n") ..core.colorize("#FFFFFF", "Critical chance: 11%\n") ..core.colorize("#FFFFFF", "Knockback: 1\n")..core.colorize("#FFFFFF", "Full punch interval: 0.325\n")..core.colorize("#FFFFFF", "Range: 3.4\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.10, [2]=0.45, [3]=0.125"),
	inventory_image = "testventure_fancy_dagger.png",
	wield_scale = {x=0.95,y=0.95,z=1},
	range = 3.4,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 0.325,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.10, [2]=0.45, [3]=0.125}, uses=125, maxlevel=3},
		},
		damage_groups = {fleshy=13, knockback=1, critical=11},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_craftitem("testventure:greatsword", {
			description = "".. core.colorize("#00eaff", "Greatsword\n")..core.colorize("#FFFFFF", "Melee damage: 33\n") ..core.colorize("#FFFFFF", "Critical chance: 10%\n") ..core.colorize("#FFFFFF", "Knockback: 20\n")..core.colorize("#FFFFFF", "Full punch interval: 1.75\n")..core.colorize("#FFFFFF", "Range: 5.5\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.20, [2]=0.5, [3]=0.15"),
	inventory_image = "testventure_greatsword.png",
	wield_scale = {x=2.0,y=2.0,z=1},
	stack_max = 1,
	range = 5.5,
	tool_capabilities = {
		full_punch_interval = 1.75,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.20, [2]=0.5, [3]=0.15}, uses=135, maxlevel=3},
		},
		damage_groups = {fleshy=33, knockback=20, critical=10},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:niobium_sword", {
			description = "".. core.colorize("#2a00ff", "Niobium sword\n")..core.colorize("#FFFFFF", "Melee damage: 31\n") ..core.colorize("#FFFFFF", "Critical chance: 13%\n") ..core.colorize("#FFFFFF", "Knockback: 12\n")..core.colorize("#FFFFFF", "Full punch interval: 0.70\n") ..core.colorize("#FFFFFF", "Range: 4.75") ..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=0.75, [2]=0.35, [3]=0.10"),
	inventory_image = "testventure_niobium_sword.png",
	wield_scale = {x=1.8,y=1.8,z=1},
	range = 4.75,
	tool_capabilities = {
		full_punch_interval = 0.70,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=0.75, [2]=0.35, [3]=0.10}, uses=175, maxlevel=3},
		},
		damage_groups = {fleshy=31, knockback=12, critical=13},
	},
	sound = {breaks = "default_tool_breaks"},
})


minetest.register_tool("testventure:amber_sword", {
			description = "".. core.colorize("#00eaff", "Amber sword\n")..core.colorize("#FFFFFF", "Melee damage: 14\n") ..core.colorize("#FFFFFF", "Critical chance: 9%\n") ..core.colorize("#FFFFFF", "Knockback: 11\n")..core.colorize("#FFFFFF", "Full punch interval: 0.75\n") ..core.colorize("#FFFFFF", "Range: 4.65\n")..core.colorize("#FFFFFF", "Regenerates 1hp every 2 seconds while wielded\n") ..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.15, [2]=0.55, [3]=0.17"),
	inventory_image = "testventure_amber_sword.png",
	wield_scale = {x=1.6,y=1.6,z=1},
	range = 4.65,
	tool_capabilities = {
		full_punch_interval = 0.75,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.15, [2]=0.55, [3]=0.17}, uses=125, maxlevel=3},
		},
		damage_groups = {fleshy=14, knockback=11, critical=9},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_craftitem("testventure:cloud_sword", {
			description = "".. core.colorize("#00eaff", "Cloud sword\n")..core.colorize("#FFFFFF", "Melee damage: 23\n") ..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Knockback: 15\n")..core.colorize("#FFFFFF", "Full punch interval: 0.6\n") ..core.colorize("#FFFFFF", "Range: 4.75\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.35, [2]=0.65, [3]=0.20"),
	inventory_image = "testventure_cloud_sword.png",
	wield_scale = {x=1.65,y=1.65,z=1.75},
	range = 4.75,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.35, [2]=0.65, [3]=0.2}, uses=115, maxlevel=3},
		},
		damage_groups = {fleshy=23, knockback=15, critical=5},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:bone_sword", {
			description = "".. core.colorize("#00eaff", "Bone sword\n")..core.colorize("#FFFFFF", "Melee damage: 12\n") ..core.colorize("#FFFFFF", "Critical chance: 7%\n") ..core.colorize("#FFFFFF", "Knockback: 11\n")..core.colorize("#FFFFFF", "Full punch interval: 0.9\n")..core.colorize("#FFFFFF", "Range: 4.5\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.30, [2]=0.6, [3]=0.2"),
	inventory_image = "testventure_bone_sword.png",
	wield_scale = {x=1.5,y=1.5,z=1},
	range = 4.5,
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.30, [2]=0.6, [3]=0.20}, uses=120, maxlevel=3},
		},
		damage_groups = {fleshy=11, knockback=11, critical=7},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:pick_bone", {
			description = "".. core.colorize("#00eaff", "Bone pickaxe\n")..core.colorize("#FFFFFF", "Melee damage: 9\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.95\n")..core.colorize("#FFFFFF", "Range: 4.65\n") ..core.colorize("#FFFFFF", "Digging speed (Cracky LV3):[4]=4.10, [1]=1.8, [2]=0.85, [3]=0.425\n")..core.colorize("#FFFFFF", "Digging speed (Crumbly LV3): [1]=0.83, [2]=0.34, [3]=0.22"),
	inventory_image = "testventure_bone_pick.png",
	range = 4.65,
	wield_scale = {x=1.5,y=1.5,z=1},
	tool_capabilities = {
		full_punch_interval = 0.95,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[4]=4.10, [1]=1.8, [2]=0.85, [3]=0.425}, uses=49, maxlevel=3},
			crumbly = {times={[1]=0.95, [2]=0.41, [3]=0.25}, uses=42, maxlevel=3},
		},
		damage_groups = {fleshy=9},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_craftitem("testventure:zombie_hand", {
			description = "".. core.colorize("#00eaff", "Zombie hand\n")..core.colorize("#FFFFFF", "Melee damage: 9\n") ..core.colorize("#FFFFFF", "Critical chance: 6%\n") ..core.colorize("#FFFFFF", "Knockback: 13\n")..core.colorize("#FFFFFF", "Full punch interval: 0.85\n")..core.colorize("#FFFFFF", "Range: 4.5"),
	inventory_image = "testventure_zombie_hand.png",
	wield_scale = {x=1.2,y=1.2,z=1},
	range = 4.25,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 0.85,
		max_drop_level=3,
		groupcaps={
		},
		damage_groups = {fleshy=9, knockback=13, critical=6},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_craftitem("testventure:bloody_zombie_hand", {
			description = "".. core.colorize("#2a00ff", "Bloody zombie hand\n")..core.colorize("#FFFFFF", "Melee damage: 19\n") ..core.colorize("#FFFFFF", "Critical chance: 12%\n") ..core.colorize("#FFFFFF", "Knockback: 14\n")..core.colorize("#FFFFFF", "Full punch interval: 0.75\n")..core.colorize("#FFFFFF", "Range: 4.6"),
	inventory_image = "testventure_bloody_zombie_hand.png",
	wield_scale = {x=1.35,y=1.35,z=1},
	range = 4.25,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 0.75,
		max_drop_level=3,
		groupcaps={
		},
		damage_groups = {fleshy=19, knockback=14, critical=12},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:rainbow_gem_sword", {
			description = "".. core.colorize("#00eaff", "Rainbow gem sword\n")..core.colorize("#FFFFFF", "Melee damage: 15\n") ..core.colorize("#FFFFFF", "Critical chance: 7%\n") ..core.colorize("#FFFFFF", "Knockback: 15\n")..core.colorize("#FFFFFF", "Full punch interval: 1.1\n")..core.colorize("#FFFFFF", "Range: 5.20\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.00, [2]=0.6, [3]=0.25"),
	inventory_image = "testventure_rainbow_gem_sword.png",
	wield_scale = {x=1.9,y=1.9,z=1.5},
	range = 5.20,
	tool_capabilities = {
		full_punch_interval = 1.1,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.00, [2]=0.6, [3]=0.25}, uses=125, maxlevel=3},
		},
		damage_groups = {fleshy=15, knockback=15, critical=7},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:treedoomer", {
			description = "".. core.colorize("#00eaff", "Treedoomer\n")..core.colorize("#FFFFFF", "Melee damage: 25\n")..core.colorize("#FFFFFF", "Critical chance: 12%\n")..core.colorize("#FFFFFF", "Knockback: 12\n")..core.colorize("#FFFFFF", "Full punch interval: 1.1\n")..core.colorize("#FFFFFF", "Range: 4.9\n")..core.colorize("#FFFFFF", "Digging speed (Choppy LV3): [1]=1.1, [2]=0.35, [3]=0.225"),
	inventory_image = "testventure_treedoomer.png",
	wield_scale = {x=1.8,y=1.8,z=1.0},
	range = 4.9,
	tool_capabilities = {
		full_punch_interval = 1.1,
		max_drop_level=3,
		groupcaps={
			choppy = {times={[1]=1.1, [2]=0.35, [3]=0.225}, uses=150, maxlevel=3},
		},
		damage_groups = {fleshy=25,knockback=12,critical=12},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_tool("testventure:adventurer_sword", {
			description = "".. core.colorize("#00eaff", "Adventurer's sword\n")..core.colorize("#FFFFFF", "Melee damage: 26\n")..core.colorize("#FFFFFF", "Critical chance: 10%\n") ..core.colorize("#FFFFFF", "Knockback: 6\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.7\n")..core.colorize("#FFFFFF", "Range: 5.0\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=0.8, [2]=0.30, [3]=0.09\n")..core.colorize("#6b9f45", "What time is it? IT'S ADVENTURE TIME!"),
	inventory_image = "testventure_adventurer_sword.png",
	wield_scale = {x=1.75,y=1.75,z=1.0},
	range = 5.0,
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=0.8, [2]=0.30, [3]=0.09}, uses=160, maxlevel=3},
		},
		damage_groups = {fleshy=26, knockback=6,critical=10},
	},
	sound = {breaks = "default_tool_breaks"},
})
