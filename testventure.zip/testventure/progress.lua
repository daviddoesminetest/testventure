minetest.register_on_joinplayer(function(player)
 meta = player:get_meta()
if not meta:get_int("chaos") then
meta:set_int("chaos",0)
end
end)

function testventure.progress()
local progresspath_find = io.open(minetest.get_worldpath().."/progression","r")
	if not progresspath_find then

	local progresspath_make = io.open(minetest.get_worldpath().."/progression","w")
	progresspath_make:write("0")
	io.close(progresspath_make)	
	progresspath_find = io.open(minetest.get_worldpath().."/progression","r")

 	end	
io.close(progresspath_find)	

end

testventure.progress()



chaos_table = {
  "testventure:rifle 1",
  "testventure:treedoomer 1",
  "testventure:crimvolver 1",
  "testventure:mana_amulet 1",
}
minetest.register_on_dignode(function(pos, oldnode, digger)
	if digger ~= nil and digger:is_player() then
	if oldnode.name == "testventure:chaos_block" then
 	meta = digger:get_meta()
	local chaos = meta:get_int("chaos") or 0
	if chaos == 0 then meta:set_int("chaos",1)
 minetest.chat_send_player(digger:get_player_name(),"" ..core.colorize("#00df7e","Feels like you are being followed..."))
	end
	if chaos == 1 then meta:set_int("chaos",2)
 minetest.chat_send_player(digger:get_player_name(),"" ..core.colorize("#00df7e","you feel like the forces of darkness really want you dead..."))
	end
	if chaos == 2 then meta:set_int("chaos",0)
 minetest.chat_send_player(digger:get_player_name(),"" ..core.colorize("#c000ff","Bloodstone golem has been summoned!"))
	pos.y = pos.y + 1
minetest.env:add_entity(pos, "testventure:bloodstone_golem")
	end
	for i=1,math.random(1,2) do
local booty = minetest.add_item(pos, chaos_table[math.random(#chaos_table)])
end
end
end
end)

local spwtimer = 0
minetest.register_globalstep(function(dtime, player)
spwtimer = spwtimer + dtime;
	if spwtimer >= 10.0 then
	for _, player in pairs(minetest.get_connected_players()) do
	spwtimer = 0
	local pos = player:get_pos()
 	meta = player:get_meta()
	local chaos = meta:get_int("chaos") or 0
		if chaos == 1 then
		if math.random(1,3) == 1 then
minetest.add_entity({x=pos.x + math.random(-30, 30), y=pos.y + math.random(1, 5), z=pos.z + (math.random(-30, 30))}, "testventure:shadow_assasin")
		end end
		if chaos == 2 then
		if math.random(1,2) == 1 then
minetest.add_entity({x=pos.x + math.random(-30, 30), y=pos.y + math.random(1, 5), z=pos.z + (math.random(-30, 30))}, "testventure:shadow_assasin")
		end
		if math.random(1,4) == 1 then
minetest.add_entity({x=pos.x + math.random(-30, 30), y=pos.y + math.random(1, 5), z=pos.z + (math.random(-30, 30))}, "testventure:darkness_sniper")
 		end end
end
end
end)


minetest.register_node("testventure:chaos_block", {
		description = "".. core.colorize("#00eaff", "Block of chaos\n")..core.colorize("#FFFFFF", "Destroy those to get some loot... and troubles..."),
	tiles = {"testventure_chaos_block_top.png", "testventure_chaos_block_top.png", "testventure_chaos_block_side.png"},
	stack_max= 999,
	drop = "",
	on_blast = function() end,
	light_source = 12,
	is_ground_content = false,
	groups = {cracky = 4},
	sounds = default.node_sound_wood_defaults(),

})

minetest.register_node("testventure:crimson_room_seed", {
		description = "".. core.colorize("#00eaff", "Bloodstone\n")..core.colorize("#FFFFFF", "YOU HACKER! YOU!"),
	tiles = {"testventure_bloodstone.png"},
	drop = "",
	groups = {cracky = 4,not_in_creative_inventory=1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_abm({
	nodenames = {"testventure:crimson_room_seed"},
	neighbors = {"group:spreads_darkness"},
	interval = 1,
	chance = 1,
	catch_up = false,
	action = function(pos, node)
	pos.x = pos.x - 4
	pos.y = pos.y - 3
	pos.z = pos.z - 4
	minetest.place_schematic(pos, minetest.get_modpath("testventure") .. "/schematics/crimsonroom.mts","random",nil, true)
	end
})

--- progress_mode--

minetest.register_on_generated(function(minp, maxp)
	if maxp.y < -31000 or maxp.y > -500 then
		return
	end
	local filepath = minetest.get_worldpath().."/progression"
	local prg = io.open(filepath, "r")
	if prg ~= nil then
	prgmode = prg:read("*l")
	prg:close()
	prgnum = prgmode + 0
		if prgnum > 0 then
	local ore = minetest.find_nodes_in_area(minp, maxp,
		{"default:stone"})
	for n = 1, #ore do
		if math.random(1, 9001) == 1 then
			local pos = {x = ore[n].x, y = ore[n].y, z = ore[n].z }
				if minetest.get_node({x=pos.x, y=pos.y, z=pos.z}).name == "default:stone" and pos.y <=-600 then
				minetest.add_node({x=pos.x, y=pos.y, z=pos.z}, {name = "testventure:niobium_ore"})
		if math.random(1, 3) == 1 then
				minetest.add_node({x=pos.x, y=pos.y+1, z=pos.z}, {name = "testventure:niobium_ore"})
	end
		if math.random(1, 3) == 1 then
				minetest.add_node({x=pos.x, y=pos.y-1, z=pos.z}, {name = "testventure:niobium_ore"})
	end
		if math.random(1, 3) == 1 then
				minetest.add_node({x=pos.x+1, y=pos.y, z=pos.z}, {name = "testventure:niobium_ore"})
	end
		if math.random(1, 3) == 1 then
				minetest.add_node({x=pos.x-1, y=pos.y, z=pos.z}, {name = "testventure:niobium_ore"})
	end
		if math.random(1, 3) == 1 then
				minetest.add_node({x=pos.x, y=pos.y, z=pos.z+1}, {name = "testventure:niobium_ore"})
	end
		if math.random(1, 3) == 1 then
				minetest.add_node({x=pos.x+1, y=pos.y, z=pos.z-1}, {name = "testventure:niobium_ore"})
	end
end
end
end
end
	end
end)


minetest.register_abm({
	nodenames = {"default:dirt_with_grass"},
	interval = 20,
	chance = 21000,
		action = function(pos, node)
	local filepath = minetest.get_worldpath().."/progression"
	local prg = io.open(filepath, "r")
	if prg ~= nil then
	prgmode = prg:read("*l")
	prg:close()
	prgnum = prgmode + 0
		if prgnum > 0 then
		pos.y = pos.y+1
	if minetest.get_node(pos).name == "air" then
	minetest.env:add_entity(pos, "testventure:slime_magic")
	end end end end
})

minetest.register_abm({
	nodenames = {"default:desert_sand"},
	interval = 20,
	chance = 17000,
		action = function(pos, node)
	local filepath = minetest.get_worldpath().."/progression"
	local prg = io.open(filepath, "r")
	if prg ~= nil then
	prgmode = prg:read("*l")
	prg:close()
	prgnum = prgmode + 0
		if prgnum > 0 then
		pos.y = pos.y+1
	if minetest.get_node(pos).name == "air" then
	minetest.env:add_entity(pos, "testventure:living_cactus")
	end end end end
})

minetest.register_abm({
	nodenames = {"default:dirt_with_grass","default:sand","default:dry_dirt_with_grass"},
	interval = 20,
	chance = 12500,
		action = function(pos, node)
	local tod = minetest.get_timeofday()
	if tod >= 0.8 or tod <= 0.2  then
	local filepath = minetest.get_worldpath().."/progression"
	local prg = io.open(filepath, "r")
	if prg ~= nil then
	prgmode = prg:read("*l")
	prg:close()
	prgnum = prgmode + 0
		if prgnum > 0 then
		pos.y = pos.y+1
	if minetest.get_node(pos).name == "air" then
	minetest.env:add_entity(pos, "testventure:darkness_skeleton")
	end end end end end
})