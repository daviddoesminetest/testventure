minetest.register_craftitem("testventure:clearance_dust", {
		description = "".. core.colorize("#00eaff", "Dust of clearance\n")..core.colorize("#FFFFFF", "Spray this on darkened blocks, to remove the darkness"),
	range = 0,
	stack_max= 25,
	inventory_image = "testventure_clearance_dust.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then
		pos.y = pos.y + 1.5
		for i=1,25 do
			local obj = minetest.add_entity(pos, "testventure:clear_particle")

			if obj then
				minetest.sound_play("testventure_throw", {object=obj})
				obj:setvelocity({x=dir.x * math.random(5, 7) , y=dir.y * math.random(5, 7), z=dir.z * math.random(5, 7)})
				obj:setacceleration({x=math.random(-3, 3), y=math.random(-4, 0), z=math.random(-3, 3)})
end
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_clear_particle = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.33, y=0.33,},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_clear_particle.on_step = function(self, dtime)
	self.timer = self.timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	if node.name == "testventure:grassy_dark_dirt" then
	minetest.set_node(pos, {name = "default:dirt_with_grass"})
	end
	if node.name == "testventure:dark_dirt" then
	minetest.set_node(pos, {name = "default:dirt"})
	end
	if node.name == "testventure:dark_cactus" then
	minetest.set_node(pos, {name = "default:cactus"})
	end
	if node.name == "testventure:dark_ice" then
	minetest.set_node(pos, {name = "default:ice"})
	end
	if node.name == "testventure:bloody_snow" then
	minetest.set_node(pos, {name = "default:snow"})
	end
	if node.name == "testventure:bloody_snow_block" then
	minetest.set_node(pos, {name = "default:snowblock"})
	end
	if node.name == "testventure:bloody_water_source" then
	minetest.set_node(pos, {name = "default:water_source"})
	end
	if node.name == "testventure:dark_sand" then
	minetest.set_node(pos, {name = "default:sand"})
	end
	if node.name == "testventure:dark_tree" then
	minetest.set_node(pos, {name = "default:tree"})
	end
	if node.name == "testventure:dark_grass" then
	minetest.set_node(pos, {name = "default:grass_3"})
	end
	if node.name == "testventure:thorny_bush" then
	minetest.set_node(pos, {name = "default:bush_leaves"})
	end
	if node.name == "testventure:dark_leaves" then
	minetest.set_node(pos, {name = "default:leaves"})
	end
	if node.name == "testventure:bloodstone" then
	minetest.set_node(pos, {name = "default:stone"})
	end
		local tiem = 0.25
		if self.timer >= 0.25 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-5, 5), y=math.random(-5, 5), z=math.random(-5, 5)},
		expirationtime = 0.75,
		size = 3,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_clear_particle.png",
		glow = 25,
	})
		tiem = tiem + 0.25 
			end
	if self.timer > 3.0 then
			self.object:remove()
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end

minetest.register_entity("testventure:clear_particle", testventure_clear_particle)



minetest.register_craftitem("testventure:darkness_spores", {
		description = "".. core.colorize("#00eaff", "Darkness Spores\n")..core.colorize("#FFFFFF", "Spray those on blocks that can be endarkened, to spread the darklands"),
	range = 0,
	stack_max= 15,
	inventory_image = "testventure_darkness_spores.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then
		pos.y = pos.y + 1.5
		for i=1,20 do
			local obj = minetest.add_entity(pos, "testventure:dark_particle")

			if obj then
				minetest.sound_play("testventure_throw", {object=obj})
				obj:setvelocity({x=dir.x * math.random(4, 6) , y=dir.y * math.random(4, 6), z=dir.z * math.random(4, 6)})
				obj:setacceleration({x=math.random(-2, 2), y=math.random(-3, -1), z=math.random(-2, 2)})
end
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_dark_particle = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.33, y=0.33,},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_dark_particle.on_step = function(self, dtime)
	self.timer = self.timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	if node.name == "default:dirt_with_dry_grass" 
	or node.name == "default:dirt_with_grass" 
	or node.name == "default:dirt_with_snow" 
	or node.name == "default:dirt_with_rainforest_litter" then
	minetest.set_node(pos, {name = "testventure:grassy_dark_dirt"})
	end
	if node.name == "default:dirt" then
	minetest.set_node(pos, {name = "testventure:dark_dirt"})
	end
	if node.name == "default:cactus" then
	minetest.set_node(pos, {name = "testventure:dark_cactus"})
	end
	if node.name == "default:ice" then
	minetest.set_node(pos, {name = "testventure:dark_ice"})
	end
	if node.name == "default:snow" then
	minetest.set_node(pos, {name = "testventure:bloody_snow"})
	end
	if node.name == "default:snowblock" then
	minetest.set_node(pos, {name = "testventure:bloody_snow_block"})
	end
	if node.name == "default:water_source" then
	minetest.set_node(pos, {name = "testventure:bloody_water_source"})
	end
	if node.name == "default:silver_sand" 
	or node.name == "default:sand" 
	or node.name == "default:desert_sand" then
	minetest.set_node(pos, {name = "testventure:dark_sand"})
	end
	if node.name == "default:acacia_tree" 
	or node.name == "default:tree" 
	or node.name == "default:aspen_tree" 
	or node.name == "default:jungletree" 
	or node.name == "default:pine_tree" then
	minetest.set_node(pos, {name = "testventure:dark_tree"})
	end
	if node.name == "default:grass_1" 
	or node.name == "default:grass_2" 
	or node.name == "default:grass_3" 
	or node.name == "default:grass_4" 
	or node.name == "default:grass_5" then
	minetest.set_node(pos, {name = "testventure:dark_grass"})
	end
	if node.name == "default:dry_shrub" 
	or node.name == "default:junglegrass" 
	or node.name == "default:bush_stem" 
	or node.name == "default:bush_leaves" 
	or node.name == "default:acacia_bush_stem" 
	or node.name == "default:acacia_bush_leaves" then
	minetest.set_node(pos, {name = "testventure:thorny_bush"})
	end
	if node.name == "default:acacia_leaves" 
	or node.name == "default:leaves" 
	or node.name == "default:aspen_leaves" 
	or node.name == "default:jungleleaves" 
	or node.name == "default:pine_needles" then
	minetest.set_node(pos, {name = "testventure:dark_leaves"})
	end
	if node.name == "default:stone" 
	or node.name == "default:sandstone" 
	or node.name == "default:desert_stone" then
	minetest.set_node(pos, {name = "testventure:bloodstone"})
	end
		local tiem = 0.25
		if self.timer >= 0.25 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-5, 5), y=math.random(-5, 5), z=math.random(-5, 5)},
		expirationtime = 0.75,
		size = 3,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_dark_particle.png",
		glow = 25,
	})
		tiem = tiem + 0.25 
			end
	if self.timer > 2.5 then
			self.object:remove()
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end

minetest.register_entity("testventure:dark_particle", testventure_dark_particle)



minetest.register_abm({
	nodenames = {"default:sand","default:desert_sand","default:silver_sand"},
	neighbors = {"group:spreads_darkness"},
	interval = 15,
	chance = 250,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:dark_sand"})
	end
})

minetest.register_abm({
	nodenames = {"default:dirt_with_grass","default:dirt_with_snow", "default:dirt_with_dry_grass", "default:dirt_with_rainforest_litter"},
	neighbors = {"group:spreads_darkness"},
	interval = 15,
	chance = 250,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:grassy_dark_dirt"})
	end
})

minetest.register_abm({
	nodenames = {"default:grass_1", "default:grass_2", "default:grass_3", "default:grass_4", "default:grass_5","default:dry_grass_1", "default:dry_grass_2", "default:dry_grass_3", "default:dry_grass_4", "default:dry_grass_5" },
	neighbors = {"group:spreads_darkness"},
	interval = 5,
	chance = 4,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:dark_grass"})
	end
})

minetest.register_abm({
	nodenames = {"flowers:mushroom_red","flowers:mushroom_brown","testventure:shroom"},
	neighbors = {"group:spreads_darkness"},
	interval = 5,
	chance = 4,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:darkshroom"})
	end
})

minetest.register_abm({
	nodenames = {"group:flower","testventure:sunglow"},
	neighbors = {"group:spreads_darkness"},
	interval = 5,
	chance = 4,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:bloodbloom_plant"})
	end
})

minetest.register_abm({
	nodenames = {"default:dry_shrub","default:junglegrass","default:bush_stem","default:bush_leaves","default:acacia_bush_stem","default:acacia_bush_leaves"},
	neighbors = {"group:spreads_darkness"},
	interval = 5,
	chance = 4,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:thorny_bush"})
	end
})

minetest.register_abm({
	nodenames = {"default:water_source"},
	neighbors = {"group:spreads_darkness"},
	interval = 4,
	chance = 15,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:bloody_water_source"})
	end
})

minetest.register_abm({
	nodenames = {"default:leaves", "default:pine_needles", "default:acacia_leaves", "default:jungleleaves", "default:aspen_leaves"},
	neighbors = {"group:spreads_darkness"},
	interval = 4,
	chance = 25,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:dark_leaves"})
	end
})

minetest.register_abm({
	nodenames = {"default:tree", "default:pine_tree", "default:acacia_tree", "default:jungletree", "default:aspen_tree"},
	neighbors = {"group:spreads_darkness"},
	interval = 5,
	chance = 10,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:dark_tree"})
	end
})

minetest.register_abm({
	nodenames = {"default:cactus"},
	neighbors = {"group:spreads_darkness"},
	interval = 5,
	chance = 5,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:dark_cactus"})
	end
})

minetest.register_abm({
	nodenames = {"default:stone", "default:sandstone", "default:desert_stone"},
	neighbors = {"group:spreads_darkness"},
	interval = 15,
	chance = 250,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:bloodstone"})
	end
})

minetest.register_abm({
	nodenames = {"default:dirt"},
	neighbors = {"group:spreads_darkness"},
	interval = 15,
	chance = 250,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:dark_dirt"})
	end
})

minetest.register_abm({
	nodenames = {"default:stone_with_iron"},
	neighbors = {"group:spreads_darkness"},
	interval = 9,
	chance = 169,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:shadowsteel_ore"})
	end
})

minetest.register_abm({
	nodenames = {"default:ice"},
	neighbors = {"group:spreads_darkness"},
	interval = 15,
	chance = 250,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:dark_ice"})
	end
})

minetest.register_abm({
	nodenames = {"default:snowblock"},
	neighbors = {"group:spreads_darkness"},
	interval = 15,
	chance = 250,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:bloody_snow_block"})
	end
})

minetest.register_abm({
	nodenames = {"default:snow"},
	neighbors = {"group:spreads_darkness"},
	interval = 15,
	chance = 250,
	catch_up = false,
	action = function(pos, node)
	minetest.set_node(pos, {name = "testventure:bloody_snow"})
	end
})

minetest.register_abm({
	nodenames = {"testventure:grassy_dark_dirt"},
	interval = 10,
	chance = 9001,
	action = function(pos, node)
		pos.y = pos.y+1
		if minetest.get_node(pos).name == "air" then
			node.name = "testventure:darkshroom"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_abm({
	nodenames = {"testventure:darkshroom"},
	interval = 16,
	chance = 69,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:darkshroom" then
			node.name = "air"
			minetest.set_node(pos, node)
		end
	end
})

	minetest.register_biome({
		name = "darklands",
		--node_dust = "",
		node_top = "testventure:grassy_dark_dirt",
		depth_top = 1,
		node_filler = "testventure:dark_dirt",
		depth_filler = 2,
		node_stone = "testventure:bloodstone",
		--node_water_top = "",
		--depth_water_top = ,
		node_water = "testventure:bloody_water_source",
		node_river_water = "testventure:bloody_water_source",
		node_riverbed = "testventure:dark_sand",
		depth_riverbed = 2,
		y_min = -100,
		y_max = upper_limit,
		heat_point = 55,
		humidity_point = 65,
	})


	minetest.register_decoration({
		deco_type = "schematic",
		place_on = {"testventure:grassy_dark_dirt"},
		sidelen = 16,
		noise_params = {
			offset = 0.002,
			scale = 0.006,
			spread = {x = 250, y = 250, z = 250},
			seed = 2,
			octaves = 3,
			persist = 0.66
		},
		biomes = {"darklands"},
		y_min = 1,
		y_max = 31000,
		schematic = minetest.get_modpath("testventure") .. "/schematics/dark_tree.mts",
		flags = "place_center_x, place_center_z",
		rotation = "random",
	})

	minetest.register_decoration({
		deco_type = "simple",
		place_on = {"testventure:grassy_dark_dirt"},
		sidelen = 16,
		noise_params = {
			offset = 0.05,
			scale = 0.05,
			spread = {x = 200, y = 200, z = 200},
			seed = 329,
			octaves = 3,
			persist = 0.6
		},
		biomes = {"darklands"},
		y_min = 2,
		y_max = 31000,
		decoration = "testventure:dark_grass",
	})


	minetest.register_decoration({
		deco_type = "schematic",
		place_on = {"testventure:grassy_dark_dirt"},
		sidelen = 16,
		noise_params = {
			offset = 0.003,
			scale = 0.009,
			spread = {x = 250, y = 250, z = 250},
			seed = 2,
			octaves = 3,
			persist = 0.66
		},
		biomes = {"darklands"},
		y_min = 1,
		y_max = 31000,
		schematic = minetest.get_modpath("testventure") .. "/schematics/thorny_bush.mts",
		flags = "place_center_x, place_center_z",
		rotation = "random",
	})





minetest.register_node("testventure:bloody_snow", {
		description = "".. core.colorize("#00eaff", "Bloody snow\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	tiles = {"testventure_bloody_snow.png"},
	inventory_image = "testventure_bloody_snowball.png",
	wield_image = "testventure_bloody_snowball.png",
	paramtype = "light",
	buildable_to = true,
	floodable = true,
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, -0.25, 0.5},
		},
	},
	groups = {crumbly = 3, falling_node = 1, puts_out_fire = 1, snowy = 1, spreads_darkness = 1},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "testventure_snow_footstep", gain = 0.15},
		dug = {name = "default_snow_footstep", gain = 0.2},
		dig = {name = "default_snow_footstep", gain = 0.2}
	}),
})

minetest.register_node("testventure:bloody_snow_block", {
		description = "".. core.colorize("#00eaff", "Bloody snow block\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	tiles = {"testventure_bloody_snow.png"},
	stack_max= 999,
	groups = {crumbly = 2, spreads_darkness = 1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("testventure:dark_ice", {
		description = "".. core.colorize("#00eaff", "Dark ice\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	tiles = {"testventure_dark_ice.png"},
	stack_max= 999,
	groups = {cracky = 3, spreads_darkness = 1},
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_node("testventure:dark_grass", {
		description = "".. core.colorize("#00eaff", "Darkened Grass\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.3,
	stack_max= 999,
	tiles = {"testventure_dark_grass.png"},
	inventory_image = "testventure_dark_grass.png",
	wield_image = "testventure_dark_grass.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1, spreads_darkness = 1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("testventure:darkshroom", {
		description = "".. core.colorize("#00eaff", "Darkshroom\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_darkshroom.png"},
	inventory_image = "testventure_darkshroom.png",
	wield_image = "testventure_darkshroom.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1, spreads_darkness = 1},
	sounds = default.node_sound_leaves_defaults(),
})


minetest.register_node("testventure:thorny_bush", {
		description = "".. core.colorize("#00eaff", "Thorny bush\n")..core.colorize("#FFFFFF", "A placable, harmful block, which spreads the darklands"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.6,
	tiles = {"testventure_thorny_bush.png"},
	inventory_image = "testventure_thorny_bush.png",
	wield_image = "testventure_thorny_bush.png",
	paramtype = "light",
	stack_max= 999,
	sunlight_propagates = true,
	walkable = false,
	liquidtype = "source",
	liquid_range= 0,
	liquid_viscosity = 10,
	damage_per_second = 2,
	liquid_alternative_flowing = "testventure:thorny_bush",
	liquid_alternative_source = "testventure:thorny_bush",
	liquid_renewable = false,
	groups = {snappy = 3, flora = 1, flammable = 1, spreads_darkness = 1},
	sounds = default.node_sound_leaves_defaults(),

})

minetest.register_node("testventure:dark_leaves", {
		description = "".. core.colorize("#00eaff", "Darkened leaves\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"testventure_dark_leaves.png"},
	stack_max= 999,
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, flammable = 2, leaves = 1, spreads_darkness = 1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("testventure:dark_tree", {
		description = "".. core.colorize("#00eaff", "Darkwood log\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	tiles = {"testventure_dark_tree_top.png", "testventure_dark_tree_top.png", "testventure_dark_tree_side.png"},
	paramtype2 = "facedir",
	stack_max= 999,
	is_ground_content = false,
	groups = {tree = 1, choppy = 2, oddly_breakable_by_hand = 1, flammable = 2, spreads_darkness = 1},
	sounds = default.node_sound_wood_defaults(),

	on_place = minetest.rotate_node
})

minetest.register_node("testventure:dark_cactus", {
		description = "".. core.colorize("#00eaff", "Darkened cactus log\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	tiles = {"testventure_dark_cactus_top.png", "testventure_dark_cactus_top.png", "testventure_dark_cactus_side.png"},
	paramtype2 = "facedir",
	stack_max= 999,
	is_ground_content = false,
	groups = {cactus = 1, choppy = 2, oddly_breakable_by_hand = 1, flammable = 2, spreads_darkness = 1},
	sounds = default.node_sound_wood_defaults(),

	on_place = minetest.rotate_node
})

minetest.register_node("testventure:dark_dirt", {
		description = "".. core.colorize("#00eaff", "Darkened dirt\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	tiles = {"testventure_dark_dirt.png"},
	stack_max= 999,
	groups = {crumbly = 2, spreads_darkness = 1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("testventure:dark_sand", {
		description = "".. core.colorize("#00eaff", "Darkened sand\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	tiles = {"testventure_dark_sand.png"},
	stack_max= 999,
	groups = {crumbly = 2, falling_node = 1, spreads_darkness = 1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("testventure:grassy_dark_dirt", {
		description = "".. core.colorize("#00eaff", "Grassy darkened dirt\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	tiles = {"testventure_dark_grass_top.png", "testventure_dark_dirt.png",
		{name = "testventure_dark_dirt.png^testventure_dark_grass_side.png",
			tileable_vertical = false}},
	groups = {crumbly = 2, spreads_darkness = 1},
	stack_max= 999,
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_grass_footstep", gain = 0.25},
	}),
})

minetest.register_node("testventure:crimrubite_ore", {
		description = "".. core.colorize("#00eaff", "Crimrubite Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_bloodstone.png^testventure_crimrubite_ore.png"},
	groups = {cracky = 4,is_ore=1,rare_ore=1},
	drop = "testventure:crimrubite_lump 1",
	light_source = 5,
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:shadowsteel_ore", {
		description = "".. core.colorize("#00eaff", "Shadowsteel Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_bloodstone.png^testventure_shadowsteel_ore.png"},
	groups = {cracky = 4,is_ore=1,rare_ore=1},
	drop = "testventure:shadowsteel_lump 1",
	light_source = 4,
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:bloodstone", {
		description = "".. core.colorize("#00eaff", "Bloodstone\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	tiles = {"testventure_bloodstone.png"},
	groups = {cracky = 4, spreads_darkness = 1,},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:bloody_water_source", {
	description = "bloody water Source",
	drawtype = "liquid",
	tiles = {
		{
		name = "testventure_bloody_water_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	special_tiles = {
		{
			name = "testventure_bloody_water_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
			backface_culling = false,
		},
	},
	alpha = 185,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "testventure:bloody_water_flowing",
	liquid_alternative_source = "testventure:bloody_water_source",
	liquid_viscosity = 1,
	post_effect_color = {a = 150, r = 200, g = 0, b = 0},
	groups = {water = 3, liquid = 3, spreads_darkness = 1, puts_out_fire = 1, cools_lava = 1, },
	sounds = default.node_sound_water_defaults(),
})

minetest.register_node("testventure:bloody_water_flowing", {
	description = "Flowing bloody water",
	drawtype = "flowingliquid",
	tiles = {"testventure_bloody_water.png"},
	special_tiles = {
		{
			name = "testventure_bloody_water_flowing_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = "testventure_bloody_water_flowing_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = 185,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "testventure:bloody_water_flowing",
	liquid_alternative_source = "testventure:bloody_water_source",
	liquid_viscosity = 1,
	post_effect_color = {a = 150, r = 200, g = 0, b = 0},
	groups = {water = 3, liquid = 3, spreads_darkness = 1, puts_out_fire = 1,
		not_in_creative_inventory = 1, cools_lava = 1},
	sounds = default.node_sound_water_defaults(),
})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:crimrubite_ore",
		wherein        = "testventure:bloodstone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -12,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:shadowsteel_ore",
		wherein        = "testventure:bloodstone",
		clust_scarcity = 15 * 15 * 15,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = 0,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:crimson_room_seed",
		wherein        = "testventure:bloodstone",
		clust_scarcity = 20 * 20 * 20,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -8,
	})

bucket.register_liquid(
	"testventure:bloody_water_source",
	"testventure:bloody_water_flowing",
	"testventure:bucket_bloody_water",
	"bucket_bloody_water.png",
	"".. core.colorize("#00eaff", "Bloody water bucket\n")..core.colorize("#FFFFFF", "A Liquid which spreads the darklands"),
	{bloody_water_bucket = 1}
)
