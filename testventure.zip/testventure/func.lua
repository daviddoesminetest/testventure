

local timer = 0

minetest.register_globalstep(function(dtime, player, pos)
	timer = timer + dtime
	if timer >= 2.0 then
	timer = 0
	for _, player in pairs(minetest.get_connected_players()) do
	local name = player:get_player_name()
	local pos = player:getpos()
	if minetest.get_player_by_name(name) then

	local filepath = minetest.get_worldpath().."/bloodmoon"
	local bloodmoon = io.open(filepath, "r")
	if bloodmoon ~= nil then
	bmmode = bloodmoon:read("*l")
	bloodmoon:close()
	bloodmoon_rised = bmmode + 0
		if bloodmoon_rised == 1 then

	player:set_moon({texture="bloodmoon.png"})
	player:set_clouds({color="#ff0000"})
  	player:set_sky({base_color={r=35,g=0,b=0},type="simple"})

else

if minetest.find_node_near(pos, 10, {"group:spreads_darkness"}) then
  	player:set_sky({base_color={r=75,g=0,b=0},type="simple"})
	player:set_clouds({color="#ff0000"})
	player:set_moon({texture="moon.png"})
else 
if minetest.find_node_near(pos, 10, {"testventure:mycelium_mud"}) then
	player:set_clouds({color="#00ccff"})
  	player:set_sky({base_color={r=0,g=0,b=50},type="simple"})
else 
	local filepath = minetest.get_worldpath().."/rain"
	local rain = io.open(filepath, "r")
	if rain ~= nil then
	rainmode = rain:read("*l")
	rain:close()
	raining = rainmode + 0
		if raining == 1 then

player:set_clouds({color="#5d6d7b"})
player:set_sky({r=60,g=60,b=75}, "simple", {})
player:set_moon({texture="moon.png"})


else
	player:set_moon({texture="moon.png"})
	player:set_clouds({color="#ffffff"})
  	player:set_sky({type="regular"})
end
end
end
end
end
end
end
end
end
end)

minetest.override_item('default:copper_lump', {
	stack_max= 999,
})
minetest.override_item('default:iron_lump', {
	stack_max= 999,
})
minetest.override_item('default:coal_lump', {
	stack_max= 999,
})
minetest.override_item('default:tin_lump', {
	stack_max= 999,
})
minetest.override_item('default:gold_lump', {
	stack_max= 999,
})
minetest.override_item('default:diamond', {
	stack_max= 999,
})
minetest.override_item('default:mese_crystal', {
	stack_max= 999,
})
minetest.override_item('default:cobble', {
	stack_max= 999,
})
minetest.override_item('default:gravel', {
	stack_max= 999,
})
minetest.override_item('default:dirt', {
	stack_max= 999,
})
minetest.override_item('default:wood', {
	stack_max= 999,
})

--
-- bonus weapon dmg from armors
--

if minetest.global_exists("armor") and armor.elements then
	table.insert(armor.elements, "accessory")
	local mult = armor.config.level_multiplier or 1
	armor.config.level_multiplier = 1
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "mana_regen")
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "regen")
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "melee_dmg")
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "melee_crit")
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "ranged_dmg")
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "ranged_crit")
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "magic_dmg")
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "magic_crit")
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "ammo_save")
end

if minetest.global_exists("armor") and armor.attributes then
	table.insert(armor.attributes, "mana_save")
end


--
-- Drownn't
--

local timer = 0
minetest.register_globalstep(function(dtime, player)
	timer = timer + dtime;
	if timer >= 4.0 then
	for _, player in pairs(minetest.get_connected_players()) do
	local wielded_item = player:get_wielded_item():get_name()
		if wielded_item == "testventure:pick_aqua" 
		or wielded_item == "testventure:sword_aqua" 
		or wielded_item == "testventure:axe_aqua" then
			timer = 0
			air = player:get_breath()  
			air = air+1
			player:set_breath(tonumber(air))
end
end
end
	end)

local timer = 0
minetest.register_globalstep(function(dtime, player)
	timer = timer + dtime;
	if timer >= 4.0 then
	for _, player in pairs(minetest.get_connected_players()) do
	local inv = minetest.get_inventory({type="player", name=player:get_player_name()})
local name = player:get_player_name()
		timer = 0
		local armor = minetest.get_inventory({type="detached", name = name .. "_armor"})
		if armor then
			local set_part_a = ItemStack("testventure:helmet_aqua")
			local set_part_b = ItemStack("testventure:chestplate_aqua")
			local set_part_c = ItemStack("testventure:leggings_aqua")
			local set_part_d = ItemStack("testventure:boots_aqua")
			local set_part_e = ItemStack("testventure:shield_aqua")
			if armor:contains_item("armor", set_part_a)
			and armor:contains_item("armor", set_part_b)
			and armor:contains_item("armor", set_part_c)
			and armor:contains_item("armor", set_part_d)
			and armor:contains_item("armor", set_part_e)
			then
			air = player:get_breath()  
			air = air+1
			player:set_breath(tonumber(air))
end
end
end
end
	end)


minetest.register_abm({
	nodenames = {"air"},
	neighbors = {"air"},
	interval = 20,
	chance = 350000,
	catch_up = false,
	action = function(pos, node)
	local tod = minetest.get_timeofday()
	 if tod >= 0.8 or tod <= 0.2  then
	if pos.y > 16 then
	minetest.add_entity(pos,"testventure:star_projectile")
	end end end
})

local testventure_star_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}

testventure_star_projectile.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.1 then
	self.object:setacceleration({x=0, y=-15, z=0})
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 3)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:star_projectile" and obj:get_luaentity().name ~= "__builtin:item" then
local damage = 1337
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage},
					}, nil)
					else

local damage = 0
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
				end
			end
		local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=0, y=0, z=0},
		expirationtime = 0.05,
		size = 7,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_star.png",
		glow = 21,
	})
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-3.0,3.0), y=math.random(-3.0,3.0), z=math.random(-3.0,3.0)},
		expirationtime = 0.3,
		size = 5,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_star.png",
		glow = 21,
	})
		tiem = tiem + 0.2 
			end

	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
minetest.add_item(self.lastpos, "testventure:fallen_star")
	for i=1,40 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-8, 8), y=math.random(-8, 8), z=math.random(-6, 6)},
		size = math.random(1, 3), 
		expirationtime = 2.0,
		collisiondetection = true,
		vertical = false,
		texture = "testventure_star.png",
		glow = 30,
	})
	end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:star_projectile", testventure_star_projectile )


minetest.register_craftitem("testventure:mana_crystal", {
		description = "" ..core.colorize("#00eaff","Mana crystal\n") ..core.colorize("#FFFFFF", "Increases MAX MP by 25 (max 750)"),
	stack_max= 25,
	inventory_image = "testventure_mana_crystal.png",
on_use = function(itemstack, user, pointed_thing)

	local maxmana = mana.getmax(user:get_player_name())
	if maxmana < 750 then 
 	itemstack:take_item()
	mana.setmax(user:get_player_name(), maxmana + 25)
		end
		return itemstack
	end, 
})

local timer = 0
minetest.register_globalstep(function(dtime, player, pos)
	timer = timer + dtime;
	if timer >=1.0 then
	timer = 0
	for _, player in pairs(minetest.get_connected_players()) do
	local pos = player:getpos()
	if minetest.find_node_near(pos, 10, "testventure:magic_slime_block") then
	mana.add(player:get_player_name(), 10)
end
end
end
end)

minetest.register_on_joinplayer(function(player)
	player:get_inventory():set_width("main", 8)
	player:get_inventory():set_size("main", 80)
end)

if minetest.get_modpath("sfinv") then

sfinv.register_page("sfinv:fullinv", {
	title = ("Full INV"),
	get = function(self, player, context)
		return sfinv.make_formspec(player, context, [[
list[current_player;main;0,0.3;8,10;48]
listring[current_player;main]
			]], true)
	end
})

end


minetest.register_chatcommand("fullinv", {
	func = function(name, formname)
		minetest.show_formspec(name,"testventure:fullinv", fullinv) 

end
})

 fullinv =
		(
"size[8,11]"..
"list[current_player;main;0,0.3;8,10;]"..
"button_exit[4,10.3;2,1;exit;Done]")



if minetest.get_modpath("unified_inventory") then

	unified_inventory.register_button("fullinv", {
		type   = "image",
		image  = "testventure_fullinv.png",
		tooltip = "Full inventory",
		action = show_formspec
	})

	minetest.register_on_player_receive_fields(function(player, _, fields)
		if fields.fullinv then
		local name = player:get_player_name()
		minetest.show_formspec(name, "testventure:fullinv", 
"size[8,11]"..
"list[current_player;main;0,0.3;8,10;]"..
"button_exit[4,10.3;2,1;exit;Done]")

		end
	end)

minetest.register_on_player_receive_fields(function(player, formname, fields)
	if formname == "testventure:fullinv" then
	if fields.quit == "true" then 
	unified_inventory.set_inventory_formspec(player, "craft")
end
end end)

end


-------------shooting

bow_shoot = function(itemstack, user, pointed_thing)
	for _,arrow in ipairs(arrows) do
		local inv = user:get_inventory()
		if inv:contains_item("main", arrow[1]) then
		local name = user:get_player_name()
		local ammo_save = armor.def[name].ammo_save
		if user:get_inventory():get_stack("main", user:get_wield_index()+1):get_name() == arrow[1] then
	if math.random(1, 100) >= bow_ammo_save + ammo_save then
	user:get_inventory():remove_item("main", arrow[1])
			end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir and yaw then
	minetest.sound_play(bow_sound, {user})
			pos.y = pos.y + 1.6
	for i=1,shots_fired do
			local obj = minetest.add_entity(pos, arrow[2])
			if obj then
		local name = user:get_player_name()
	base_dmg = bow_damage or 1
	base_crit = bow_crit or 1
	base_kb = bow_knockback or 1
	bow_timer = bow_timer or 0
	local meta = user:get_meta()
	local meta_ranged_dmg = meta:get_int("ranged_dmg_meta")
	mrd = (meta_ranged_dmg / 100)
	dmg_bonus = armor.def[name].ranged_dmg + 1 + mrd
	crit_bonus = armor.def[name].ranged_crit
	bow_accuracy = bow_accuracy or 100
	accuracy = (100 - bow_accuracy) / 10
	bow_velocity = bow_velocity or 10
	shots_fired = shots_fired or 1
				obj:setyaw(yaw + math.pi)
				obj:setvelocity({x=dir.x * bow_velocity, y=dir.y * bow_velocity, z=dir.z * bow_velocity})
				obj:setacceleration({x=math.random(-accuracy,accuracy), y=-bow_gravity, z=math.random(-accuracy,accuracy)})
		end
			local ent = obj:get_luaentity()
			if ent then
			ent.player = ent.player or user
end end end end end end end

------------------------------------------------

auto_bow_shoot = function(itemstack, player)
	for _,arrow in ipairs(arrows) do
		local inv = player:get_inventory()
		if inv:contains_item("main", arrow[1]) then
		local name = player:get_player_name()
		local ammo_save = armor.def[name].ammo_save
		if player:get_inventory():get_stack("main", player:get_wield_index()+1):get_name() == arrow[1] then
	if math.random(1, 100) >= bow_ammo_save + ammo_save then
	player:get_inventory():remove_item("main", arrow[1])
end
		local pos = player:getpos()
		local dir = player:get_look_dir()
		local yaw = player:get_look_yaw()
		if pos and dir and yaw then
	minetest.sound_play(bow_sound, {user})
	base_dmg = bow_damage or 1
	base_crit = bow_crit or 1
	base_kb = bow_knockback or 1
	bow_timer = bow_timer or 0
	local meta = user:get_meta()
	local meta_ranged_dmg = player:get_int("ranged_dmg_meta")
	mrd = (meta_ranged_dmg / 100)
	dmg_bonus = armor.def[name].ranged_dmg + 1 + mrd
	crit_bonus = armor.def[name].ranged_crit
	bow_accuracy = bow_accuracy or 100
	accuracy = (100 - bow_accuracy) / 10
	bow_velocity = bow_velocity or 10
	shots_fired = shots_fired or 1
			pos.y = pos.y + 1.6
	for i=1,shots_fired do
			local obj = minetest.add_entity(pos, arrow[2])
			if obj then
				obj:setvelocity({x=dir.x * bow_velocity, y=dir.y * bow_velocity, z=dir.z * bow_velocity})
				obj:setacceleration({x=math.random(-accuracy,accuracy), y=-bow_gravity, z=math.random(-accuracy,accuracy)})
				obj:setyaw(yaw + math.pi)
			end
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or player
end end end end end end end

---------------------------------------------

gun_shoot = function(itemstack, user, pointed_thing)
	for _,bullets in ipairs(bullets) do
		local inv = user:get_inventory()
		if inv:contains_item("main", bullets[1]) then
		local name = user:get_player_name()
		local ammo_save = armor.def[name].ammo_save
		if user:get_inventory():get_stack("main", user:get_wield_index()+1):get_name() == bullets[1] then
	if math.random(1, 100) >= gun_ammo_save + ammo_save then
	user:get_inventory():remove_item("main", bullets[1])
		timer = 0
			end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
	minetest.sound_play(gun_sound, {user})
		if pos and dir and yaw then
			pos.y = pos.y + 1.6
	for i=1,shots_fired do
			local obj = minetest.add_entity(pos, bullets[2])
			if obj then
		local name = user:get_player_name()
	base_dmg = gun_damage or 1
	base_crit = gun_crit or 1
	base_kb = gun_knockback or 1
	bow_timer = bow_timer or 0
	local meta = user:get_meta()
	local meta_ranged_dmg = meta:get_int("ranged_dmg_meta")
	mrd = (meta_ranged_dmg / 100)
	dmg_bonus = armor.def[name].ranged_dmg + 1 + mrd
	crit_bonus = armor.def[name].ranged_crit
	gun_accuracy = gun_accuracy or 100
	accuracy = (100 - gun_accuracy) / 10
	gun_velocity = gun_velocity or 10
	shots_fired = shots_fired or 1
				obj:setyaw(yaw + math.pi)
				obj:setvelocity({x=dir.x * gun_velocity, y=dir.y * gun_velocity, z=dir.z * gun_velocity})
				obj:setacceleration({x=math.random(-accuracy,accuracy),y=-math.random(-accuracy,accuracy), z= math.random(-accuracy,accuracy)})
		end
			local ent = obj:get_luaentity()
			if ent then
			ent.player = ent.player or user
end end end end end end end

------------------------------------------------

auto_gun_shoot = function(itemstack, player)
	for _,bullets in ipairs(bullets) do
		local inv = player:get_inventory()
		if inv:contains_item("main", bullets[1]) then
		local name = player:get_player_name()
		local ammo_save = armor.def[name].ammo_save
		if player:get_inventory():get_stack("main", player:get_wield_index()+1):get_name() == bullets[1] then
	if math.random(1, 100) >= gun_ammo_save + ammo_save then
	player:get_inventory():remove_item("main", bullets[1])
end
		local pos = player:getpos()
		local dir = player:get_look_dir()
		local yaw = player:get_look_yaw()
		if pos and dir and yaw then
	minetest.sound_play(gun_sound, {player})
	base_dmg = gun_damage or 1
	base_crit = gun_crit or 1
	base_kb = gun_knockback or 1
	bow_timer = bow_timer or 0
	local meta = player:get_meta()
	local meta_ranged_dmg = meta:get_int("ranged_dmg_meta")
	mrd = (meta_ranged_dmg / 100)
	dmg_bonus = armor.def[name].ranged_dmg + 1 + mrd
	crit_bonus = armor.def[name].ranged_crit
	gun_accuracy = gun_accuracy or 100
	accuracy = (100 - gun_accuracy) / 10
	gun_velocity = gun_velocity or 10
	shots_fired = shots_fired or 1
			pos.y = pos.y + 1.6
	for i=1,shots_fired do
			local obj = minetest.add_entity(pos, bullets[2])
			if obj then
				obj:setvelocity({x=dir.x * gun_velocity, y=dir.y * gun_velocity, z=dir.z * gun_velocity})
				obj:setacceleration({x=math.random(-accuracy,accuracy),y=-math.random(-accuracy,accuracy), z= math.random(-accuracy,accuracy)})
				obj:setyaw(yaw + math.pi)
			end
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or player
end end end end end end end

-----------------------------------projectile

projectile_shoot = function(itemstack, player)
		local name = player:get_player_name()
		mana_save = 1 - armor.def[name].mana_save
		if mana.subtract(player:get_player_name(), mana_cost *mana_save) then
		timer = 0
		local pos = player:getpos()
		local dir = player:get_look_dir()
		local yaw = player:get_look_yaw()
		if pos and dir and yaw then

		magic_dmg = 1 + armor.def[name].magic_dmg
		melee_dmg = 1 + armor.def[name].melee_dmg
		local meta = player:get_meta()
		local meta_ranged_dmg = meta:get_int("ranged_dmg_meta")
		mrd = (meta_ranged_dmg / 100)
		ranged_dmg = 1 + armor.def[name].ranged_dmg + mrd
	shots_fired = shots_fired or 1
	ranged_crit = armor.def[name].ranged_crit
	melee_crit = armor.def[name].melee_crit
	magic_crit = armor.def[name].magic_crit
	projectile_accuracy = projectile_accuracy or 100
	accuracy = (100 - projectile_accuracy) / 10
	gun_velocity = gun_velocity or 10

			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, the_projectile)
			if obj then
				minetest.sound_play(projectile_sound, {player})
				obj:setvelocity({x=dir.x * 20, y=dir.y * 20, z=dir.z * 20})
				obj:setacceleration({x=math.random(-accuracy,accuracy), y=-projectile_gravity, z=math.random(-accuracy,accuracy)})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or player
		

end end end end end 

minetest.register_globalstep(function(dtime, player)
	for _, player in pairs(minetest.get_connected_players()) do
local meta = player:get_meta()
local cool_down = meta:get_int("cooldown") or 0
meta:set_int("cooldown", cool_down + 25)


local name = player:get_player_name()
local armor_speed = armor.def[name].speed
 walk_speed = meta:get_int("walkspeed") or 0
player:set_physics_override({speed = (walk_speed/100) + armor_speed})

end end)

minetest.register_on_joinplayer(function(player)
local meta = player:get_meta()
meta:set_int("walkspeed", 0)
end)

minetest.register_on_joinplayer(function(player)
local meta = player:get_meta()
meta:set_int("ranged_dmg_meta", 0)
meta:set_int("srd_applied", 0)
end)

