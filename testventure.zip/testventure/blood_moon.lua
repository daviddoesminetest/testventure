function testventure.bloodmoon()
local bmpath_find = io.open(minetest.get_worldpath().."/bloodmoon","r")
	if not bmpath_find then

	local bmpath_make = io.open(minetest.get_worldpath().."/bloodmoon","w")
	bmpath_make:write("0")
	io.close(bmpath_make)	
	bmpath_find = io.open(minetest.get_worldpath().."/bloodmoon","r")

 	end	
io.close(bmpath_find)	

end

testventure.bloodmoon()


	local bloodmoontimer = 0
minetest.register_globalstep(function(dtime)
	local tod = minetest.get_timeofday()
	bloodmoontimer = bloodmoontimer + dtime;
	if bloodmoontimer >= 2.0 then
	if tod >= 0.8 or tod <= 0.2  then
		bloodmoontimer = 0
	local filepath = minetest.get_worldpath().."/progression"
	local prg = io.open(filepath, "r")
	if prg ~= nil then
	prgmode = prg:read("*l")
	prg:close()
	prgnum = prgmode + 0
		if prgnum > 0 then

	local filepath = minetest.get_worldpath().."/bloodmoon"
	local bloodmoon = io.open(filepath, "r")
	if bloodmoon ~= nil then
	bmmode = bloodmoon:read("*l")
	bloodmoon:close()
	bloodmoon_rised = bmmode + 0
		if bloodmoon_rised == 0 then
if math.random(1, 6) == 1 then
local filepath = minetest.get_worldpath().."/bloodmoon"
		local bloodmoon = io.open(filepath,"w")
		bloodmoon:write("1")
		bloodmoon:close(bloodmoon)
 minetest.chat_send_all("" ..core.colorize("#00df7e","The blood moon is rising..."))

	else
		if bloodmoon_rised == 0 then
local filepath = minetest.get_worldpath().."/bloodmoon"
		local bloodmoon = io.open(filepath,"w")
		bloodmoon:write("2")
		bloodmoon:close(bloodmoon)

end end end end end end end end end)

	local bmgonetimer = 0
minetest.register_globalstep(function(dtime, player)
	bmgonetimer = bmgonetimer + dtime;
	if bmgonetimer >= 5.0 then
	local tod = minetest.get_timeofday()
	 if tod <= 0.8 then
	 if tod >= 0.2 then
		bmgonetimer = 0
local filepath = minetest.get_worldpath().."/bloodmoon"
		local bloodmoon = io.open(filepath,"w")
		bloodmoon:write("0")
		bloodmoon:close(bloodmoon)
end end end end)

bmmobs = {
  "testventure:darkness_skeleton",
  "testventure:zombie",
  "testventure:blood_zombie",
  "testventure:demoneye",
}


minetest.register_abm({
	nodenames = {"default:dirt_with_grass","default:sand","default:dry_dirt_with_grass"},
	interval = 15,
	chance = 3500,

		action = function(pos, node)
	local filepath = minetest.get_worldpath().."/bloodmoon"
	local bloodmoon = io.open(filepath, "r")
	if bloodmoon ~= nil then
	bmmode = bloodmoon:read("*l")
	bloodmoon:close()
	bloodmoon_rised = bmmode + 0
		if bloodmoon_rised == 1 then

		pos.y = pos.y+3
	if minetest.get_node(pos).name == "air" then
	minetest.env:add_entity(pos, bmmobs[math.random(#bmmobs)])

	end end end end
})
