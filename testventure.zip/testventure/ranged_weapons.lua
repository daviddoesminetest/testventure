
--
-- bows
--

minetest.register_tool("testventure:bow_wooden", {
		description = "" ..core.colorize("#00eaff"," wooden bow\n")..core.colorize("#FFFFFF", "Ranged damage: 1-2\n")..core.colorize("#FFFFFF", "Accuracy: 80%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 10\n") ..core.colorize("#FFFFFF", "knockback: 3\n") ..core.colorize("#FFFFFF", "Critical chance: 3%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.8\n") ..core.colorize("#FFFFFF", "Projectile velocity: 18\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_wooden.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 800 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(1,2)
	bow_crit = 3
	bow_knockback = 3
	bow_accuracy = 80
	bow_gravity = 10
	bow_velocity = 18
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---darkwood bow---

minetest.register_tool("testventure:bow_darkwood", {
		description = "" ..core.colorize("#00eaff"," darkwood bow\n")..core.colorize("#FFFFFF", "Ranged damage: 2-3\n")..core.colorize("#FFFFFF", "Accuracy: 80%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 9\n") ..core.colorize("#FFFFFF", "knockback: 4\n") ..core.colorize("#FFFFFF", "Critical chance: 4%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.75\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_darkwood.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 750 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(2,3)
	bow_crit = 4
	bow_knockback = 4
	bow_accuracy = 80
	bow_gravity = 9
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---skywood bow---

minetest.register_tool("testventure:bow_skywood", {
		description = "" ..core.colorize("#00eaff"," skywood bow\n")..core.colorize("#FFFFFF", "Ranged damage: 3-5\n")..core.colorize("#FFFFFF", "Accuracy: 85%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 8\n") ..core.colorize("#FFFFFF", "knockback: 4\n") ..core.colorize("#FFFFFF", "Critical chance: 4%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.70\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_skywood.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 700 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(3,5)
	bow_crit = 4
	bow_knockback = 4
	bow_accuracy = 85
	bow_gravity = 8
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---copper bow---

minetest.register_tool("testventure:bow_copper", {
		description = "" ..core.colorize("#00eaff"," Copper bow\n")..core.colorize("#FFFFFF", "Ranged damage: 3-4\n")..core.colorize("#FFFFFF", "Accuracy: 85%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 8\n") ..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.70\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_copper.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 700 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(3,4)
	bow_crit = 5
	bow_knockback = 5
	bow_accuracy = 85
	bow_gravity = 8
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---tin bow---

minetest.register_tool("testventure:bow_tin", {
		description = "" ..core.colorize("#00eaff","Tin bow\n")..core.colorize("#FFFFFF", "Ranged damage: 3-4\n")..core.colorize("#FFFFFF", "Accuracy: 85%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 8\n") ..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.70\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_tin.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 700 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(3,4)
	bow_crit = 5
	bow_knockback = 5
	bow_accuracy = 85
	bow_gravity = 8
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---steel bow---

minetest.register_tool("testventure:bow_steel", {
		description = "" ..core.colorize("#00eaff"," Steel bow\n")..core.colorize("#FFFFFF", "Ranged damage: 3-5\n")..core.colorize("#FFFFFF", "Accuracy: 85%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 8\n") ..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.70\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_steel.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 700 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(3,5)
	bow_crit = 5
	bow_knockback = 5
	bow_accuracy = 85
	bow_gravity = 8
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---bronze bow---

minetest.register_tool("testventure:bow_bronze", {
		description = "" ..core.colorize("#00eaff","Bronze bow\n")..core.colorize("#FFFFFF", "Ranged damage: 3-5\n")..core.colorize("#FFFFFF", "Accuracy: 85%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 7.5\n") ..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.65\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_bronze.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 650 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(3,5)
	bow_crit = 5
	bow_knockback = 5
	bow_accuracy = 85
	bow_gravity = 7.5
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---gold bow---

minetest.register_tool("testventure:bow_gold", {
		description = "" ..core.colorize("#00eaff","Golden bow\n")..core.colorize("#FFFFFF", "Ranged damage: 4-7\n")..core.colorize("#FFFFFF", "Accuracy: 87%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 7.0\n") ..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.6\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_gold.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 600 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(4,7)
	bow_crit = 5
	bow_knockback = 5
	bow_accuracy = 87
	bow_gravity = 7.0
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---smaranium bow---

minetest.register_tool("testventure:bow_smaranium", {
		description = "" ..core.colorize("#00eaff","Smaranium bow\n")..core.colorize("#FFFFFF", "Ranged damage: 6-9\n")..core.colorize("#FFFFFF", "Accuracy: 89%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 6.5\n") ..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 6%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.6\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_smaranium.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 600 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(6,9)
	bow_crit = 6
	bow_knockback = 5
	bow_accuracy = 89
	bow_gravity = 6.5
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})


minetest.register_tool("testventure:bow_black_silver", {
		description = "" ..core.colorize("#00eaff","Black silver bow\n")..core.colorize("#FFFFFF", "Ranged damage: 10-17\n")..core.colorize("#FFFFFF", "Accuracy: 92%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 6.0\n") ..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 8%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.5\n") ..core.colorize("#FFFFFF", "Projectile velocity: 25\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.85,y=1.85,z=1.0},
	inventory_image = "testventure_bow_black_silver.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 500 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(10,17)
	bow_crit = 8
	bow_knockback = 5
	bow_accuracy = 92
	bow_gravity = 6.0
	bow_velocity = 25
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})



---sky bow---

minetest.register_tool("testventure:bow_sky", {
		description = "" ..core.colorize("#00eaff"," sky bow\n")..core.colorize("#FFFFFF", "Ranged damage: 5-14\n")..core.colorize("#FFFFFF", "Accuracy: 90%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 5\n") ..core.colorize("#FFFFFF", "knockback: 4\n") ..core.colorize("#FFFFFF", "Critical chance: 6%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 25\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.25,y=1.25,z=1.0},
	inventory_image = "testventure_bow_sky.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 400 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(5,14)
	bow_crit = 6
	bow_knockback = 4
	bow_accuracy = 90
	bow_gravity = 5
	bow_velocity = 25
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})


---tactical bow---

minetest.register_tool("testventure:bow_tactical", {
		description = "" ..core.colorize("#00eaff"," Tactical bow\n")..core.colorize("#FFFFFF", "Ranged damage: 9-16\n")..core.colorize("#FFFFFF", "Accuracy: 95%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 4\n") ..core.colorize("#FFFFFF", "knockback: 4\n") ..core.colorize("#FFFFFF", "Critical chance: 12%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.50\n") ..core.colorize("#FFFFFF", "Projectile velocity: 25\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.85,y=1.85,z=1.0},
	inventory_image = "testventure_bow_tactical.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 500 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(9,16)
	bow_crit = 12
	bow_knockback = 4
	bow_accuracy = 95
	bow_gravity = 4
	bow_velocity = 25
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---nightmare_injector bow---

minetest.register_tool("testventure:bow_nightmare_injector", {
		description = "" ..core.colorize("#00eaff"," Nightmare injector\n")..core.colorize("#FFFFFF", "Ranged damage: 7-13\n")..core.colorize("#FFFFFF", "Accuracy: 90%\n") ..core.colorize("#FFFFFF", "Projectile gravitational pull: 6\n") ..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 14%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.6\n") ..core.colorize("#FFFFFF", "Projectile velocity: 30\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.75,y=1.75,z=1.0},
	inventory_image = "testventure_bow_nightmare_injector.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 600 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(7,13)
	bow_crit = 14
	bow_knockback = 5
	bow_accuracy = 90
	bow_gravity = 6
	bow_velocity = 30
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.01
	bow_shoot(itemstack, user, pointed_thing)
	end end,
})

---frost bow---

minetest.register_tool("testventure:bow_frost", {
		description = "" ..core.colorize("#00eaff"," Frost bow\n")..core.colorize("#FFFFFF", "Ranged damage: 12-20\n")..core.colorize("#FFFFFF", "Accuracy: 94%\n") ..core.colorize("#FFFFFF", "Projectile gravitational pull: 5\n") ..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 10%\n") ..core.colorize("#FFFFFF", "Ammunition: Arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 30\n") ..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	wield_scale = {x=1.75,y=1.75,z=1.0},
	inventory_image = "testventure_bow_frost.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 400 then
	meta:set_int("cooldown", 0)
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(12,20)
	bow_crit = 10
	bow_knockback = 5
	bow_accuracy = 94
	bow_gravity = 5
	bow_velocity = 30
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.01
	bow_shoot(itemstack, user, pointed_thing)
	local dir = user:get_look_dir()
	local pos = user:getpos()
	pos.y = pos.y+1.5
	for i=1,10 do
	minetest.add_particle({
		pos = pos,
		velocity = {x=dir.x * 8, y=dir.y * 8, z=dir.z * 8} ,
          	acceleration = {x=math.random(-5,5), y=math.random(-5,5), z=math.random(-5,5)},
		expirationtime = 0.75,
		size = 3,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_frost_particle.png",
		glow = 100,
	})
	end
	end end,
})


--- arrowstorm

	minetest.register_craftitem("testventure:arrowstorm", {
	stack_max= 1,
	wield_scale = {x=2.0,y=2.0,z=1.25},
		description = "" ..core.colorize("#00eaff"," Arrowtorm\n")..core.colorize("#FFFFFF", "Ranged damage: 4-7\n")..core.colorize("#FFFFFF", "Accuracy: 50%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 9\n") ..core.colorize("#FFFFFF", "knockback: 2\n") ..core.colorize("#FFFFFF", "Critical chance: 7%\n") ..core.colorize("#FFFFFF", "Ammunition: arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.12\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n")..core.colorize("#FFFFFF", "35% chance not to consume ammo\n")..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your bow"),
	range = 0,
	inventory_image = "testventure_arrowstorm.png",
})
--- niobium_repeater

	minetest.register_craftitem("testventure:niobium_repeater", {
	stack_max= 1,
	wield_scale = {x=1.8,y=1.8,z=1.4},
		description = "" ..core.colorize("#2a00ff"," Niobium repeater\n")..core.colorize("#FFFFFF", "Ranged damage: 24-29\n")..core.colorize("#FFFFFF", "Accuracy: 85%\n")..core.colorize("#FFFFFF", "Projectile gravitational pull: 4\n") ..core.colorize("#FFFFFF", "knockback: 2\n") ..core.colorize("#FFFFFF", "Critical chance: 7%\n") ..core.colorize("#FFFFFF", "Ammunition: arrows\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.3\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n")..core.colorize("#ff6600", "Make sure the arrow in your inventory is next to your repeater"),
	range = 0,
	inventory_image = "testventure_niobium_repeater.png",
})

---
--- guns
---

--- flintlock pistol

minetest.register_tool("testventure:flintlock_pistol", {
		description = "" ..core.colorize("#00eaff"," flintlock pistol\n")..core.colorize("#FFFFFF", "Ranged damage: 4-7\n")..core.colorize("#FFFFFF", "Accuracy: 85%\n")..core.colorize("#FFFFFF", "knockback: 4\n") ..core.colorize("#FFFFFF", "Critical chance: 3%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.7\n") ..core.colorize("#FFFFFF", "Projectile velocity: 30\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_flintlock_pistol.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 700 then
	meta:set_int("cooldown", 0)
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(4,7)
	gun_crit = 3
	gun_knockback = 4
	gun_accuracy = 85
	gun_velocity = 30
	gun_sound = "testventure_weak_gun"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.01
	gun_shoot(itemstack, user, pointed_thing)
	end end,
})

minetest.register_tool("testventure:handgun", {
		description = "" ..core.colorize("#00eaff"," Handgun\n")..core.colorize("#FFFFFF", "Ranged damage: 5-10\n")..core.colorize("#FFFFFF", "Accuracy: 92%\n")..core.colorize("#FFFFFF", "knockback: 4\n") ..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 30\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_handgun.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 400 then
	meta:set_int("cooldown", 0)
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(5,10)
	gun_crit = 5
	gun_knockback = 4
	gun_accuracy = 92
	gun_velocity = 30
	gun_sound = "testventure_handgun"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.01
	gun_shoot(itemstack, user, pointed_thing)
	end end,
})

minetest.register_tool("testventure:golden_handgun", {
		description = "" ..core.colorize("#00eaff"," Golden handgun\n")..core.colorize("#FFFFFF", "Ranged damage: 9-13\n")..core.colorize("#FFFFFF", "Accuracy: 94%\n")..core.colorize("#FFFFFF", "knockback: 4\n") ..core.colorize("#FFFFFF", "Critical chance: 8%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.45\n") ..core.colorize("#FFFFFF", "Projectile velocity: 30\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_golden_handgun.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 450 then
	meta:set_int("cooldown", 0)
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(9,13)
	gun_crit = 8
	gun_knockback = 4
	gun_accuracy = 94
	gun_velocity = 30
	gun_sound = "testventure_handgun"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.01
	gun_shoot(itemstack, user, pointed_thing)
	end end,
})

--- shadow_eagle

minetest.register_tool("testventure:shadow_eagle", {
		description = "" ..core.colorize("#00eaff"," Shadow Eagle\n")..core.colorize("#FFFFFF", "Ranged damage: 12-22\n")..core.colorize("#FFFFFF", "Accuracy: 97%\n")..core.colorize("#FFFFFF", "knockback: 6\n") ..core.colorize("#FFFFFF", "Critical chance: 10%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.3\n") ..core.colorize("#FFFFFF", "Projectile velocity: 35\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	wield_scale = {x=1.5,y=1.5,z=1.5},
	inventory_image = "testventure_shadow_eagle.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 300 then
	meta:set_int("cooldown", 0)
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(12,22)
	gun_crit = 10
	gun_knockback = 6
	gun_accuracy = 97
	gun_velocity = 35
	gun_sound = "testventure_handgun"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.015
	gun_shoot(itemstack, user, pointed_thing)
	end end,
})

--- crimvolver

minetest.register_tool("testventure:crimvolver", {
		description = "" ..core.colorize("#00eaff"," Crimvolver\n")..core.colorize("#FFFFFF", "Ranged damage: 11-15\n")..core.colorize("#FFFFFF", "Accuracy: 94%\n")..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 13%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.2\n") ..core.colorize("#FFFFFF", "Projectile velocity: 35\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	wield_scale = {x=1.5,y=1.5,z=1.5},
	inventory_image = "testventure_crimvolver.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 200 then
	meta:set_int("cooldown", 0)
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(11,15)
	gun_crit = 13
	gun_knockback = 5
	gun_accuracy = 94
	gun_velocity = 35
	gun_sound = "testventure_handgun"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.015
	gun_shoot(itemstack, user, pointed_thing)
	end end,
})

--- rifle
minetest.register_tool("testventure:rifle", {
		description = "" ..core.colorize("#00eaff"," Rifle\n")..core.colorize("#FFFFFF", "Ranged damage: 19-28\n")..core.colorize("#FFFFFF", "Accuracy: 96%\n")..core.colorize("#FFFFFF", "knockback: 9\n") ..core.colorize("#FFFFFF", "Critical chance: 7%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 1.5\n") ..core.colorize("#FFFFFF", "Projectile velocity: 35\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	wield_scale = {x=1.75,y=1.75,z=1.0},
	inventory_image = "testventure_rifle.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 1500 then
	meta:set_int("cooldown", 0)
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(19,28)
	gun_crit = 7
	gun_knockback = 9
	gun_accuracy = 96
	gun_velocity = 35
	gun_sound = "testventure_rifle"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.015
	gun_shoot(itemstack, user, pointed_thing)
	end end,
})

--- shadow_rifle

minetest.register_tool("testventure:shadow_rifle", {
		description = "" ..core.colorize("#00eaff"," Shadow rifle\n")..core.colorize("#FFFFFF", "Ranged damage: 70-85\n")..core.colorize("#FFFFFF", "Accuracy: 98%\n")..core.colorize("#FFFFFF", "knockback: 15\n") ..core.colorize("#FFFFFF", "Critical chance: 20%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 2.0\n") ..core.colorize("#FFFFFF", "Projectile velocity: 38\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	wield_scale = {x=2.0,y=2.0,z=1.0},
	inventory_image = "testventure_shadow_rifle.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 2000 then
	meta:set_int("cooldown", 0)
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(70,85)
	gun_crit = 20
	gun_knockback = 15
	gun_accuracy = 98
	gun_velocity = 38
	gun_sound = "testventure_rifle"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.016
	gun_shoot(itemstack, user, pointed_thing)
	end end,
})

--- shotgun

minetest.register_tool("testventure:shotgun", {
		description = "" ..core.colorize("#00eaff"," Shotgun\n")..core.colorize("#FFFFFF", "Ranged damage: 8-12\n")..core.colorize("#FFFFFF", "Accuracy: 45%\n")..core.colorize("#FFFFFF", "knockback: 10\n") ..core.colorize("#FFFFFF", "Critical chance: 4%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 1.2\n") ..core.colorize("#FFFFFF", "Projectile velocity: 25\n")..core.colorize("#FFFFFF", "Shoots a spread of bullets\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	wield_scale = {x=2.0,y=2.0,z=1.5},
	inventory_image = "testventure_shotgun.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 1200 then
	meta:set_int("cooldown", 0)
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(8,12)
	gun_crit = 4
	gun_knockback = 10
	gun_accuracy = 45
	gun_velocity = 25
	gun_sound = "testventure_shotgun"
	shots_fired = 4
--------------------------------------
	bow_timer = 0.00
	gun_shoot(itemstack, user, pointed_thing)
	end end,
})

--- combat shotgun

minetest.register_tool("testventure:combat_shotgun", {
		description = "" ..core.colorize("#2a00ff","Combat shotgun\n")..core.colorize("#FFFFFF", "Ranged damage: 10-15\n")..core.colorize("#FFFFFF", "Accuracy: 55%\n")..core.colorize("#FFFFFF", "knockback: 10\n") ..core.colorize("#FFFFFF", "Critical chance: 6%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 1.0\n") ..core.colorize("#FFFFFF", "Projectile velocity: 25\n")..core.colorize("#FFFFFF", "Shoots a spread of bullets\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	wield_scale = {x=2.0,y=2.0,z=1.5},
	inventory_image = "testventure_combat_shotgun.png",
on_use = function(itemstack, user, pointed_thing)
	meta = user:get_meta()
 	c_down = meta:get_int("cooldown") or 0
	if c_down > 1000 then
	meta:set_int("cooldown", 0)
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(10,15)
	gun_crit = 6
	gun_knockback = 10
	gun_accuracy = 55
	gun_velocity = 25
	gun_sound = "testventure_shotgun"
	shots_fired = 5
--------------------------------------
	bow_timer = 0.00
	gun_shoot(itemstack, user, pointed_thing)
	end end,
})



--- machinetrout

	minetest.register_craftitem("testventure:machinetrout", {
	stack_max= 1,
	wield_scale = {x=2.0,y=2.0,z=3.0},
		description = "" ..core.colorize("#00eaff"," Machinetrout\n")..core.colorize("#FFFFFF", "Ranged damage: 1-4\n")..core.colorize("#FFFFFF", "Accuracy: 70%\n")..core.colorize("#FFFFFF", "knockback: 1\n") ..core.colorize("#FFFFFF", "Critical chance: 2%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.08\n") ..core.colorize("#FFFFFF", "Projectile velocity: 25\n")..core.colorize("#FFFFFF", "33% chance not to consume ammo\n")..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	inventory_image = "testventure_machinetrout.png",
})

--- quick_end

	minetest.register_craftitem("testventure:quick_end", {
	stack_max= 1,
	wield_scale = {x=1.0,y=1.0,z=1.0},
		description = "" ..core.colorize("#00eaff"," Quick end\n")..core.colorize("#FFFFFF", "Ranged damage: 3-7\n")..core.colorize("#FFFFFF", "Accuracy: 60%\n")..core.colorize("#FFFFFF", "knockback: 1\n") ..core.colorize("#FFFFFF", "Critical chance: 3%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.07\n") ..core.colorize("#FFFFFF", "Projectile velocity: 25\n") ..core.colorize("#FFFFFF", "25% chance not to consume ammo\n") ..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	inventory_image = "testventure_quick_end.png",
})
--- niobium_machinegun

	minetest.register_craftitem("testventure:niobium_machinegun", {
	stack_max= 1,
	wield_scale = {x=1.8,y=1.8,z=1.4},
		description = "" ..core.colorize("#2a00ff"," Niobium machinegun\n")..core.colorize("#FFFFFF", "Ranged damage: 12-17\n")..core.colorize("#FFFFFF", "Accuracy: 75%\n")..core.colorize("#FFFFFF", "knockback: 1\n") ..core.colorize("#FFFFFF", "Critical chance: 6%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.125\n") ..core.colorize("#FFFFFF", "Projectile velocity: 25\n")..core.colorize("#FFFFFF", "20% chance not to consume ammo\n")..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	inventory_image = "testventure_niobium_machinegun.png",
})
--- comrad_kalashnikov

	minetest.register_craftitem("testventure:comrad_kalashnikov", {
	stack_max= 1,
	wield_scale = {x=2.0,y=2.0,z=1.0},
		description = "" ..core.colorize("#00eaff"," Comrad Kalashnikov\n")..core.colorize("#FFFFFF", "Ranged damage: 8-13\n")..core.colorize("#FFFFFF", "Accuracy: 80%\n")..core.colorize("#FFFFFF", "knockback: 3\n") ..core.colorize("#FFFFFF", "Critical chance: 8%\n") ..core.colorize("#FFFFFF", "Ammunition: bullets\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.15\n") ..core.colorize("#FFFFFF", "Projectile velocity: 30\n")..core.colorize("#ff6600", "Make sure the bullet in your inventory is next to your gun"),
	range = 0,
	inventory_image = "testventure_comrad_kalashnikov.png",
})

minetest.register_globalstep(function(dtime, player)
	for _, player in pairs(minetest.get_connected_players()) do
 meta = player:get_meta()
 c_down = meta:get_int("cooldown") or 0
			local inv = player:get_inventory()
			local controls = player:get_player_control()
			if controls.LMB then
	local wielded_item = player:get_wielded_item():get_name()

---
--- auto shooting
---

if wielded_item == "testventure:arrowstorm" then
	if c_down >= 100 then
--------------------------------------
	bow_ammo_save = 35
	bow_damage = math.random(4,7)
	bow_crit = 7
	bow_knockback = 2
	bow_accuracy = 50
	bow_gravity = 9
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
auto_bow_shoot(itemstack, player)
	
		meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:niobium_repeater" then
	if c_down >= 300 then
--------------------------------------
	bow_ammo_save = 0
	bow_damage = math.random(24,29)
	bow_crit = 7
	bow_knockback = 2
	bow_accuracy = 85
	bow_gravity = 4
	bow_velocity = 20
	bow_sound = "testventure_throw"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
auto_bow_shoot(itemstack, player)
	
		meta:set_int("cooldown", 0)
end end 


---
--- gun shooting
---

if wielded_item == "testventure:machinetrout" then
	if c_down >= 80 then
--------------------------------------
	gun_ammo_save = 33
	gun_damage = math.random(1,4)
	gun_crit = 2
	gun_knockback = 1
	gun_accuracy = 70
	gun_velocity = 25
	gun_sound = "testventure_weak_gun"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
auto_gun_shoot(itemstack, player)
	
	meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:quick_end" then
	if c_down >= 70 then
--------------------------------------
	gun_ammo_save = 25
	gun_damage = math.random(3,7)
	gun_crit = 3
	gun_knockback = 1
	gun_accuracy = 60
	gun_velocity = 25
	gun_sound = "testventure_weak_gun"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
auto_gun_shoot(itemstack, player)
	
	meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:niobium_machinegun" then
	if c_down >= 125 then
--------------------------------------
	gun_ammo_save = 20
	gun_damage = math.random(12,17)
	gun_crit = 6
	gun_knockback = 1
	gun_accuracy = 75
	gun_velocity = 25
	gun_sound = "testventure_machinegun"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.0
auto_gun_shoot(itemstack, player)
	
	meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:comrad_kalashnikov" then
	if c_down >= 150 then
--------------------------------------
	gun_ammo_save = 0
	gun_damage = math.random(8,13)
	gun_crit = 8
	gun_knockback = 3
	gun_accuracy = 80
	gun_velocity = 30
	gun_sound = "testventure_machinegun"
	shots_fired = 1
--------------------------------------
	bow_timer = 0.01
auto_gun_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

---
--- magic
---

if wielded_item == "testventure:blood_scepter" then
	if c_down >= 100 then
--------------------------------------
	mana_cost = 14
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 4
	projectile_sound = "testventure_waterspray"
	the_projectile = "testventure:blood_ray"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:oceanic_trident" then
	if c_down >= 100 then
--------------------------------------
	mana_cost = 9
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 4
	projectile_sound = "testventure_waterspray"
	the_projectile = "testventure:water_ray"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:amethyst_staff" then
	if c_down >= 400 then
--------------------------------------
	mana_cost = 12
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 0
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:amethyst_ray"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:topaz_staff" then
	if c_down >= 400 then
--------------------------------------
	mana_cost = 14
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 0
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:topaz_ray"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:emerald_staff" then
	if c_down >= 400 then
--------------------------------------
	mana_cost = 17
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 0
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:emerald_ray"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:sapphire_staff" then
	if c_down >= 400 then
--------------------------------------
	mana_cost = 21
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 0
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:sapphire_ray"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:ruby_staff" then
	if c_down >= 400 then
--------------------------------------
	mana_cost = 30
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 0
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:ruby_ray"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:diamond_staff" then
	if c_down >= 400 then
--------------------------------------
	mana_cost = 40
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 0
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:diamond_ray"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

if wielded_item == "testventure:niobium_staff" then
	if c_down >= 300 then
--------------------------------------
	mana_cost = 35
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 0
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:niobium_ray"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end 

---
--- melee rays
---

if wielded_item == "testventure:endarkener" then
	if c_down >= 1200 then
--------------------------------------
	mana_cost = 0
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 5
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:darkness_projectile"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end

if wielded_item == "testventure:swordsicle" then
	if c_down >= 800 then
--------------------------------------
	mana_cost = 0
	projectile_accuracy = 100
	projectile_velocity = 20
	projectile_gravity = 0
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:frost_projectile"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end

if wielded_item == "testventure:energy_sword" then
	if c_down >= 650 then
--------------------------------------
	mana_cost = 0
	projectile_accuracy = 100
	projectile_velocity = 16
	projectile_gravity = 0
	projectile_sound = "testventure_throw"
	the_projectile = "testventure:energy_projectile"
	shots_fired = 1
--------------------------------------
projectile_shoot(itemstack, player)
		meta:set_int("cooldown", 0)
end end

end end end)


