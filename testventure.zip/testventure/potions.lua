minetest.register_on_joinplayer(function(player)
	meta = player:get_meta()
if not meta:get_int("grav_mode") then
meta:set_int("grav_mode",0)
end
end)


minetest.register_node("testventure:potionglow", {
		description = "" ..core.colorize("#00eaff","Potion glow\n") ..core.colorize("#FFFFFF", "YOU HACKER, YOU!"),
	drawtype = "airlike",
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	pointable = false,
	sunlight_propagates = true,
	light_source = 13,
	on_construct = function(pos)
		minetest.get_node_timer(pos):start(1.0)
	end,
	on_timer = function(pos, elapsed)
		minetest.swap_node(pos, {name = "air"})
	end,
	drop = "",
	groups = {snappy = 3, not_in_creative_inventory=1},
})


--mana
minetest.register_craftitem("testventure:mana_potion_small", {
		description = "" ..core.colorize("#00eaff","Small mana potion\n") ..core.colorize("#FFFFFF", "Restores 100 mp"),
	stack_max= 25,
	inventory_image = "testventure_mana_potion_small.png",
on_use = function(itemstack, user, pointed_thing)
 itemstack:take_item()
mana.add_up_to(user:get_player_name(), 100)
		return itemstack
	end, 
})
minetest.register_craftitem("testventure:mana_potion", {
		description = "" ..core.colorize("#00eaff","Mana potion\n") ..core.colorize("#FFFFFF", "Restores 200 mp"),
	stack_max= 25,
	inventory_image = "testventure_mana_potion.png",
on_use = function(itemstack, user, pointed_thing)
 itemstack:take_item()
mana.add_up_to(user:get_player_name(), 200)
		return itemstack
	end, 
})
minetest.register_craftitem("testventure:mana_potion_large", {
		description = "" ..core.colorize("#00eaff","Large mana potion\n") ..core.colorize("#FFFFFF", "Restores 500 mp"),
	stack_max= 25,
	inventory_image = "testventure_mana_potion_large.png",
on_use = function(itemstack, user, pointed_thing)
 itemstack:take_item()
mana.add_up_to(user:get_player_name(), 500)
		return itemstack
	end, 
})

--
-- teleportation
--


minetest.register_craftitem("testventure:teleportation_potion", {
		description = "" ..core.colorize("#00eaff","Teleportation potion\n") ..core.colorize("#FFFFFF", "Will teleport you somewhere... IT COULD NEARLY ANYWHERE! use at your own risk!"),
	stack_max= 25,
	inventory_image = "testventure_teleportation_potion.png",
on_use = function(itemstack, user, pointed_thing, pos)
 itemstack:take_item()
	local pos = user:getpos()
	for i=1,50 do
	minetest.add_particle({
		pos = pos,
		acceleration = 0,
          	velocity = {x=math.random(-2, 2), y=math.random(-2, 2), z=math.random(-2, 2)},
		size = 2, 
		expirationtime = 2.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_energy_particle_d.png",
		glow = 30,
	})
	end
	local pos ={x=math.random(-30000, 30000), y=math.random(-1000, 1000), z=math.random(-30000, 30000)}
		user:setpos(pos)
	for i=1,50 do
	minetest.add_particle({
		pos = pos,
		acceleration = 0,
          	velocity = {x=math.random(-2, 2), y=math.random(-2, 2), z=math.random(-2, 2)},
		size = 2, 
		expirationtime = 2.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_energy_particle_d.png",
		glow = 30,
	})
	end
		return itemstack
	end,
})


--
-- recall
--


minetest.register_craftitem("testventure:recall_potion", {
		description = "" ..core.colorize("#00eaff","Recall potion\n") ..core.colorize("#FFFFFF", "Will teleport you to your last sleeping spot or to x0 y16 z0 if you had never slept"),
	stack_max= 25,
	inventory_image = "testventure_recall_potion.png",
on_use = function(itemstack, user, pointed_thing, pos)
 itemstack:take_item()
	local pos = user:getpos()
	for i=1,50 do
	minetest.add_particle({
		pos = pos,
		acceleration = 0,
          	velocity = {x=math.random(-2, 2), y=math.random(-2, 2), z=math.random(-2, 2)},
		size = 2, 
		expirationtime = 2.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_energy_particle_a.png",
		glow = 30,
	})
	end
	local name = user:get_player_name()
	local pos = beds.spawn[name] or {x=0, y=16, z=0}
	for i=1,50 do
	minetest.add_particle({
		pos = pos,
		acceleration = 0,
          	velocity = {x=math.random(-2, 2), y=math.random(-2, 2), z=math.random(-2, 2)},
		size = 2, 
		expirationtime = 2.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_energy_particle_a.png",
		glow = 30,
	})
	end
		user:setpos(pos)

		return itemstack
	end,
})


---
--- swiftness
---




minetest.register_craftitem("testventure:swiftness_potion", {
		description = "" ..core.colorize("#00eaff","Swiftness potion\n") ..core.colorize("#FFFFFF", "Increases walking speed by 75% for 180 seconds"),
	stack_max= 25,
	inventory_image = "testventure_swiftness_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("swiftness", 180, user)
		return itemstack
	end, true
})

playereffects.register_effect_type("swiftness",("Swiftness"), "testventure_swiftness_icon.png", {"speed"},
	function(player)
		local meta = player:get_meta()
walk_speed = meta:get_int("walkspeed") or 1
meta:set_int("walkspeed", walk_speed + 75)
	end,
	function(effect, player)
		local meta = player:get_meta()
walk_speed = meta:get_int("walkspeed") or 1
meta:set_int("walkspeed", 0)
	end
)

---
--- jumping
---

minetest.register_craftitem("testventure:jumping_potion", {
		description = "" ..core.colorize("#00eaff","Jumping potion\n") ..core.colorize("#FFFFFF", "Increases jumping force  by 90% for 180 secs"),
	stack_max= 25,
	inventory_image = "testventure_jumping_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("jumping", 180, user)
		return itemstack
	end, true
})

playereffects.register_effect_type("jumping",("jumping"), "testventure_jumping_icon.png", {"jump"},
	function(player)
		local name = player:get_player_name()
		local base_jump = armor.def[name].jump
		player:set_physics_override({jump=base_jump*1.9})
	end,
	function(effect, player)
		local name = player:get_player_name()
		local base_jump = armor.def[name].jump
		player:set_physics_override({jump=base_jump*1})
	end
)



---
--- glowing
---


minetest.register_craftitem("testventure:glowing_potion", {
		description = "" ..core.colorize("#00eaff","Glowing potion\n") ..core.colorize("#FFFFFF", "Will make you glow for 180 seconds"),
	stack_max= 25,
	inventory_image = "testventure_glowing_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_glowing", 180, user)
		return itemstack
	end, true
})

testventure.glowing = {}

function testventure.enable_glowing(playername)
	testventure.glowing[playername] = true
end

function testventure.disable_glowing(playername)
	testventure.glowing[playername] = false
end

playereffects.register_effect_type("testventure_glowing",("glowing"), "testventure_glowing_icon.png", {"glowing"},
	function(player)
		testventure.enable_glowing(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_glowing(player:get_player_name())
	end
)

local gtimer = 0
minetest.register_globalstep(function(dtime, player)
	gtimer = gtimer + dtime;
	if gtimer >=0.50 then
	for _, player in pairs(minetest.get_connected_players()) do
	for playername, has_glowing in pairs(testventure.glowing) do
			if has_glowing then
		gtimer = 0
	gpos = player:getpos()
	gpos.y = gpos.y+1
local node = minetest.get_node(gpos)
if node.name == "air" or
   node.name == "testventure:potionglow" then

minetest.set_node(gpos, {name = "testventure:potionglow"})
minetest.get_node_timer(gpos):start(1.0)
end

	gpos.y = gpos.y+1
local node = minetest.get_node(gpos)
if node.name == "air" or
   node.name == "testventure:potionglow" then

minetest.set_node(gpos, {name = "testventure:potionglow"})
minetest.get_node_timer(gpos):start(1.0)
end

	gpos.y = gpos.y+1
local node = minetest.get_node(gpos)
if node.name == "air" or
   node.name == "testventure:potionglow" then

minetest.set_node(gpos, {name = "testventure:potionglow"})
minetest.get_node_timer(gpos):start(1.0)



end end end end end end)

---
--- ironskin
---

testventure.ironskin = {}

function testventure.enable_ironskin(playername)
	testventure.ironskin[playername] = true
end

function testventure.disable_ironskin(playername)
	testventure.ironskin[playername] = false
end

playereffects.register_effect_type("testventure_ironskin",("Ironskin"), "testventure_ironskin_icon.png", {"ironskin"},
	function(player)
		testventure.enable_ironskin(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_ironskin(player:get_player_name())
	end
)


minetest.register_craftitem("testventure:ironskin_potion", {
		description = "" ..core.colorize("#00eaff","Iron skin potion\n") ..core.colorize("#FFFFFF", "Reduces taken damage by 2, for 90 seconds"),
	stack_max= 25,
	inventory_image = "testventure_ironskin_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_ironskin", 90, user)
		return itemstack
	end, true
})

---
--- strenght
---

testventure.strenght = {}

function testventure.enable_strenght(playername)
	testventure.strenght[playername] = true
end

function testventure.disable_strenght(playername)
	testventure.strenght[playername] = false
end

playereffects.register_effect_type("testventure_strenght",("strenght"), "testventure_strenght_icon.png", {"strenght"},
	function(player)
		testventure.enable_strenght(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_strenght(player:get_player_name())
	end
)


minetest.register_craftitem("testventure:strenght_potion", {
		description = "" ..core.colorize("#00eaff","Strenght potion\n") ..core.colorize("#FFFFFF", "Increases melee damage by 50%, for 180 seconds"),
	stack_max= 25,
	inventory_image = "testventure_strenght_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_strenght", 180, user)
		return itemstack
	end, true
})

---
--- sharpshooting
---


minetest.register_craftitem("testventure:sharpshooting_potion", {
		description = "" ..core.colorize("#00eaff","sharpshooting potion\n") ..core.colorize("#FFFFFF", "Increases ranged damage by 40%, for 180 seconds"),
	stack_max= 25,
	inventory_image = "testventure_sharpshooting_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("sharpshooting", 180, user)
		return itemstack
	end, true
})

playereffects.register_effect_type("sharpshooting",("sharpshooting"), "testventure_sharpshooting_icon.png", {"sharpshooting"},
	function(player)
		local meta = player:get_meta()
r_dam = meta:get_int("ranged_dmg_meta") or 1
meta:set_int("ranged_dmg_meta", r_dam + 40)
	end,
	function(effect, player)
		local meta = player:get_meta()
r_dam = meta:get_int("ranged_dmg_meta") or 1
meta:set_int("ranged_dmg_meta", 0)
meta:set_int("srd_applied", 0)

	end
)

---
--- force
---

testventure.force = {}

function testventure.enable_force(playername)
	testventure.force[playername] = true
end

function testventure.disable_force(playername)
	testventure.force[playername] = false
end

playereffects.register_effect_type("testventure_force",("force"), "testventure_force_icon.png", {"force"},
	function(player)
		testventure.enable_force(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_force(player:get_player_name())
	end
)


minetest.register_craftitem("testventure:force_potion", {
		description = "" ..core.colorize("#00eaff","force potion\n") ..core.colorize("#FFFFFF", "Increases melee knockback by 100%, for 180 seconds"),
	stack_max= 25,
	inventory_image = "testventure_force_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_force", 180, user)
		return itemstack
	end, true
})


---
--- regen
---

testventure.regen = {}

function testventure.enable_regen(playername)
	testventure.regen[playername] = true
end

function testventure.disable_regen(playername)
	testventure.regen[playername] = false
end

playereffects.register_effect_type("testventure_regen",("Regeneration"), "testventure_regen_icon.png", {"regen"},
	function(player)
		testventure.enable_regen(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_regen(player:get_player_name())
	end
)


minetest.register_craftitem("testventure:regen_potion", {
		description = "" ..core.colorize("#00eaff","Regeneration potion\n") ..core.colorize("#FFFFFF", "Restores 0.5 hp every second for 120 seconds"),
	stack_max= 25,
	inventory_image = "testventure_regen_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_regen", 120, user)
		return itemstack
	end, true
})

---
--- antigravity
---

testventure.antigravity = {}

function testventure.enable_antigravity(playername)
	testventure.antigravity[playername] = true
end

function testventure.disable_antigravity(playername)
	testventure.antigravity[playername] = false
end

playereffects.register_effect_type("testventure_antigravity",("Gravity control"), "testventure_antigravity_icon.png", {"antigravity"},
	function(player)
		testventure.enable_antigravity(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_antigravity(player:get_player_name())
		local name = player:get_player_name()
		local base_gravity = armor.def[name].gravity
		player:set_physics_override({gravity=base_gravity*1})
	player:hud_change(grav, "text","testventure_invisible.png")
	end
)


minetest.register_craftitem("testventure:antigravity_potion", {
		description = "" ..core.colorize("#00eaff","antigravity potion\n") ..core.colorize("#FFFFFF", "Allows you to flip your gravity by jumping, for 120 seconds, BE CAREFUL THO!"),
	stack_max= 25,
	inventory_image = "testventure_antigravity_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_antigravity", 120, user)
		return itemstack
	end, true
})

local timer = 0
minetest.register_globalstep(function(dtime, player, pos)
	timer = timer + dtime;
	if timer >=0.30 then
	for _, player in pairs(minetest.get_connected_players()) do
	for playername, has_antigravity in pairs(testventure.antigravity) do
			if has_antigravity then
		local controls = player:get_player_control()
		if controls.jump then
		timer = 0
	minetest.sound_play("testventure_throw", {player})
	local pos = player:getpos()
	for i=1,40 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-10, 10), y=math.random(-10, 10), z=math.random(-10, 10)},
		size = math.random(5, 8), 
		expirationtime = 2.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_shadow_particle.png",
		glow = 30,
	})
	end
	meta = player:get_meta()
local grav_mode = meta:get_int("grav_mode") or 0
	if grav_mode == 0 then meta:set_int("grav_mode", 1)
	player:set_physics_override({gravity=-0.5})
	player:hud_change(grav, "text","testventure_grav_up.png")
	end
	if grav_mode == 1 then meta:set_int("grav_mode", 0)
	player:set_physics_override({gravity=0.5})
	player:hud_change(grav, "text","testventure_grav_down.png")
	end
end
end
end
end
end
	end)


---
--- manaregen
---

testventure.manaregen = {}

function testventure.enable_manaregen(playername)
	testventure.manaregen[playername] = true
end

function testventure.disable_manaregen(playername)
	testventure.manaregen[playername] = false
end

playereffects.register_effect_type("testventure_manaregen",("Mana regeneration"), "testventure_manaregen_icon.png", {"manaregen"},
	function(player)
		testventure.enable_manaregen(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_manaregen(player:get_player_name())
	end
)


minetest.register_craftitem("testventure:manaregen_potion", {
		description = "" ..core.colorize("#00eaff","Mana regeneration potion\n") ..core.colorize("#FFFFFF", "Restores 10 MP every second for 120 seconds"),
	stack_max= 25,
	inventory_image = "testventure_manaregen_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_manaregen", 120, user)
		return itemstack
	end, true
})

local timer = 0
minetest.register_globalstep(function(dtime, player)
	timer = timer + dtime;
	if timer >=1.00 then
	for _, player in pairs(minetest.get_connected_players()) do
	for playername, has_manaregen in pairs(testventure.manaregen) do
			if has_manaregen then
		timer = 0
mana.add(player:get_player_name(), 10)
end
end
end
end
	end)



---
--- spelunkin
---

testventure.spelunkin = {}

function testventure.enable_spelunkin(playername)
	testventure.spelunkin[playername] = true
end

function testventure.disable_spelunkin(playername)
	testventure.spelunkin[playername] = false
end

playereffects.register_effect_type("testventure_spelunkin",("spelunkin"), "testventure_spelunkin_icon.png", {"spelunkin"},
	function(player)
		testventure.enable_spelunkin(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_spelunkin(player:get_player_name())
	end
)


minetest.register_craftitem("testventure:spelunkin_potion", {
		description = "" ..core.colorize("#00eaff","spelunker potion\n") ..core.colorize("#FFFFFF", "Exposes nearest minerals and treasures for 300 seconds"),
	stack_max= 25,
	inventory_image = "testventure_spelunkin_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_spelunkin", 300, user)
		return itemstack
	end, true
})

default_ores = {
  "default:stone_with_coal",
  "default:stone_with_iron",
  "default:stone_with_tin",
  "default:stone_with_copper",
  "default:stone_with_diamond",
  "default:stone_with_mese",
  "default:stone_with_gold",
}

treasures = {
  "testventure:treasure",
  "testventure:swordstone",
  "testventure:silver_heart",
}

local timer = 0
minetest.register_globalstep(function(dtime, player, pos)
	timer = timer + dtime;
	if timer >=2.00 then
	for _, player in pairs(minetest.get_connected_players()) do
	for playername, has_spelunkin in pairs(testventure.spelunkin) do
			if has_spelunkin then
			timer = 0
			local pos = player:getpos()
local defaultpos = minetest.find_node_near(pos, 20,default_ores)
	for i=1,20 do
	minetest.add_particle({
		pos = defaultpos,
		acceleration = 0,
          	velocity = {x=math.random(-1, 1), y=math.random(-1, 1), z=math.random(-1, 1)},
		size = 2, 
		expirationtime = 4.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_default_ore_shine.png",
		glow = 30,
	})
	end
local commonpos = minetest.find_node_near(pos, 20, "group:common_ore" )
	for i=1,20 do
	minetest.add_particle({
		pos = commonpos,
		acceleration = 0,
          	velocity = {x=math.random(-1, 1), y=math.random(-1, 1), z=math.random(-1, 1)},
		size = 2, 
		expirationtime = 4.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_common_ore_shine.png",
		glow = 30,
	})
	end
local uncommonpos = minetest.find_node_near(pos, 20, "group:uncommon_ore")
	for i=1,20 do
	minetest.add_particle({
		pos = uncommonpos,
		acceleration = 0,
          	velocity = {x=math.random(-1, 1), y=math.random(-1, 1), z=math.random(-1, 1)},
		size = 2, 
		expirationtime = 4.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_uncommon_ore_shine.png",
		glow = 30,
	})
	end
local rarepos = minetest.find_node_near(pos, 20, "group:rare_ore")
	for i=1,20 do
	minetest.add_particle({
		pos = rarepos,
		acceleration = 0,
          	velocity = {x=math.random(-1, 1), y=math.random(-1, 1), z=math.random(-1, 1)},
		size = 2, 
		expirationtime = 4.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_rare_ore_shine.png",
		glow = 30,
	})
	end
local progresspos = minetest.find_node_near(pos, 20, "group:progress_ore")
	for i=1,20 do
	minetest.add_particle({
		pos = progresspos,
		acceleration = 0,
          	velocity = {x=math.random(-1, 1), y=math.random(-1, 1), z=math.random(-1, 1)},
		size = 2, 
		expirationtime = 4.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_progress_ore_shine.png",
		glow = 30,
	})
	end
local treasurepos = minetest.find_node_near(pos, 20, treasures)
	for i=1,20 do
	minetest.add_particle({
		pos = treasurepos,
		acceleration = 0,
          	velocity = {x=math.random(-1, 1), y=math.random(-1, 1), z=math.random(-1, 1)},
		size = 2, 
		expirationtime = 4.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_treasure_shine.png",
		glow = 30,
	})
	end
end	
end
end
end
	end)

---
--- mining
---

testventure.mining = {}

function testventure.enable_mining(playername)
	testventure.mining[playername] = true
end

function testventure.disable_mining(playername)
	testventure.mining[playername] = false
end

playereffects.register_effect_type("testventure_mining",("mining"), "testventure_mining_icon.png", {"mining"},
	function(player)
		testventure.enable_mining(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_mining(player:get_player_name())
	end
)


minetest.register_craftitem("testventure:mining_potion", {
		description = "" ..core.colorize("#00eaff","Mining potion\n") ..core.colorize("#FFFFFF", "Gives 25% chance of doubling mined ores for 300 seconds"),
	stack_max= 25,
	inventory_image = "testventure_mining_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_mining", 300, user)
		return itemstack
	end, true
})

minetest.register_on_dignode(function(pos, oldnode, digger)
	if digger ~= nil and digger:is_player() then
	if math.random(1, 4) == 1 then
local name = oldnode.name
	is_ore = minetest.get_item_group(name, "is_ore")
	if oldnode.name == "default:stone_with_coal" 
	or oldnode.name == "default:stone_with_iron" 
	or oldnode.name == "default:stone_with_copper" 
	or oldnode.name == "default:stone_with_tin" 
	or oldnode.name == "default:stone_with_gold" 
	or oldnode.name == "default:stone_with_diamond" 
	or oldnode.name == "default:stone_with_mese"  
	or is_ore > 0 
	then

	for _, digger in pairs(minetest.get_connected_players()) do
for playername, has_mining in pairs	(testventure.mining) do
			if has_mining then
	local droppeditm = minetest.get_node_drops(oldnode)
	for _, itemname in ipairs(droppeditm) do 
		minetest.add_item(pos, itemname)
	for i=1,20 do
	minetest.add_particle({
		pos = pos,
		acceleration = {x=math.random(-1, 1), y=math.random(-10, -5), z=math.random(-1, 1)},
          	velocity = {x=math.random(-2, 2), y=math.random(2, 6), z=math.random(-2, 2)},
		size = 1.25, 
		expirationtime = 3.0,
		collisiondetection = true,
		vertical = false,
		texture = "testventure_treasure_shine.png",
		glow = 30,
	})
	end
		end
		end
		end
		end
		end
		end
	end
end)

---
--- invincibility
---

testventure.invincibility = {}

function testventure.enable_invincibility(playername)
	testventure.invincibility[playername] = true
end

function testventure.disable_invincibility(playername)
	testventure.invincibility[playername] = false
end

playereffects.register_effect_type("testventure_invincibility",("invincibility"), "testventure_invincibility_icon.png", {"invincibility"},
	function(player)
		testventure.enable_invincibility(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_invincibility(player:get_player_name())
	end
)


minetest.register_craftitem("testventure:invincibility_potion", {
		description = "" ..core.colorize("#00eaff","Invincibility potion\n") ..core.colorize("#FFFFFF", "Makes you invincible for 7 seconds, but gives 20 secs of healing cooldown\n")..core.colorize("#FFFFFF", "Can't be used during healing cooldown"),

	stack_max= 25,
	inventory_image = "testventure_invincibility_potion.png",
on_use = function(itemstack, user, pointed_thing)
		 meta = user:get_meta()
		 heal_cooldown = meta:get_int("heal_cooldown") or 0
	if heal_cooldown < 1 then
 itemstack:take_item()
playereffects.apply_effect_type("testventure_invincibility", 7, user)
	meta:set_int("heal_cooldown", 20)
		return itemstack
	end end, true
})

---
--- oxygen
---

testventure.oxygen = {}

function testventure.enable_oxygen(playername)
	testventure.oxygen[playername] = true
end

function testventure.disable_oxygen(playername)
	testventure.oxygen[playername] = false
end

playereffects.register_effect_type("testventure_oxygen",("Full of oxygen"), "testventure_oxygen_icon.png", {"oxygen"},
	function(player)
		testventure.enable_oxygen(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_oxygen(player:get_player_name())
	end
)


minetest.register_craftitem("testventure:oxygen_potion", {
		description = "" ..core.colorize("#00eaff","Oxygen potion\n") ..core.colorize("#FFFFFF", "Prevents you from drowning for 90 secs"),
	stack_max= 25,
	inventory_image = "testventure_oxygen_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_oxygen", 90, user)
		return itemstack
	end, true
})

local timer = 0
minetest.register_globalstep(function(dtime, player)
	timer = timer + dtime;
	if timer >=1.00 then
	for _, player in pairs(minetest.get_connected_players()) do
	for playername, has_oxygen in pairs(testventure.oxygen) do
			if has_oxygen then
		timer = 0
			air = player:get_breath()  
			air = air+1
			player:set_breath(tonumber(air))
end
end
end
end
	end)

---
--- featherweight
---

minetest.register_craftitem("testventure:featherweight_potion", {
		description = "" ..core.colorize("#00eaff","Featherweight potion\n") ..core.colorize("#FFFFFF", "Reduces your gravity to 15% for 120 secs"),
	stack_max= 25,
	inventory_image = "testventure_featherweight_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("featherweight", 120, user)
		return itemstack
	end, true
})

playereffects.register_effect_type("featherweight",("featherweight"), "testventure_featherweight_icon.png", {"grav"},
	function(player)
		local name = player:get_player_name()
		player:set_physics_override({gravity=0.15})
	end,
	function(effect, player)
		local name = player:get_player_name()
		local base_grav = armor.def[name].gravity
		player:set_physics_override({gravity=base_grav*1})
	end
)

---
--wealth--
---

testventure.wealth = {}

function testventure.enable_wealth(playername)
	testventure.wealth[playername] = true
end

function testventure.disable_wealth(playername)
	testventure.wealth[playername] = false
end

playereffects.register_effect_type("testventure_wealth",("wealth"), "testventure_wealth_icon.png", {"wealth"},
	function(player)
		testventure.enable_wealth(player:get_player_name())
	end,
	function(effect, player)
		testventure.disable_wealth(player:get_player_name())
	end
)

minetest.register_craftitem("testventure:wealth_potion", {
		description = "" ..core.colorize("#00eaff","wealth potion\n") ..core.colorize("#FFFFFF", "Digging blocks has a chance to drop coins for 600 seconds"),
	stack_max= 25,
	inventory_image = "testventure_wealth_potion.png",
on_use = function(itemstack, user, pointed_thing)

 itemstack:take_item()
playereffects.apply_effect_type("testventure_wealth", 600, user)
		return itemstack
	end, true
})

minetest.register_on_dignode(function(pos, oldnode, digger)
	if digger ~= nil and digger:is_player() then
	for _, digger in pairs(minetest.get_connected_players()) do
for playername, has_wealth in pairs	(testventure.wealth) do
			if has_wealth then
	if math.random(1,2) == 1 then
		minetest.add_item(pos, "testventure:coin_copper")
	end
	if math.random(1,15) == 1 then
		minetest.add_item(pos, "testventure:coin_silver")
	end
	if math.random(1,360) == 1 then
		minetest.add_item(pos, "testventure:coin_gold")
	end
	if math.random(1,15000) == 1 then
		minetest.add_item(pos, "testventure:coin_platinum")
	end

		end
		end
		end
		end
end)

