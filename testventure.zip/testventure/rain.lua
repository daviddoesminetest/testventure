function testventure.rain()
local rainpath_find = io.open(minetest.get_worldpath().."/rain","r")
	if not rainpath_find then

	local rainpath_make = io.open(minetest.get_worldpath().."/rain","w")
	rainpath_make:write("0")
	io.close(rainpath_make)	
	rainpath_find = io.open(minetest.get_worldpath().."/rain","r")

 	end	
io.close(rainpath_find)	

end

testventure.rain()



	local raintimer = 0
minetest.register_globalstep(function(dtime, player)
	raintimer = raintimer + dtime;
	if raintimer >= 1.0 then
		raintimer = 0
	local filepath = minetest.get_worldpath().."/rain"
	local rain = io.open(filepath, "r")
	if rain ~= nil then
	rainmode = rain:read("*l")
	rain:close()
	raining = rainmode + 0
		if raining == 1 then
	minetest.sound_play("", {player})

	local filepath = minetest.get_worldpath().."/bloodmoon"
	local bloodmoon = io.open(filepath, "r")
	if bloodmoon ~= nil then
	bmmode = bloodmoon:read("*l")
	bloodmoon:close()
	bloodmoon_rised = bmmode + 0
		if bloodmoon_rised == 1 then

	for _, player in pairs(minetest.get_connected_players()) do
		local pos = player:get_pos()
		if pos.y > 0 then
		for i=1,200 do
	minetest.add_particle({
		pos = {x=pos.x + math.random(-30, 30), y=pos.y + math.random(15, 25), z=pos.z + (math.random(-30, 30))},
		velocity = 0,
          acceleration = {x=math.random(-0.25,0.25), y=math.random(-5.0,-20.0), z=math.random(-0.25,0.25)},
		expirationtime = 4.0,
		size = 6,
		collisiondetection = true,
		collision_removal = true,
		vertical = true,
		texture = "testventure_raindrop_red.png",
		glow = 3,
	})
	end end end
	else

	for _, player in pairs(minetest.get_connected_players()) do
		local pos = player:get_pos()
		if pos.y > 0 then
		for i=1,200 do
	minetest.add_particle({
		pos = {x=pos.x + math.random(-30, 30), y=pos.y + math.random(15, 25), z=pos.z + (math.random(-30, 30))},
		velocity = 0,
          acceleration = {x=math.random(-0.25,0.25), y=math.random(-5.0,-20.0), z=math.random(-0.25,0.25)},
		expirationtime = 4.0,
		size = 6,
		collisiondetection = true,
		collision_removal = true,
		vertical = true,
		texture = "testventure_raindrop.png",
		glow = 3,
	})
		end

	end end end end end end end end)


	local rainmodetimer = 0
minetest.register_globalstep(function(dtime, player)
	rainmodetimer = rainmodetimer + dtime;
	if rainmodetimer >= 20.0 then
	rainmodetimer = 0
if math.random(1, 75) <= 1 then

	local filepath = minetest.get_worldpath().."/rain"
	local rain = io.open(filepath, "r")
	if rain ~= nil then
	rainmode = rain:read("*l")
	rain:close()
	raining = rainmode + 0
		if raining == 0 then

local filepath = minetest.get_worldpath().."/rain"
		local rain = io.open(filepath,"w")
		rain:write("1")
		rain:close(rain)
 minetest.chat_send_all("" ..core.colorize("#00df7e","It began raining..."))
end 
		if raining == 1 then

local filepath = minetest.get_worldpath().."/rain"
		local rain = io.open(filepath,"w")
		rain:write("0")
		rain:close(rain)
 minetest.chat_send_all("" ..core.colorize("#00df7e","It stopped raining..."))

end

end end end end)

