----
---- icestone
----


minetest.register_node("testventure:icestone_coal_ore", {
		description = "".. core.colorize("#00eaff", "Coal Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^default_mineral_coal.png"},
	groups = {cracky = 3,is_ore=1,common_ore=1},
	drop = 'default:coal_lump',
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:icestone_iron_ore", {
		description = "".. core.colorize("#00eaff", "Iron Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^default_mineral_iron.png"},
	groups = {cracky = 2,is_ore=1,common_ore=1},
	drop = 'default:iron_lump',
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:icestone_copper_ore", {
		description = "".. core.colorize("#00eaff", "Copper Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^default_mineral_copper.png"},
	groups = {cracky = 2,is_ore=1,common_ore=1},
	drop = 'default:copper_lump',
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:icestone_tin_ore", {
		description = "".. core.colorize("#00eaff", "Tin Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^default_mineral_tin.png"},
	groups = {cracky = 2,is_ore=1,common_ore=1},
	drop = "default:tin_lump",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:icestone_mese_ore", {
		description = "".. core.colorize("#00eaff", "Mese Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^default_mineral_mese.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "default:mese_crystal",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:icestone_gold_ore", {
		description = "".. core.colorize("#00eaff", "Gold Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^default_mineral_gold.png"},
	groups = {cracky = 2,is_ore=1,uncommon_ore=1},
	drop = "default:gold_lump",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:icestone_diamond_ore", {
		description = "".. core.colorize("#00eaff", "Diamond Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^default_mineral_diamond.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "default:diamond",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:icestone_amethyst_ore", {
		description = "".. core.colorize("#00eaff", "amethyst Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^testventure_amethyst_ore.png"},
	groups = {cracky = 1,is_ore=1,common_ore=1},
	drop = "testventure:amethyst 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:icestone_topaz_ore", {
		description = "".. core.colorize("#00eaff", "topaz Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^testventure_topaz_ore.png"},
	groups = {cracky = 1,is_ore=1,common_ore=1},
	drop = "testventure:topaz 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:icestone_emerald_ore", {
		description = "".. core.colorize("#00eaff", "emerald Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^testventure_emerald_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:emerald 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:icestone_sapphire_ore", {
		description = "".. core.colorize("#00eaff", "sapphire Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^testventure_sapphire_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:sapphire 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:icestone_ruby_ore", {
		description = "".. core.colorize("#00eaff", "ruby Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^testventure_ruby_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:ruby 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("testventure:icestone_smaranium_ore", {
		description = "".. core.colorize("#00eaff", "Smaranium Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^testventure_smaranium_ore.png"},
	groups = {cracky = 1,is_ore=1,rare_ore=1},
	drop = "testventure:smaranium_lump 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:icestone_black_silver_ore", {
		description = "".. core.colorize("#00eaff", "Black silver Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^testventure_black_silver_ore.png"},
	groups = {cracky = 4,is_ore=1,rare_ore=1},
	drop = "testventure:black_silver_lump 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_coal_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 8 * 8 * 8,
		clust_num_ores = 8,
		clust_size     = 3,
		y_max          = 64,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_iron_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 7 * 7 * 7,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = 0,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_copper_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 9 * 9 * 9,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -16,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_tin_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -16,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_gold_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -55,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_mese_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -100,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_diamond_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 15 * 15 * 15,
		clust_num_ores = 4,
		clust_size     = 3,
		y_max          = -120,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_amethyst_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -40,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_topaz_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 11 * 11 * 11,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -55,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_emerald_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -70,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_sapphire_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -85,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_ruby_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -100,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_smaranium_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 25 * 25 * 25,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -300,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:icestone_black_silver_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 28 * 28 * 28,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -750,
	})

----
---- desert
----


minetest.register_node("testventure:desert_coal_ore", {
		description = "".. core.colorize("#00eaff", "Coal Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^default_mineral_coal.png"},
	groups = {cracky = 3,is_ore=1,common_ore=1},
	drop = 'default:coal_lump',
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:desert_iron_ore", {
		description = "".. core.colorize("#00eaff", "Iron Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^default_mineral_iron.png"},
	groups = {cracky = 2,is_ore=1,common_ore=1},
	drop = 'default:iron_lump',
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:desert_copper_ore", {
		description = "".. core.colorize("#00eaff", "Copper Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^default_mineral_copper.png"},
	groups = {cracky = 2,is_ore=1,common_ore=1},
	drop = 'default:copper_lump',
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:desert_tin_ore", {
		description = "".. core.colorize("#00eaff", "Tin Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^default_mineral_tin.png"},
	groups = {cracky = 2,is_ore=1,common_ore=1},
	drop = "default:tin_lump",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:desert_mese_ore", {
		description = "".. core.colorize("#00eaff", "Mese Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^default_mineral_mese.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "default:mese_crystal",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:desert_gold_ore", {
		description = "".. core.colorize("#00eaff", "Gold Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^default_mineral_gold.png"},
	groups = {cracky = 2,is_ore=1,uncommon_ore=1},
	drop = "default:gold_lump",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:desert_diamond_ore", {
		description = "".. core.colorize("#00eaff", "Diamond Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^default_mineral_diamond.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "default:diamond",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:desert_amethyst_ore", {
		description = "".. core.colorize("#00eaff", "amethyst Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^testventure_amethyst_ore.png"},
	groups = {cracky = 1,is_ore=1,common_ore=1},
	drop = "testventure:amethyst 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:desert_topaz_ore", {
		description = "".. core.colorize("#00eaff", "topaz Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^testventure_topaz_ore.png"},
	groups = {cracky = 1,is_ore=1,common_ore=1},
	drop = "testventure:topaz 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:desert_emerald_ore", {
		description = "".. core.colorize("#00eaff", "emerald Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^testventure_emerald_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:emerald 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:desert_sapphire_ore", {
		description = "".. core.colorize("#00eaff", "sapphire Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^testventure_sapphire_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:sapphire 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:desert_ruby_ore", {
		description = "".. core.colorize("#00eaff", "ruby Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^testventure_ruby_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:ruby 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("testventure:desert_smaranium_ore", {
		description = "".. core.colorize("#00eaff", "Smaranium Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^testventure_smaranium_ore.png"},
	groups = {cracky = 1,is_ore=1,rare_ore=1},
	drop = "testventure:smaranium_lump 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:desert_black_silver_ore", {
		description = "".. core.colorize("#00eaff", "Black silver Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_desert_stone.png^testventure_black_silver_ore.png"},
	groups = {cracky = 4,is_ore=1,rare_ore=1},
	drop = "testventure:black_silver_lump 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_coal_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 8 * 8 * 8,
		clust_num_ores = 16,
		clust_size     = 4,
		y_max          = 128,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_iron_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 7 * 7 * 7,
		clust_num_ores = 12,
		clust_size     = 4,
		y_max          = 10,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_copper_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 7 * 7 * 7,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -6,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_tin_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 8 * 8 * 8,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -6,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_gold_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -30,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_mese_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -100,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_diamond_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 15 * 15 * 15,
		clust_num_ores = 4,
		clust_size     = 3,
		y_max          = -120,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_amethyst_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -40,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_topaz_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 11 * 11 * 11,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -55,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_emerald_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -70,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_sapphire_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -85,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_ruby_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -100,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_smaranium_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 22 * 22 * 22,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -275,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:desert_black_silver_ore",
		wherein        = "default:desert_stone",
		clust_scarcity = 26 * 26 * 26,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -700,
	})

----
---- junglestone
----


minetest.register_node("testventure:junglestone_coal_ore", {
		description = "".. core.colorize("#00eaff", "Coal Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^default_mineral_coal.png"},
	groups = {cracky = 3,is_ore=1,common_ore=1},
	drop = 'default:coal_lump',
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:junglestone_iron_ore", {
		description = "".. core.colorize("#00eaff", "Iron Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^default_mineral_iron.png"},
	groups = {cracky = 2,is_ore=1,common_ore=1},
	drop = 'default:iron_lump',
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:junglestone_copper_ore", {
		description = "".. core.colorize("#00eaff", "Copper Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^default_mineral_copper.png"},
	groups = {cracky = 2,is_ore=1,common_ore=1},
	drop = 'default:copper_lump',
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:junglestone_tin_ore", {
		description = "".. core.colorize("#00eaff", "Tin Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^default_mineral_tin.png"},
	groups = {cracky = 2,is_ore=1,common_ore=1},
	drop = "default:tin_lump",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:junglestone_mese_ore", {
		description = "".. core.colorize("#00eaff", "Mese Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^default_mineral_mese.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "default:mese_crystal",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:junglestone_gold_ore", {
		description = "".. core.colorize("#00eaff", "Gold Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^default_mineral_gold.png"},
	groups = {cracky = 2,is_ore=1,uncommon_ore=1},
	drop = "default:gold_lump",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:junglestone_diamond_ore", {
		description = "".. core.colorize("#00eaff", "Diamond Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^default_mineral_diamond.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "default:diamond",
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:junglestone_amethyst_ore", {
		description = "".. core.colorize("#00eaff", "amethyst Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^testventure_amethyst_ore.png"},
	groups = {cracky = 1,is_ore=1,common_ore=1},
	drop = "testventure:amethyst 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:junglestone_topaz_ore", {
		description = "".. core.colorize("#00eaff", "topaz Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^testventure_topaz_ore.png"},
	groups = {cracky = 1,is_ore=1,common_ore=1},
	drop = "testventure:topaz 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:junglestone_emerald_ore", {
		description = "".. core.colorize("#00eaff", "emerald Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^testventure_emerald_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:emerald 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:junglestone_sapphire_ore", {
		description = "".. core.colorize("#00eaff", "sapphire Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^testventure_sapphire_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:sapphire 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:junglestone_ruby_ore", {
		description = "".. core.colorize("#00eaff", "ruby Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^testventure_ruby_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:ruby 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("testventure:junglestone_smaranium_ore", {
		description = "".. core.colorize("#00eaff", "Smaranium Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^testventure_smaranium_ore.png"},
	groups = {cracky = 1,is_ore=1,rare_ore=1},
	drop = "testventure:smaranium_lump 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:junglestone_black_silver_ore", {
		description = "".. core.colorize("#00eaff", "Black silver Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_junglestone.png^testventure_black_silver_ore.png"},
	groups = {cracky = 4,is_ore=1,rare_ore=1},
	drop = "testventure:black_silver_lump 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_coal_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 8 * 8 * 8,
		clust_num_ores = 8,
		clust_size     = 3,
		y_max          = 64,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_iron_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 7 * 7 * 7,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = 0,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_copper_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 9 * 9 * 9,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -16,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_tin_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -16,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_gold_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -55,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_mese_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = -90,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_diamond_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 4,
		clust_size     = 3,
		y_max          = -100,
		y_min          = -31000,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_amethyst_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 8 * 8 * 8,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -32,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_topaz_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 9 * 9 * 9,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -47,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_emerald_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -58,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_sapphire_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 11 * 11 * 11,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -72,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_ruby_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -80,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_smaranium_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 25 * 25 * 25,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -300,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:junglestone_black_silver_ore",
		wherein        = "testventure:junglestone",
		clust_scarcity = 28 * 28 * 28,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -750,
	})




