minetest.register_node("testventure:aquastone", {
		description = "".. core.colorize("#00eaff", "Aquastone\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_aquastone.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:aquamarine_ore", {
		description = "".. core.colorize("#00eaff", "Aquamarine Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_aquastone.png^testventure_aquamarine_ore.png"},
	groups = {cracky = 1,is_ore=1},
	drop = "testventure:aquamarine_shards 1",
	light_source = 3,
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:aquatic_lamp", {
		description = "".. core.colorize("#00eaff", "Aquatic lamp\n")..core.colorize("#FFFFFF", "A placable block, that produces light"),
	tiles = {"testventure_aquatic_lamp.png"},
	groups = {cracky = 3},
	paramtype = "light",
	sunlight_propagates = true,
	light_source = 13,
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:sand_with_yellow_kelp", {
		description = "".. core.colorize("#00eaff", "Yellow kelp\n")..core.colorize("#FFFFFF", "A plant, that can be placed on sand, underwater"),
	drawtype = "plantlike_rooted",
	stack_max= 999,
	waving = 1,
	tiles = {"default_sand.png"},
	special_tiles = {{name = "testventure_yellow_kelp.png", tileable_vertical = true}},
	inventory_image = "testventure_yellow_kelp.png",
	paramtype = "light",
	paramtype2 = "leveled",
	groups = {snappy = 3},
	selection_box = {
		type = "fixed",
		fixed = {
				{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
				{-2/16, 0.5, -2/16, 2/16, 3.5, 2/16},
		},
	},
	node_dig_prediction = "default:sand",
	node_placement_prediction = "",
	sounds = default.node_sound_sand_defaults({
		dig = {name = "default_dig_snappy", gain = 0.2},
		dug = {name = "default_grass_footstep", gain = 0.25},
	}),
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" and placer and
not placer:get_player_control().sneak then
local node_ptu = minetest.get_node(pointed_thing.under)
local def_ptu = minetest.registered_nodes[node_ptu.name]
			if def_ptu and def_ptu.on_rightclick then
				return def_ptu.on_rightclick(pointed_thing.under, node_ptu, placer,
			itemstack, pointed_thing)
			end end
		local pos = pointed_thing.under
		if minetest.get_node(pos).name ~= "default:sand" then
			return itemstack
		end
		local height = math.random(4, 6)
		local pos_top = {x = pos.x, y = pos.y + height, z = pos.z}
		local node_top = minetest.get_node(pos_top)
		local def_top = minetest.registered_nodes[node_top.name]
		local player_name = placer:get_player_name()
		if def_top and def_top.liquidtype == "source" and
				minetest.get_item_group(node_top.name, "water") > 0 then
			if not minetest.is_protected(pos, player_name) and
					not minetest.is_protected(pos_top, player_name) then
				minetest.set_node(pos, {name = "testventure:sand_with_yellow_kelp",
					param2 = height * 16})
				if not (creative and creative.is_enabled_for
						and creative.is_enabled_for(player_name)) then
					itemstack:take_item()
				end
			else
				minetest.chat_send_player(player_name, "Node is protected")
				minetest.record_protection_violation(pos, player_name)
			end
		end

		return itemstack
	end,
	after_destruct  = function(pos, oldnode)
		minetest.set_node(pos, {name = "default:sand"})
	end
})

minetest.register_node("testventure:sand_with_seaweed", {
		description = "".. core.colorize("#00eaff", "Seaweed kelp\n")..core.colorize("#FFFFFF", "A plant, that can be placed on sand, underwater"),
	drawtype = "plantlike_rooted",
	stack_max= 999,
	waving = 1,
	tiles = {"default_sand.png"},
	special_tiles = {{name = "testventure_seaweed.png", tileable_vertical = true}},
	inventory_image = "testventure_seaweed.png",
	paramtype = "light",
	paramtype2 = "leveled",
	groups = {snappy = 3},
	selection_box = {
		type = "fixed",
		fixed = {
				{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
				{-4/16, 0.5, -4/16, 4/16, 1.25, 4/16},
		},
	},
	node_dig_prediction = "default:sand",
	node_placement_prediction = "",
	sounds = default.node_sound_sand_defaults({
		dig = {name = "default_dig_snappy", gain = 0.2},
		dug = {name = "default_grass_footstep", gain = 0.25},
	}),

	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" and placer and
				not placer:get_player_control().sneak then
			local node_ptu = minetest.get_node(pointed_thing.under)
			local def_ptu = minetest.registered_nodes[node_ptu.name]
			if def_ptu and def_ptu.on_rightclick then
				return def_ptu.on_rightclick(pointed_thing.under, node_ptu, placer,
					itemstack, pointed_thing)
			end end
		local pos = pointed_thing.under
		if minetest.get_node(pos).name ~= "default:sand" then
			return itemstack
		end
		local height = 1
		local pos_top = {x = pos.x, y = pos.y + height, z = pos.z}
		local node_top = minetest.get_node(pos_top)
		local def_top = minetest.registered_nodes[node_top.name]
		local player_name = placer:get_player_name()
		if def_top and def_top.liquidtype == "source" and
				minetest.get_item_group(node_top.name, "water") > 0 then
			if not minetest.is_protected(pos, player_name) and
					not minetest.is_protected(pos_top, player_name) then
				minetest.set_node(pos, {name = "testventure:sand_with_seaweed",
					param2 = height * 16})
				if not (creative and creative.is_enabled_for
						and creative.is_enabled_for(player_name)) then
					itemstack:take_item()
				end
			else
				minetest.chat_send_player(player_name, "Node is protected")
				minetest.record_protection_violation(pos, player_name)
			end end
		return itemstack
	end,
	after_destruct  = function(pos, oldnode)
		minetest.set_node(pos, {name = "default:sand"})
	end
})

minetest.register_node("testventure:sand_with_red_kelp", {
		description = "".. core.colorize("#00eaff", "Red kelp\n")..core.colorize("#FFFFFF", "A plant, that can be placed on sand, underwater"),
	drawtype = "plantlike_rooted",
	stack_max= 999,
	waving = 1,
	tiles = {"default_sand.png"},
	special_tiles = {{name = "testventure_red_kelp.png", tileable_vertical = true}},
	inventory_image = "testventure_red_kelp.png",
	paramtype = "light",
	paramtype2 = "leveled",
	groups = {snappy = 3},
	selection_box = {
		type = "fixed",
		fixed = {
				{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
				{-4/16, 0.5, -4/16, 4/16, 1.25, 4/16},
		},
	},
	node_dig_prediction = "default:sand",
	node_placement_prediction = "",
	sounds = default.node_sound_sand_defaults({
		dig = {name = "default_dig_snappy", gain = 0.2},
		dug = {name = "default_grass_footstep", gain = 0.25},
	}),

	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" and placer and
				not placer:get_player_control().sneak then
			local node_ptu = minetest.get_node(pointed_thing.under)
			local def_ptu = minetest.registered_nodes[node_ptu.name]
			if def_ptu and def_ptu.on_rightclick then
				return def_ptu.on_rightclick(pointed_thing.under, node_ptu, placer,
					itemstack, pointed_thing)
			end end
		local pos = pointed_thing.under
		if minetest.get_node(pos).name ~= "default:sand" then
			return itemstack
		end
		local height = 1
		local pos_top = {x = pos.x, y = pos.y + height, z = pos.z}
		local node_top = minetest.get_node(pos_top)
		local def_top = minetest.registered_nodes[node_top.name]
		local player_name = placer:get_player_name()
		if def_top and def_top.liquidtype == "source" and
				minetest.get_item_group(node_top.name, "water") > 0 then
			if not minetest.is_protected(pos, player_name) and
					not minetest.is_protected(pos_top, player_name) then
				minetest.set_node(pos, {name = "testventure:sand_with_red_kelp",
					param2 = height * 16})
				if not (creative and creative.is_enabled_for
						and creative.is_enabled_for(player_name)) then
					itemstack:take_item()
				end
			else
				minetest.chat_send_player(player_name, "Node is protected")
				minetest.record_protection_violation(pos, player_name)
			end end
		return itemstack
	end,
	after_destruct  = function(pos, oldnode)
		minetest.set_node(pos, {name = "default:sand"})
	end
})

minetest.register_node("testventure:sand_with_long_seaweed", {
		description = "".. core.colorize("#00eaff", "Long seaweed\n")..core.colorize("#FFFFFF", "A plant, that can be placed on sand, underwater"),
	drawtype = "plantlike_rooted",
	stack_max= 999,
	waving = 1,
	tiles = {"default_sand.png"},
	special_tiles = {{name = "testventure_long_seaweed.png", tileable_vertical = true}},
	inventory_image = "testventure_long_seaweed.png",
	paramtype = "light",
	paramtype2 = "leveled",
	groups = {snappy = 3},
	selection_box = {
		type = "fixed",
		fixed = {
				{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
				{-2/16, 0.5, -2/16, 2/16, 3.5, 2/16},
		},
	},
	node_dig_prediction = "default:sand",
	node_placement_prediction = "",
	sounds = default.node_sound_sand_defaults({
		dig = {name = "default_dig_snappy", gain = 0.2},
		dug = {name = "default_grass_footstep", gain = 0.25},
	}),
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" and placer and
not placer:get_player_control().sneak then
local node_ptu = minetest.get_node(pointed_thing.under)
local def_ptu = minetest.registered_nodes[node_ptu.name]
			if def_ptu and def_ptu.on_rightclick then
				return def_ptu.on_rightclick(pointed_thing.under, node_ptu, placer,
			itemstack, pointed_thing)
			end end
		local pos = pointed_thing.under
		if minetest.get_node(pos).name ~= "default:sand" then
			return itemstack
		end
		local height = math.random(4, 6)
		local pos_top = {x = pos.x, y = pos.y + height, z = pos.z}
		local node_top = minetest.get_node(pos_top)
		local def_top = minetest.registered_nodes[node_top.name]
		local player_name = placer:get_player_name()
		if def_top and def_top.liquidtype == "source" and
				minetest.get_item_group(node_top.name, "water") > 0 then
			if not minetest.is_protected(pos, player_name) and
					not minetest.is_protected(pos_top, player_name) then
				minetest.set_node(pos, {name = "testventure:sand_with_long_seaweed",
					param2 = height * 16})
				if not (creative and creative.is_enabled_for
						and creative.is_enabled_for(player_name)) then
					itemstack:take_item()
				end
			else
				minetest.chat_send_player(player_name, "Node is protected")
				minetest.record_protection_violation(pos, player_name)
			end
		end

		return itemstack
	end,
	after_destruct  = function(pos, oldnode)
		minetest.set_node(pos, {name = "default:sand"})
	end
})

minetest.register_decoration({
		name = "testventure:yellow_kelp",
		deco_type = "simple",
		place_on = {"default:sand"},
		place_offset_y = -1,
		sidelen = 80,
		fill_ratio = 0.03,
		biomes = {
			"taiga_ocean",
			"snowy_grassland_ocean",
			"grassland_ocean",
			"coniferous_forest_ocean",
			"deciduous_forest_ocean",
			"sandstone_desert_ocean",
			"cold_desert_ocean"},
		y_max = -7,
		y_min = -40,
		flags = "force_placement",
		decoration = "testventure:sand_with_yellow_kelp",
		param2 = 48,
		param2_max = 96,
	})

	minetest.register_decoration({
		name = "testventure:seaweed",
		deco_type = "simple",
		place_on = {"default:sand"},
		place_offset_y = -1,
		sidelen = 80,
		fill_ratio = 0.2,
		biomes = {
			"taiga_ocean",
			"snowy_grassland_ocean",
			"grassland_ocean",
			"coniferous_forest_ocean",
			"deciduous_forest_ocean",
			"sandstone_desert_ocean",
			"cold_desert_ocean"},
		y_max = -1,
		y_min = -40,
		flags = "force_placement",
		decoration = "testventure:sand_with_seaweed",
		param2 = 16,
		param2_max = 16,
	})

	minetest.register_decoration({
		name = "testventure:red_kelp",
		deco_type = "simple",
		place_on = {"default:sand"},
		place_offset_y = -1,
		sidelen = 80,
		fill_ratio = 0.05,
		biomes = {
			"taiga_ocean",
			"snowy_grassland_ocean",
			"grassland_ocean",
			"coniferous_forest_ocean",
			"deciduous_forest_ocean",
			"sandstone_desert_ocean",
			"cold_desert_ocean"},
		y_max = -2,
		y_min = -40,
		flags = "force_placement",
		decoration = "testventure:sand_with_red_kelp",
		param2 = 16,
		param2_max = 16,
	})

minetest.register_decoration({
		name = "testventure:long_seaweed",
		deco_type = "simple",
		place_on = {"default:sand"},
		place_offset_y = -1,
		sidelen = 80,
		fill_ratio = 0.04,
		biomes = {
			"taiga_ocean",
			"snowy_grassland_ocean",
			"grassland_ocean",
			"coniferous_forest_ocean",
			"deciduous_forest_ocean",
			"sandstone_desert_ocean",
			"cold_desert_ocean"},
		y_max = -6,
		y_min = -40,
		flags = "force_placement",
		decoration = "testventure:sand_with_long_seaweed",
		param2 = 48,
		param2_max = 96,
	})

	minetest.register_decoration({
		name = "testventure:aquatic_lamp",
		deco_type = "simple",
		place_on = {"default:sand"},
		place_offset_y = 0,
		sidelen = 80,
		fill_ratio = 0.003,
		biomes = {
			"taiga_ocean",
			"snowy_grassland_ocean",
			"grassland_ocean",
			"coniferous_forest_ocean",
			"deciduous_forest_ocean",
			"sandstone_desert_ocean",
			"cold_desert_ocean"},
		y_max = -7,
		y_min = -40,
		flags = "force_placement",
		decoration = "testventure:aquatic_lamp",
	})



