

arrows = {
	{"testventure:stone_arrow", "testventure:stone_arrow_projectile"},
	{"testventure:flint_arrow", "testventure:flint_arrow_projectile"},
	{"testventure:steel_arrow", "testventure:steel_arrow_projectile"},
	{"testventure:diamond_arrow", "testventure:diamond_arrow_projectile"},
	{"testventure:crimson_arrow", "testventure:crimson_arrow_projectile"},
	{"testventure:gem_shard_arrow", "testventure:gem_shard_arrow_projectile"},
	{"testventure:sky_arrow", "testventure:sky_arrow_projectile"},
	{"testventure:frost_arrow", "testventure:frost_arrow_projectile"},
}

bullets = {
	{"testventure:musketball", "testventure:musketball_projectile"},
	{"testventure:standard_bullet", "testventure:standard_bullet_projectile"},
	{"testventure:black_silver_bullet", "testventure:black_silver_bullet_projectile"},
	{"testventure:shadow_bullet", "testventure:shadow_bullet_projectile"},

}

---
--- arrows
---


--- stone_arrow ---

minetest.register_craftitem("testventure:stone_arrow", {
		description = "".. core.colorize("#00eaff", "stone arrow\n")..core.colorize("#FFFFFF", "Ammo damage: 1-2\n")..core.colorize("#FFFFFF", "Ammo critical: 1%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 200%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 1"),
	stack_max= 999,
	wield_scale = {x=1,y=1,z=1},
	range = 0,
	inventory_image = "testventure_stone_arrow.png",
})

local testventure_stone_arrow_projectile = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure:stone_arrow_shot"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_stone_arrow_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:stone_arrow_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 1 + base_crit + crit_bonus then
local damage = (math.random(1,2)+ base_dmg) * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (math.random(1,2) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 1 + crit_bonus then
local damage = (math.random(1,2)+ base_dmg) * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (math.random(1,2) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		if self.timer >= 15.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if math.random(1, 100) <= 25 then
minetest.add_item(self.lastpos, "testventure:stone_arrow")
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:stone_arrow_projectile", testventure_stone_arrow_projectile )

minetest.register_craft({
	output = 'testventure:stone_arrow 15',
	recipe = {
		{'default:cobble', 'group:wood', 'group:wood'},
	}
})



minetest.register_craftitem("testventure:stone_arrow_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_stone_arrow_shot.png",
})

--- flint_arrow ---

minetest.register_craftitem("testventure:flint_arrow", {
		description = "".. core.colorize("#00eaff", "flint arrow\n")..core.colorize("#FFFFFF", "Ammo damage: 2-3\n")..core.colorize("#FFFFFF", "Ammo critical: 2%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 225%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 1"),
	stack_max= 999,
	wield_scale = {x=1,y=1,z=1},
	range = 0,
	inventory_image = "testventure_flint_arrow.png",
})

local testventure_flint_arrow_projectile = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure:flint_arrow_shot"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_flint_arrow_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:flint_arrow_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 2 + base_crit + crit_bonus then
local damage = (math.random(2,3)+ base_dmg) * 2.25 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (math.random(2,3) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 2 + crit_bonus then
local damage = (math.random(2,3)+ base_dmg) * 2.25 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (math.random(2,3) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		if self.timer >= 15.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if math.random(1, 100) <= 25 then
minetest.add_item(self.lastpos, "testventure:flint_arrow")
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:flint_arrow_projectile", testventure_flint_arrow_projectile )

minetest.register_craft({
	output = 'testventure:flint_arrow 12',
	recipe = {
		{'', '', 'mobs:chicken_feather'},
		{'default:flint', 'group:wood', 'group:wood'},
		{'', '', 'mobs:chicken_feather'},

	}
})



minetest.register_craftitem("testventure:flint_arrow_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_flint_arrow_shot.png",
})

--- steel_arrow ---

minetest.register_craftitem("testventure:steel_arrow", {
		description = "".. core.colorize("#00eaff", "steel arrow\n")..core.colorize("#FFFFFF", "Ammo damage: 3-5\n")..core.colorize("#FFFFFF", "Ammo critical: 2%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 240%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 2"),
	stack_max= 999,
	wield_scale = {x=1,y=1,z=1},
	range = 0,
	inventory_image = "testventure_steel_arrow.png",
})

local testventure_steel_arrow_projectile = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure:steel_arrow_shot"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_steel_arrow_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:steel_arrow_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 2 + base_crit + crit_bonus then
local damage = (math.random(3,5)+ base_dmg) * 2.4 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 2 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (math.random(3,5) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 2 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 2 + crit_bonus then
local damage = (math.random(3,5)+ base_dmg) * 2.4 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (math.random(3,5) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		if self.timer >= 15.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if math.random(1, 100) <= 25 then
minetest.add_item(self.lastpos, "testventure:steel_arrow")
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:steel_arrow_projectile", testventure_steel_arrow_projectile )

minetest.register_craft({
	output = 'testventure:steel_arrow 15',
	recipe = {
		{'', '', 'default:paper'},
		{'default:steel_ingot', 'group:wood', 'group:wood'},
		{'', '', 'default:paper'},

	}
})

minetest.register_craftitem("testventure:steel_arrow_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_steel_arrow_shot.png",
})


--- diamond_arrow ---

minetest.register_craftitem("testventure:diamond_arrow", {
		description = "".. core.colorize("#00eaff", "diamond arrow\n")..core.colorize("#FFFFFF", "Ammo damage: 5-8\n")..core.colorize("#FFFFFF", "Ammo critical: 4%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 350%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 2"),
	stack_max= 999,
	wield_scale = {x=1,y=1,z=1},
	range = 0,
	inventory_image = "testventure_diamond_arrow.png",
})

local testventure_diamond_arrow_projectile = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure:diamond_arrow_shot"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_diamond_arrow_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:diamond_arrow_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 4 + base_crit + crit_bonus then
local damage = (math.random(5,8)+ base_dmg) * 3.5 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 2 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (math.random(5,8) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 2 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 4 + crit_bonus then
local damage = (math.random(5,8)+ base_dmg) * 3.5 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (math.random(5,8) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		if self.timer >= 15.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if math.random(1, 100) <= 25 then
minetest.add_item(self.lastpos, "testventure:diamond_arrow")
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:diamond_arrow_projectile", testventure_diamond_arrow_projectile )

minetest.register_craft({
	output = 'testventure:diamond_arrow 25',
	recipe = {
		{'', '', 'default:paper'},
		{'default:diamond', 'default:steel_ingot', 'default:steel_ingot'},
		{'', '', 'default:paper'},

	}
})

minetest.register_craftitem("testventure:diamond_arrow_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_diamond_arrow_shot.png",
})


--- frost_arrow ---

minetest.register_craftitem("testventure:frost_arrow", {
		description = "".. core.colorize("#00eaff", "frost arrow\n")..core.colorize("#FFFFFF", "Ammo damage: 8-10\n")..core.colorize("#FFFFFF", "Ammo critical: 8%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 400%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 2"),
	stack_max= 999,
	wield_scale = {x=1,y=1,z=1},
	range = 0,
	inventory_image = "testventure_frost_arrow.png",
})

local testventure_frost_arrow_projectile = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	glow = 25,
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure:frost_arrow_shot"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_frost_arrow_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:frost_arrow_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 4 + base_crit + crit_bonus then
local damage = (math.random(8,10)+ base_dmg) * 4.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 2 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (math.random(8,10) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 2 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 4 + crit_bonus then
local damage = (math.random(5,8)+ base_dmg) * 4.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (math.random(5,8) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end

	local tiem = 0.2
		if self.timer >= 0.1 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-4, 4), y=math.random(-4, 4), z=math.random(-4, 4)},
		expirationtime = 1.0,
		size = 3,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_frost_particle.png",
		glow = 25,
	})
		tiem = tiem + 0.2
			end
		if self.timer >= 15.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if math.random(1, 100) <= 25 then
minetest.add_item(self.lastpos, "testventure:frost_arrow")
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:frost_arrow_projectile", testventure_frost_arrow_projectile )

minetest.register_craft({
	output = 'testventure:frost_arrow 60',
	recipe = {
		{'', '', 'testventure:frozen_slimeball'},
		{'testventure:eternal_ice_shards', 'testventure:icestone', 'testventure:icestone'},
		{'', '', 'testventure:frozen_slimeball'},

	}
})

minetest.register_craftitem("testventure:frost_arrow_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_frost_arrow_shot.png",
})


--- crimson_arrow ---

minetest.register_craftitem("testventure:crimson_arrow", {
		description = "".. core.colorize("#00eaff", "crimson arrow\n")..core.colorize("#FFFFFF", "Ammo damage: 4-7\n")..core.colorize("#FFFFFF", "Ammo critical: 9%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 400%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 1"),
	stack_max= 999,
	wield_scale = {x=1,y=1,z=1},
	range = 0,
	inventory_image = "testventure_crimson_arrow.png",
})

local testventure_crimson_arrow_projectile = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure:crimson_arrow_shot"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_crimson_arrow_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:crimson_arrow_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 9 + base_crit + crit_bonus then
local damage = (math.random(4,7)+ base_dmg) * 4.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (math.random(4,7) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 9 + crit_bonus then
local damage = (math.random(4,7)+ base_dmg) * 4.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (math.random(4,7) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		if self.timer >= 15.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if math.random(1, 100) <= 25 then
minetest.add_item(self.lastpos, "testventure:crimson_arrow")
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:crimson_arrow_projectile", testventure_crimson_arrow_projectile )

minetest.register_craft({
	output = 'testventure:crimson_arrow 50',
	recipe = {
		{'testventure:worm_tooth', '', ''},
		{'', 'testventure:crimrubite_bar', 'testventure:shadowsteel_bar'},
		{'testventure:worm_tooth', '', ''},

	}
})



minetest.register_craftitem("testventure:crimson_arrow_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_crimson_arrow_shot.png",
})


--- sky_arrow ---

minetest.register_craftitem("testventure:sky_arrow", {
		description = "".. core.colorize("#00eaff", "sky arrow\n")..core.colorize("#FFFFFF", "Ammo damage: 3-9\n")..core.colorize("#FFFFFF", "Ammo critical: 5%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 300%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 1\n")..core.colorize("#FFFFFF", "has 75% chance to penetrate targets"),
	stack_max= 999,
	wield_scale = {x=1,y=1,z=1},
	range = 0,
	inventory_image = "testventure_sky_arrow.png",
})

local testventure_sky_arrow_projectile = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure:sky_arrow_shot"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_sky_arrow_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:sky_arrow_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 5 + base_crit + crit_bonus then
local damage = (math.random(3,9)+ base_dmg) * 3.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.timer = 0.025
			if math.random(1, 4) == 1 then
				self.object:remove()
			end
					else
local damage = (math.random(3,9) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
			self.timer = 0.025
			if math.random(1, 4) == 1 then
				self.object:remove()
			end
				end
			end
			else
if math.random(1, 100) <= 5 + crit_bonus then
local damage = (math.random(3,9)+ base_dmg) * 3.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.timer = 0.025
			if math.random(1, 4) == 1 then
				self.object:remove()
			end
				else
local damage = (math.random(4,9) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
			self.timer = 0.025
			if math.random(1, 4) == 1 then
				self.object:remove()
			end
				end
			end
		if self.timer >= 15.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if math.random(1, 100) <= 25 then
minetest.add_item(self.lastpos, "testventure:sky_arrow")
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:sky_arrow_projectile", testventure_sky_arrow_projectile )



minetest.register_craftitem("testventure:sky_arrow_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_sky_arrow_shot.png",
})


--- gem_shard_arrow ---

minetest.register_craftitem("testventure:gem_shard_arrow", {
		description = "".. core.colorize("#00eaff", "Gem shard arrow\n")..core.colorize("#FFFFFF", "Ammo damage: 2-5\n")..core.colorize("#FFFFFF", "Ammo critical: 4%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 250%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 1\n")..core.colorize("#FFFFFF", "Upon impact, shatters into gem shards, that may hit nearby enemies"),
	stack_max= 999,
	wield_scale = {x=1,y=1,z=1},
	range = 0,
	inventory_image = "testventure_gem_shard_arrow.png",
})

local testventure_gem_shard_arrow_projectile = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure:gem_shard_arrow_shot"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_gem_shard_arrow_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:gem_shard_arrow_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 4 + base_crit + crit_bonus then
local damage = (math.random(2,5)+ base_dmg) * 2.5 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
self.object:remove()
for i=1,5 do
local shatter = minetest.add_entity({x=pos.x + math.random(-1, 1), y=pos.y + math.random(0, 2), z=pos.z + (math.random(-1, 1))}, 	"testventure:gem_shard_projectile")
shatter:setvelocity({x=0, y=math.random(6, 10), z=0})
	shatter:setacceleration({x=math.random(-45, 45), y=math.random(-45, -45),z=math.random(-45, 45)})
end

					else
local damage = (math.random(2,5) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
for i=1,5 do
local shatter = minetest.add_entity({x=pos.x + math.random(-1, 1), y=pos.y + math.random(0, 2), z=pos.z + (math.random(-1, 1))}, 	"testventure:gem_shard_projectile")
shatter:setvelocity({x=0, y=math.random(6, 10), z=0})
	shatter:setacceleration({x=math.random(-45, 45), y=math.random(-45, -45),z=math.random(-45, 45)})
end

				end
			end
			else
if math.random(1, 100) <= 4 + crit_bonus then
local damage = (math.random(2,5)+ base_dmg) * 2.5 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
for i=1,5 do
local shatter = minetest.add_entity({x=pos.x + math.random(-1, 1), y=pos.y + math.random(0, 2), z=pos.z + (math.random(-1, 1))}, 	"testventure:gem_shard_projectile")
shatter:setvelocity({x=0, y=math.random(6, 10), z=0})
	shatter:setacceleration({x=math.random(-45, 45), y=math.random(-45, -45),z=math.random(-45, 45)})
end

				else
local damage = (math.random(2,5) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
for i=1,5 do
local shatter = minetest.add_entity({x=pos.x + math.random(-1, 1), y=pos.y + math.random(0, 2), z=pos.z + (math.random(-1, 1))}, 	"testventure:gem_shard_projectile")
shatter:setvelocity({x=0, y=math.random(6, 10), z=0})
	shatter:setacceleration({x=math.random(-45, 45), y=math.random(-45, -45),z=math.random(-45, 45)})
end


				end
			end
		if self.timer >= 15.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()

for i=1,4 do
	if self.timer > 0.55 then
local shatter = minetest.add_entity(self.lastpos, 	"testventure:gem_shard_projectile")
shatter:setvelocity({x=0, y=math.random(6, 10), z=0})
	shatter:setacceleration({x=math.random(-45, 45), y=math.random(-45, -45),z=math.random(-45, 45)})

end
end
		end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:gem_shard_arrow_projectile", testventure_gem_shard_arrow_projectile )




local testventure_gem_shard_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.4, y=0.4},
	textures = {"testventure_gem_shard.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_gem_shard_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:gem_shard_arrow_projectile" and obj:get_luaentity().name ~= "testventure:gem_shard_projectile" and obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 1

local damage = (1 + base_dmg)/2
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 3},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})

					self.object:remove()
				end

				else
	base_dmg = base_dmg or 1
local damage = (1 + base_dmg)/2
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
			end
		if self.timer >= 15.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:gem_shard_projectile", testventure_gem_shard_projectile )

minetest.register_craft({
	output = 'testventure:gem_shard_arrow 40',
	recipe = {
		{'testventure:ruby', 'testventure:topaz', 'testventure:emerald'},
		{'testventure:amethyst', 'default:steel_ingot', ''},
		{'testventure:sapphire', '', 'default:steel_ingot'},

	}
})



minetest.register_craftitem("testventure:gem_shard_arrow_shot", {
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_gem_shard_arrow_shot.png",
})

---
--- bullets
---

--- musketball

minetest.register_craftitem("testventure:musketball", {
		description = "".. core.colorize("#00eaff", "musketball\n")..core.colorize("#FFFFFF", "Ammo damage: 1-2\n")..core.colorize("#FFFFFF", "Ammo critical: 2%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 200%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 1"),
	stack_max= 999,
	wield_scale = {x=0.5,y=0.5,z=1},
	range = 0,
	inventory_image = "testventure_musketball.png",
})

local testventure_musketball_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}

testventure_musketball_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.125 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:musketball_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 2 + base_crit + crit_bonus then
local damage = (math.random(1,2) + base_dmg) * 2.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (math.random(1,2) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 2 + crit_bonus then
local damage = (math.random(1,2) + base_dmg) * 2.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (math.random(1,2) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end 
		local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=0, y=0, z=0},
		expirationtime = 0.06,
		size = 3,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_bulletshot.png",
		glow = 21,
	})
		tiem = tiem + 0.2 
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:musketball_projectile", testventure_musketball_projectile )

--- standard_bullet

minetest.register_craftitem("testventure:standard_bullet", {
		description = "".. core.colorize("#00eaff", "Standard bullet\n")..core.colorize("#FFFFFF", "Ammo damage: 2-4\n")..core.colorize("#FFFFFF", "Ammo critical: 3%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 250%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 1"),
	stack_max= 999,
	wield_scale = {x=0.5,y=0.5,z=1},
	range = 0,
	inventory_image = "testventure_standard_bullet.png",
})

local testventure_standard_bullet_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}

testventure_standard_bullet_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.125 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:standard_bullet_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 3 + base_crit + crit_bonus then
local damage = (math.random(2,4)+ base_dmg) * 2.5 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (math.random(2,4) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 3 + crit_bonus then
local damage = (math.random(2,4)+ base_dmg) * 2.5 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (math.random(2,4) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end 
		local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=0, y=0, z=0},
		expirationtime = 0.06,
		size = 3,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_standard_bulletshot.png",
		glow = 21,
	})
		tiem = tiem + 0.2 
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:standard_bullet_projectile", testventure_standard_bullet_projectile )


--- black_silver_bullet

minetest.register_craftitem("testventure:black_silver_bullet", {
		description = "".. core.colorize("#00eaff", "Black silver bullet\n")..core.colorize("#FFFFFF", "Ammo damage: 4-6\n")..core.colorize("#FFFFFF", "Ammo critical: 5%\n")..core.colorize("#FFFFFF", "Ammo critical efficiency: 300%\n") ..core.colorize("#FFFFFF", "Ammo knockback: 1"),
	stack_max= 999,
	wield_scale = {x=0.5,y=0.5,z=1},
	range = 0,
	inventory_image = "testventure_black_silver_bullet.png",
})

local testventure_black_silver_bullet_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}

testventure_black_silver_bullet_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.125 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:black_silver_bullet_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 5 + base_crit + crit_bonus then
local damage = (math.random(4,6)+ base_dmg) * 3.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (math.random(4,6) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 5 + crit_bonus then
local damage = (math.random(4,6)+ base_dmg) * 3.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (math.random(4,6) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=0, y=0, z=0},
		expirationtime = 0.06,
		size = 3,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_bulletshot.png",
		glow = 21,
	})
		tiem = tiem + 0.2 
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:black_silver_bullet_projectile", testventure_black_silver_bullet_projectile)



--- shadow_bullet

minetest.register_craftitem("testventure:shadow_bullet", {
		description = "".. core.colorize("#00eaff", "Shadow bullet\n")..core.colorize("#FFFFFF", "Ammo damage: 2-4\n")..core.colorize("#FFFFFF", "Ammo critical: 5%\n") ..core.colorize("#FFFFFF", "Ammo critical efficiency: 300%\n")..core.colorize("#FFFFFF", "Penetrates targets\n")  ..core.colorize("#FFFFFF", "Ammo knockback: 0"),
	stack_max= 999,
	wield_scale = {x=0.5,y=0.5,z=1},
	range = 0,
	inventory_image = "testventure_shadow_bullet.png",
})

local testventure_shadow_bullet_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}

testventure_shadow_bullet_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.125 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:shadow_bullet_projectile" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	base_kb = base_kb or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 5 + base_crit + crit_bonus then
local damage = (math.random(2,4)+ base_dmg) * 3.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 0 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.timer = 0.025
					else
local damage = (math.random(2,4) + base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 0 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
			self.timer = 0.025
				end
			end
			else
if math.random(1, 100) <= 5 + crit_bonus then
local damage = (math.random(2,4)+ base_dmg) * 3.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.timer = 0.025
				else
local damage = (math.random(2,4) + base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.timer = 0.025
				end
			end
		local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=0, y=0, z=0},
		expirationtime = 0.06,
		size = 3,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_shadow_bulletshot.png",
		glow = 21,
	})
		tiem = tiem + 0.2 
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:shadow_bullet_projectile", testventure_shadow_bullet_projectile )


minetest.register_craftitem("testventure:flare", {
		description = "".. core.colorize("#00eaff", "Flare\n")..core.colorize("#FFFFFF", "Ammo damage: 1\n")..core.colorize("#FFFFFF", "Penetrates targets\n")  ..core.colorize("#FFFFFF", "Used by the flare gun"),
	stack_max= 999,
	wield_scale = {x=0.75,y=0.75,z=0.75},
	range = 0,
	inventory_image = "testventure_flare.png",
})

local testventure_flare_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}

testventure_flare_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.24 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 2)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:flare_projectile" and obj:get_luaentity().name ~= "__builtin:item" then
local damage = 1
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback=0},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
			self.timer = 0.1
				
			end
			else
local damage = 1
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.timer = 0.1
				
			end
		local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-2.0,2.0), y=math.random(-2.0,2.0), z=math.random(-2.0,2.0)},
		expirationtime = 1.0,
		size = 15,
		collisiondetection = true,
		vertical = false,
		texture = "testventure_flare_spark.png",
		glow = 30,
	})
		tiem = tiem + 0.2 
			end
		if self.timer >= 15 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
local node = minetest.get_node(self.lastpos)
if node.name == "air" then
minetest.set_node(self.lastpos, {name = "testventure:flare_block"})
minetest.get_node_timer(self.lastpos):start(0.5)
		end
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:flare_projectile", testventure_flare_projectile)









