---
--- armsdealer
---

armsdealer_form =
"size[14,10]"..
"label[0,0;Armsdealer.]"..
--machinetrout--
"image_button[1,1;2.0,2.0;testventure_machinetrout.png;machinetrout; "..minetest.colorize("#ffe400","35 Gold").."]"..
--musketball--
"image_button[3,1;2.0,2.0;testventure_musketball.png;musketball; "..minetest.colorize("#b0d8db","1 silver (15)").."]"..
--flintlock--
"image_button[5,1;2.0,2.0;testventure_flintlock_pistol.png;flintlock; "..minetest.colorize("#ffe400","4 gold").."]"..
--shotgun--
"image_button[7,1;2.0,2.0;testventure_shotgun.png;shotgun; "..minetest.colorize("#ffe400","25 gold").."]"..
----
--tactical--
"image_button[9,1;2.0,2.0;testventure_bow_tactical.png;tactical; "..minetest.colorize("#ffe400","16 gold").."]"..
----
"button_exit[6,9;2,1;exit;Done]"


minetest.register_on_player_receive_fields(function(player, formname, fields)

	if formname == "testventure:armsdealer_form" then

		if fields["bacc"] then
		minetest.show_formspec(player:get_player_name(),"testventure:armsdealer_form", armsdealer_form) 
end

		if fields["machinetrout"] then
		minetest.show_formspec(player:get_player_name(),"testventure:armsdealer_form", machinetrout_form) 
end

		if fields["musketball"] then
		minetest.show_formspec(player:get_player_name(),"testventure:armsdealer_form", musketball_form) 
end

		if fields["flintlock"] then
		minetest.show_formspec(player:get_player_name(),"testventure:armsdealer_form", flintlock_form) 
end

		if fields["shotgun"] then
		minetest.show_formspec(player:get_player_name(),"testventure:armsdealer_form", shotgun_form) 
end

		if fields["tactical"] then
		minetest.show_formspec(player:get_player_name(),"testventure:armsdealer_form", tactical_form) 
end

end
end)

--machinetrout

machinetrout_form =
"size[5,10]"..
"label[1,0;Machinetrout.]"..
"image[1,1;3.0,3.0;testventure_machinetrout.png]"..
"label[0.5,4;Ranged damage: 1-4]"..
"label[0.5,4.5;Accuracy: 70%]"..
"label[0.5,5;Knockback: 1]"..
"label[0.5,5.5;Critical chance: 2%]"..
"label[0.5,6;Ammunition: bullets]"..
"label[0.5,6.5;Rate of fire: 0.08]"..
"label[0.5,7;projectile velocity: 25]"..
"label[0.5,7.5;33% chance not to consume ammo]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buymachinetrout;Buy (35 gold)]"

--musketball

musketball_form =
"size[5,10]"..
"label[1,0;Musket ball (x 15).]"..
"image[1,1;3.0,3.0;testventure_musketball.png]"..
"label[0.5,4;Ammo damage: 1-2]"..
"label[0.5,4.5;Ammo critical: 2%]"..
"label[0.5,5;Ammo critical efficiency: 200%]"..
"label[0.5,5.5;Ammo knockback: 1]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buymusketball;Buy (1 silver)]"

--flintlock

flintlock_form =
"size[5,10]"..
"label[1,0;Flintlock pistol.]"..
"image[1,1;3.0,3.0;testventure_flintlock_pistol.png]"..
"label[0.5,4;Ranged damage: 4-7]"..
"label[0.5,4.5;Accuracy: 85%]"..
"label[0.5,5;Knockback: 4]"..
"label[0.5,5.5;Critical chance: 3%]"..
"label[0.5,6;Ammunition: bullets]"..
"label[0.5,6.5;Rate of fire: 0.7]"..
"label[0.5,7;projectile velocity: 30]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buyflintlock;Buy (4 gold)]"

--shotgun

shotgun_form =
"size[5,10]"..
"label[1,0;Shotgun.]"..
"image[1,1;3.0,3.0;testventure_shotgun.png]"..
"label[0.5,4;Ranged damage: 8-12]"..
"label[0.5,4.5;Accuracy: 45%]"..
"label[0.5,5;Knockback: 10]"..
"label[0.5,5.5;Critical chance: 4%]"..
"label[0.5,6;Ammunition: bullets]"..
"label[0.5,6.5;Rate of fire: 1.2]"..
"label[0.5,7;projectile velocity: 25]"..
"label[0.5,7.5;Shoots a spread of bullets]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buyshotgun;Buy (25 gold)]"

--tactical

tactical_form =
"size[5,10]"..
"label[1,0;Tactical bow.]"..
"image[1,1;3.0,3.0;testventure_bow_tactical.png]"..
"label[0.5,4;Ranged damage: 9-16]"..
"label[0.5,4.5;Accuracy: 95%]"..
"label[0.5,5.0;Projectile gravitational pull: 5]"..
"label[0.5,5.5;Knockback: 4]"..
"label[0.5,6.0;Critical chance: 10%]"..
"label[0.5,6.5;Ammunition: arrows]"..
"label[0.5,7.0;Rate of fire: 0.5]"..
"label[0.5,7.5;projectile velocity: 25]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buytactical;Buy (16 gold)]"

---
---buying
---

minetest.register_on_player_receive_fields(function(player, formname, fields)

---machinetrout
---
	if formname == "testventure:armsdealer_form" then
		if fields["buymachinetrout"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_gold 35") then
		inv:remove_item("main", "testventure:coin_gold 35")
		inv:add_item("main", "testventure:machinetrout 1") 
	end
	end
----
---- musketball
----
		if fields["buymusketball"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_silver 1") then
		inv:remove_item("main", "testventure:coin_silver 1")
		inv:add_item("main", "testventure:musketball 15") 
	end
	end
----
---- flintlock pistol
----
		if fields["buyflintlock"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_gold 4") then
		inv:remove_item("main", "testventure:coin_gold 4")
		inv:add_item("main", "testventure:flintlock_pistol 1") 
	end
	end
----
---- shotgun
----
		if fields["buyshotgun"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_gold 25") then
		inv:remove_item("main", "testventure:coin_gold 25")
		inv:add_item("main", "testventure:shotgun 1") 
	end
	end
----
---- tactical
----
		if fields["buytactical"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_gold 16") then
		inv:remove_item("main", "testventure:coin_gold 16")
		inv:add_item("main", "testventure:bow_tactical 1") 
	end
	end
----


end
end)

---
--- merchant
---

merchant_form =
"size[14,10]"..
"label[0,0;merchant.]"..
--basic_sword--
"image_button[1,1;2.0,2.0;testventure_basic_sword.png;basic_sword; "..minetest.colorize("#ffe400","1 Gold").."]"..
--steel_arrow--
"image_button[3,1;2.0,2.0;testventure_steel_arrow.png;steel_arrow; "..minetest.colorize("#b0d8db","2 silver (12)").."]"..
--torch--
"image_button[5,1;2.0,2.0;default_torch_on_floor.png;torch; "..minetest.colorize("#ff6000","50 copper (4)").."]"..
--small_health--
"image_button[7,1;2.0,2.0;testventure_health_potion_small.png;small_health; "..minetest.colorize("#ff6000","90 copper").."]"..
--health--
"image_button[9,1;2.0,2.0;testventure_health_potion.png;health; "..minetest.colorize("#b0d8db","5 silver").."]"..
--shuriken--
"image_button[11,1;2.0,2.0;testventure_shuriken.png;shuriken; "..minetest.colorize("#b0d8db","2 silver (10)").."]"..
----
--throwing_knife--
"image_button[1,3;2.0,2.0;testventure_throwing_knife.png;throwing_knife; "..minetest.colorize("#b0d8db","3 silver (10)").."]"..
----
--flare--
"image_button[3,3;2.0,2.0;testventure_flare.png;flare; "..minetest.colorize("#b0d8db","2 silver (16)").."]"..
----
"button_exit[6,9;2,1;exit;Done]"


minetest.register_on_player_receive_fields(function(player, formname, fields)

	if formname == "testventure:merchant_form" then

		if fields["bacc"] then
		minetest.show_formspec(player:get_player_name(),"testventure:merchant_form", merchant_form) 
end

		if fields["basic_sword"] then
		minetest.show_formspec(player:get_player_name(),"testventure:merchant_form", basic_sword_form) 
end

		if fields["steel_arrow"] then
		minetest.show_formspec(player:get_player_name(),"testventure:merchant_form", steel_arrow_form) 
end

		if fields["torch"] then
		minetest.show_formspec(player:get_player_name(),"testventure:merchant_form", torch_form) 
end

		if fields["small_health"] then
		minetest.show_formspec(player:get_player_name(),"testventure:merchant_form", small_health_form) 
end

		if fields["health"] then
		minetest.show_formspec(player:get_player_name(),"testventure:merchant_form", health_form) 
end

		if fields["shuriken"] then
		minetest.show_formspec(player:get_player_name(),"testventure:merchant_form", shuriken_form) 
end

		if fields["throwing_knife"] then
		minetest.show_formspec(player:get_player_name(),"testventure:merchant_form", throwing_knife_form) 
end

		if fields["flare"] then
		minetest.show_formspec(player:get_player_name(),"testventure:merchant_form", flare_form) 
end

end
end)

--basic_Sword

basic_sword_form =
"size[5,10]"..
"label[1,0;Basic sword.]"..
"image[1,1;3.0,3.0;testventure_basic_sword.png]"..
"label[0.5,4;melee damage: 10]"..
"label[0.5,4.5;critical chance: 4%]"..
"label[0.5,5;Knockback: 7]"..
"label[0.5,5.5;Full punch interval: 0.9]"..
"label[0.5,6;Range: 4.20]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buybasicsword;Buy (1 gold)]"

--steel_arrow

steel_arrow_form =
"size[5,10]"..
"label[1,0;Steel arrow (x 12).]"..
"image[1,1;3.0,3.0;testventure_steel_arrow.png]"..
"label[0.5,4;Ammo damage: 3-5]"..
"label[0.5,4.5;Ammo critical: 2%]"..
"label[0.5,5;Ammo critical efficiency: 240%]"..
"label[0.5,5.5;Ammo knockback: 2]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buysteelarrow;Buy (2 silver)]"

--torch

torch_form =
"size[5,10]"..
"label[1,0;Torch (x4)]"..
"image[1,1;3.0,3.0;default_torch_on_floor.png]"..
"label[0.5,4;Provides light]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buytorch;Buy (50 copper)]"

--small_health

small_health_form =
"size[8,10]"..
"label[1,0;Small health potion.]"..
"image[1,1;3.0,3.0;testventure_health_potion_small.png]"..
"label[0.5,4;Restores 10hp, with capability of restoring special hearts]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buysmallhealth;Buy (90 copper)]"

--health

health_form =
"size[8,10]"..
"label[1,0;health potion.]"..
"image[1,1;3.0,3.0;testventure_health_potion.png]"..
"label[0.5,4;Restores 20hp, with capability of restoring special hearts]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buyhealth;Buy (5 silver)]"

--shuriken

shuriken_form =
"size[5,10]"..
"label[1,0;Shuriken (x10).]"..
"image[1,1;3.0,3.0;testventure_shuriken.png]"..
"label[0.5,4;Ranged damage: 2-5]"..
"label[0.5,4.5;accuracy: 95%]"..
"label[0.5,5;throwable gravitational pull: 5]"..
"label[0.5,5.5;knockback: 1]"..
"label[0.5,6;Critical chance: 4%]"..
"label[0.5,6.5;velocity: 25]"..
"label[0.5,7;Penetrates targets]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buyshuriken;Buy (2 silver)]"

--throwing_knife

throwing_knife_form =
"size[5,10]"..
"label[1,0;Throwing knife (x10).]"..
"image[1,1;3.0,3.0;testventure_throwing_knife.png]"..
"label[0.5,4;Ranged damage: 4-6]"..
"label[0.5,4.5;accuracy: 90%]"..
"label[0.5,5;throwable gravitational pull: 6]"..
"label[0.5,5.5;knockback: 2]"..
"label[0.5,6;Critical chance: 4%]"..
"label[0.5,6.5;velocity: 20]"..
"label[0.5,7;Penetrates targets]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buythrowingknife;Buy (3 silver)]"

flare_form =
"size[5,10]"..
"label[1,0;Flare (x16).]"..
"image[1,1;3.0,3.0;testventure_flare.png]"..
"label[0.5,4;Ammo damage: 2]"..
"label[0.5,4.5;Penetrates targets]"..
"label[0.5,5;Used by the flare gun]"..
"button[0,9;2,1;bacc;Back]"..
"button[2,9;3,1;buyflare;Buy (2 silver)]"

---
---buying
---

minetest.register_on_player_receive_fields(function(player, formname, fields)

---basic_sword
---
	if formname == "testventure:merchant_form" then
		if fields["buybasicsword"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_gold 1") then
		inv:remove_item("main", "testventure:coin_gold 1")
		inv:add_item("main", "testventure:sword_basic 1") 
	end
	end
----
---- steel_arrow
----
		if fields["buysteelarrow"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_silver 2") then
		inv:remove_item("main", "testventure:coin_silver 2")
		inv:add_item("main", "testventure:steel_arrow 12") 
	end
	end
----
---- torch
----
		if fields["buytorch"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_copper 50") then
		inv:remove_item("main", "testventure:coin_copper 50")
		inv:add_item("main", "default:torch 4") 
	end
	end
----
---- small_heal
----
		if fields["buysmallhealth"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_copper 90") then
		inv:remove_item("main", "testventure:coin_copper 90")
		inv:add_item("main", "testventure:health_potion_small 1") 
	end
	end
----
---- heal
----
		if fields["buyhealth"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_silver 5") then
		inv:remove_item("main", "testventure:coin_silver 5")
		inv:add_item("main", "testventure:health_potion 1") 
	end
	end
----
---- shuriken
----
		if fields["buyshuriken"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_silver 2") then
		inv:remove_item("main", "testventure:coin_silver 2")
		inv:add_item("main", "testventure:shuriken 10") 
	end
	end
----
---- throwing_knife
----
		if fields["buythrowingknife"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_silver 3") then
		inv:remove_item("main", "testventure:coin_silver 3")
		inv:add_item("main", "testventure:throwing_knife 10") 
	end
	end
----
----
---- flare
----
		if fields["buyflare"] then
	local inv = player:get_inventory()
	if inv:contains_item("main", "testventure:coin_silver 2") then
		inv:remove_item("main", "testventure:coin_silver 2")
		inv:add_item("main", "testventure:flare 16") 
	end
	end
----


end
end)