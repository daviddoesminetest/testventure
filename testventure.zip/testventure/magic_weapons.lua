--- blood scepter

	minetest.register_craftitem("testventure:blood_scepter", {
	stack_max= 1,
	wield_scale = {x=2.0,y=2.0,z=1.0},
		description = "" ..core.colorize("#00eaff","Blood scepter\n")..core.colorize("#FFFFFF", "Magic damage: 9-13\n")..core.colorize("#FFFFFF", "knockback: 2\n") ..core.colorize("#FFFFFF", "Critical chance: 4%\n") ..core.colorize("#FFFFFF", "Uses 14 mana\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.10\n") ..core.colorize("#FFFFFF", "Penetrates targets\n") ..core.colorize("#FFFFFF", "Projectile gravitational pull: 4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20"),
	range = 0,
	inventory_image = "testventure_blood_scepter.png",
})

local blood_ray = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.3, y=0.3},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
blood_ray.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	magic_dmg = magic_dmg or 1
	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.0)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:blood_ray" and 	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
			if math.random(1, 100) <= 4 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			local damage = math.random(27,39)* magic_dmg
		obj:punch(self.object, 1.0, {
		full_punch_interval = 1.0,
		damage_groups= {fleshy = damage , knockback = 4},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
			self.timer = 0.00
					else
		local damage = math.random(9,13)* magic_dmg
		obj:punch(self.object, 1.0, {
		full_punch_interval = 1.0,
		damage_groups= {fleshy = damage , knockback = 2},
					}, nil)
					minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.timer = 0.00
				end end
			else
				if math.random(1, 100) <= 4 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
	local damage = math.random(27,39)* magic_dmg
				obj:punch(self.object, 1.0, {
				full_punch_interval = 1.0,
				damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.timer = 0.00
				else
				local damage = math.random(9,13)* magic_dmg
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
						self.timer = 0.00
				end end
	local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-4, 4), y=math.random(-10, 1), z=math.random(-4, 4)},
		expirationtime = 0.5,
		size = 7,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_blood_particle.png",
		glow = 25,
	})
		tiem = tiem + 0.1
			end

		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then end
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()
	end end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end end end
minetest.register_entity("testventure:blood_ray", blood_ray )



--- oceanic trident

	minetest.register_craftitem("testventure:oceanic_trident", {
	stack_max= 1,
	wield_scale = {x=2.0,y=2.0,z=1.0},
		description = "" ..core.colorize("#00eaff","Oceanic trident\n")..core.colorize("#FFFFFF", "Magic damage: 4-6\n")..core.colorize("#FFFFFF", "knockback: 2\n") ..core.colorize("#FFFFFF", "Critical chance: 3%\n") ..core.colorize("#FFFFFF", "Uses 9 mana\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.10\n")..core.colorize("#FFFFFF", "Penetrates targets\n") ..core.colorize("#FFFFFF", "Projectile gravitational pull: 4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20"),
	range = 0,
	inventory_image = "testventure_oceanic_trident.png",
})

local water_ray = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.3, y=0.3},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
water_ray.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	magic_dmg = magic_dmg or 1
	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.0)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
			if obj:get_luaentity().name ~= "testventure:water_ray" and 
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
			if math.random(1, 100) <= 3 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			local damage = math.random(12,18)* magic_dmg
		obj:punch(self.object, 1.0, {
		full_punch_interval = 1.0,
		damage_groups= {fleshy = damage , knockback = 4},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
			self.timer = 0.00
					else
		local damage = math.random(4,6)* magic_dmg
		obj:punch(self.object, 1.0, {
		full_punch_interval = 1.0,
		damage_groups= {fleshy = damage , knockback = 2},
					}, nil)
					minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.timer = 0.00
				end end
			else
				if math.random(1, 100) <= 3 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
	local damage = math.random(12,18)* magic_dmg
				obj:punch(self.object, 1.0, {
				full_punch_interval = 1.0,
				damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.timer = 0.00
				else
				local damage = math.random(4,6)* magic_dmg
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
						self.timer = 0.00
				end end
	local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-4, 4), y=math.random(-10, 1), z=math.random(-4, 4)},
		expirationtime = 0.5,
		size = 7,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_water_particle.png",
		glow = 25,
	})
		tiem = tiem + 0.1
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then end
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()
	end end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end end end
minetest.register_entity("testventure:water_ray", water_ray )


--- amethyst staff

	minetest.register_craftitem("testventure:amethyst_staff", {
	stack_max= 1,
	wield_scale = {x=1.0,y=1.0,z=1.0},
		description = "" ..core.colorize("#00eaff"," amethyst staff\n")..core.colorize("#FFFFFF", "Magic damage: 5-8\n")..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 10%\n") ..core.colorize("#FFFFFF", "Uses 12 mana\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20"),
	range = 0,
	inventory_image = "testventure_amethyst_staff.png",
})


local amethyst_ray = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.3, y=0.3},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
amethyst_ray.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	magic_dmg = magic_dmg or 1
	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.33)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:amethyst_ray" and 
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
			if math.random(1, 100) <= 10 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			local damage = math.random(15,24)* magic_dmg
		obj:punch(self.object, 1.0, {
		full_punch_interval = 1.0,
		damage_groups= {fleshy = damage , knockback = 10},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
					else
		local damage = math.random(5,8)* magic_dmg
		obj:punch(self.object, 1.0, {
		full_punch_interval = 1.0,
		damage_groups= {fleshy = damage , knockback = 5},
					}, nil)
					minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end end
			else
				if math.random(1, 100) <= 10 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
	local damage = math.random(15,24)* magic_dmg
				obj:punch(self.object, 1.0, {
				full_punch_interval = 1.0,
				damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				else
				local damage = math.random(5,8)* magic_dmg
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end end
	local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-4, 4), y=math.random(-4, 4), z=math.random(-4, 4)},
		expirationtime = 0.25,
		size = 5,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_amethyst_ray.png",
		glow = 25,
	})
		tiem = tiem + 0.1 
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then end
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()
	end end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end end end
minetest.register_entity("testventure:amethyst_ray", amethyst_ray )


--- topaz staff

	minetest.register_craftitem("testventure:topaz_staff", {
	stack_max= 1,
	wield_scale = {x=1.0,y=1.0,z=1.0},
		description = "" ..core.colorize("#00eaff"," topaz staff\n")..core.colorize("#FFFFFF", "Magic damage: 7-11\n")..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 11%\n") ..core.colorize("#FFFFFF", "Uses 14 mana\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20"),
	range = 0,
	inventory_image = "testventure_topaz_staff.png",
})


local topaz_ray = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.3, y=0.3},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
topaz_ray.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	magic_dmg = magic_dmg or 1
	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.33)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:topaz_ray" and 
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
			if math.random(1, 100) <= 11 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					local damage = math.random(21,33)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 10},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
					else
					local damage = math.random(7,11)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 5},
					}, nil)
					minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
				if math.random(1, 100) <= 11 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
				local damage = math.random(21,33)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				else
				local damage = math.random(7,11)* magic_dmg
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
	local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-4, 4), y=math.random(-4, 4), z=math.random(-4, 4)},
		expirationtime = 0.25,
		size = 5,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_topaz_ray.png",
		glow = 25,
	})
		tiem = tiem + 0.1
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			end
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end



minetest.register_entity("testventure:topaz_ray", topaz_ray )


--- emerald staff

	minetest.register_craftitem("testventure:emerald_staff", {
	stack_max= 1,
	wield_scale = {x=1.0,y=1.0,z=1.0},
		description = "" ..core.colorize("#00eaff"," emerald staff\n")..core.colorize("#FFFFFF", "Magic damage: 10-15\n")..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 12%\n") ..core.colorize("#FFFFFF", "Uses 17 mana\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20"),
	range = 0,
	inventory_image = "testventure_emerald_staff.png",
})

local emerald_ray = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.3, y=0.3},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
emerald_ray.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	magic_dmg = magic_dmg or 1
	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.33)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:emerald_ray" and 
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
			if math.random(1, 100) <= 12 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					local damage = math.random(30,45)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 10},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
					else
					local damage = math.random(10,15)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 5},
					}, nil)
					minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
				if math.random(1, 100) <= 12 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
				local damage = math.random(30,45)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				else
				local damage = math.random(10,15)* magic_dmg
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
	local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-4, 4), y=math.random(-4, 4), z=math.random(-4, 4)},
		expirationtime = 0.25,
		size = 5,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_emerald_ray.png",
		glow = 25,
	})
		tiem = tiem + 0.1 
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			end
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end



minetest.register_entity("testventure:emerald_ray", emerald_ray )

--- sapphire staff

	minetest.register_craftitem("testventure:sapphire_staff", {
	stack_max= 1,
	wield_scale = {x=1.0,y=1.0,z=1.0},
		description = "" ..core.colorize("#00eaff"," sapphire staff\n")..core.colorize("#FFFFFF", "Magic damage: 16-22\n")..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 13%\n") ..core.colorize("#FFFFFF", "Uses 21 mana\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20"),
	range = 0,
	inventory_image = "testventure_sapphire_staff.png",
})

local sapphire_ray = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.3, y=0.3},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
sapphire_ray.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	magic_dmg = magic_dmg or 1
	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.33)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:sapphire_ray" and 
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
			if math.random(1, 100) <= 13 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					local damage = math.random(48,63)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 10},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
					else
					local damage = math.random(16,21)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 5},
					}, nil)
					minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
				if math.random(1, 100) <= 13 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
				local damage = math.random(48,63)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				else
				local damage = math.random(16,21)* magic_dmg
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
	local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-4, 4), y=math.random(-4, 4), z=math.random(-4, 4)},
		expirationtime = 0.25,
		size = 5,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_sapphire_ray.png",
		glow = 25,
	})
		tiem = tiem + 0.1
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			end
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end



minetest.register_entity("testventure:sapphire_ray", sapphire_ray )

--- ruby staff

	minetest.register_craftitem("testventure:ruby_staff", {
	stack_max= 1,
	wield_scale = {x=1.0,y=1.0,z=1.0},
		description = "" ..core.colorize("#00eaff"," ruby staff\n")..core.colorize("#FFFFFF", "Magic damage: 22-29\n")..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 14%\n") ..core.colorize("#FFFFFF", "Uses 30 mana\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20"),
	range = 0,
	inventory_image = "testventure_ruby_staff.png",
})


local ruby_ray = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.3, y=0.3},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
ruby_ray.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	magic_dmg = magic_dmg or 1
	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.33)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:ruby_ray" and 
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
			if math.random(1, 100) <= 14 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					local damage = math.random(66,87)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 10},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
					else
					local damage = math.random(22,29)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 5},
					}, nil)
					minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
				if math.random(1, 100) <= 14 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
				local damage = math.random(66,87)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				else
				local damage = math.random(22,29)* magic_dmg
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
	local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-4, 4), y=math.random(-4, 4), z=math.random(-4, 4)},
		expirationtime = 0.25,
		size = 5,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_ruby_ray.png",
		glow = 25,
	})
		tiem = tiem + 0.1
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			end
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end



minetest.register_entity("testventure:ruby_ray", ruby_ray )

--- diamond staff

	minetest.register_craftitem("testventure:diamond_staff", {
	stack_max= 1,
	wield_scale = {x=1.0,y=1.0,z=1.0},
		description = "" ..core.colorize("#00eaff"," diamond staff\n")..core.colorize("#FFFFFF", "Magic damage: 32-38\n")..core.colorize("#FFFFFF", "knockback: 5\n") ..core.colorize("#FFFFFF", "Critical chance: 16%\n") ..core.colorize("#FFFFFF", "Uses 40 mana\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.4\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20"),
	range = 0,
	inventory_image = "testventure_diamond_staff.png",
})

local diamond_ray = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.3, y=0.3},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
diamond_ray.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	magic_dmg = magic_dmg or 1
	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.33)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:diamond_ray" and 	
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
			if math.random(1, 100) <= 16 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					local damage = math.random(96,114)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 10},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
					else
					local damage = math.random(32,38)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 5},
					}, nil)
					minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
				if math.random(1, 100) <= 16 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
				local damage = math.random(96,114)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				else
				local damage = math.random(32,38)* magic_dmg
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
	local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-4, 4), y=math.random(-4, 4), z=math.random(-4, 4)},
		expirationtime = 0.25,
		size = 5,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_diamond_ray.png",
		glow = 25,
	})
		tiem = tiem + 0.1
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			end
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end



minetest.register_entity("testventure:diamond_ray", diamond_ray )



--- niobium staff

	minetest.register_craftitem("testventure:niobium_staff", {
	stack_max= 1,
	wield_scale = {x=1.8,y=1.8,z=1.8},
		description = "" ..core.colorize("#2a00ff"," niobium staff\n")..core.colorize("#FFFFFF", "Magic damage: 29-34\n")..core.colorize("#FFFFFF", "knockback: 4\n") ..core.colorize("#FFFFFF", "Critical chance: 15%\n") ..core.colorize("#FFFFFF", "Uses 35 mana\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.3\n")..core.colorize("#FFFFFF", "Penetrates targets\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20"),
	range = 0,
	inventory_image = "testventure_niobium_staff.png",
})


local niobium_ray = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.3, y=0.3},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
niobium_ray.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	magic_dmg = magic_dmg or 1
	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.33)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:niobium_ray" and 
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
		if math.random(1, 100) <= 15 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					local damage = math.random(87,101)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 8},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
					self.timer = 0.00
					else
					local damage = math.random(29,34)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage , knockback = 4},
					}, nil)
					minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.timer = 0.00
				end
			end
			else
				if math.random(1, 100) <= 15 + magic_crit then
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
				local damage = math.random(87,101)* magic_dmg
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
				self.timer = 0.00
				else
				local damage = math.random(29,34)* magic_dmg
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("magic_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.timer = 0.00
				end
			end
	local tiem = 0.02
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-4, 4), y=math.random(-4, 4), z=math.random(-4, 4)},
		expirationtime = 0.25,
		size = 5,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_niobium_ray.png",
		glow = 25,
	})
		tiem = tiem + 0.1
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			end
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end



minetest.register_entity("testventure:niobium_ray", niobium_ray )
