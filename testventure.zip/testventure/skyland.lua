skyland_table = {
  "/schematics/skypool.mts",
  "/schematics/skypool.mts",
  "/schematics/skyhouse.mts",
  "/schematics/skywaterfall.mts",
  "/schematics/skywaterfall.mts",
  "/schematics/skyland.mts",
  "/schematics/skyland.mts",
  "/schematics/skyland.mts",
  "/schematics/skyland.mts",
}

minetest.register_on_generated(function(minp, maxp)
	if maxp.y < 509 or maxp.y > 530 then
		return
	end

	for n = 1,math.random(1,100) do

			local pos = {x = math.random(minp.x,maxp.x), y = math.random(minp.y,maxp.y), z = math.random(minp.z,maxp.z)}
				if minetest.get_node({x=pos.x, y=pos.y, z=pos.z}).name == "air" and pos.y > 500 then
	if pos.y < 510 then
	minetest.place_schematic(pos, minetest.get_modpath("testventure") .. skyland_table[math.random(#skyland_table)],"random",nil, true)


end
end
end
end)




	minetest.register_ore({
		ore_type        = "blob",
		ore             = "testventure:thick_cloud",
		wherein         = {"air"},
		clust_scarcity  = 32 * 32 * 32,
		clust_size      = 8,
		y_min           = 500,
		y_max           = 540,
		noise_threshold = 0.0,
		noise_params    = {
			offset = 0.5,
			scale = 0.2,
			spread = {x = 5, y = 5, z = 5},
			seed = 17000,
			octaves = 1,
			persist = 0.0
		},
	})


	minetest.register_ore({
		ore_type        = "blob",
		ore             = "testventure:rain_cloud",
		wherein         = {"air"},
		clust_scarcity  = 50 * 50 * 50,
		clust_size      = 8,
		y_min           = 500,
		y_max           = 540,
		noise_threshold = 0.0,
		noise_params    = {
			offset = 0.5,
			scale = 0.2,
			spread = {x = 5, y = 5, z = 5},
			seed = 17000,
			octaves = 1,
			persist = 0.0
		},
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:cloudantite_ore",
		wherein        = "testventure:skystone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = 450,
		y_max          = 550,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:skytree_seed",
		wherein        = "testventure:grassy_skydirt",
		clust_scarcity = 4 * 4 * 4,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = 450,
		y_max          = 550,
	})
minetest.register_node("testventure:cloudantite_ore", {
		description = "".. core.colorize("#00eaff", "Cloudantite Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_skystone.png^testventure_cloudantite_ore.png"},
	groups = {cracky = 1,is_ore=1,rare_ore=1},
	drop = "testventure:cloudantite_lump 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_craftitem("testventure:cloudantite_lump", {
		description = "".. core.colorize("#00eaff", "Cloudantite lump\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_cloudantite_lump.png",
	stack_max= 999,
})
minetest.register_craftitem("testventure:cloudantite_bar", {
		description = "".. core.colorize("#00eaff", "Cloudantite bar\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_cloudantite_bar.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:skywood_stick", {
		description = "".. core.colorize("#00eaff", "Skywood stick\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_skywood_stick.png",
	groups = {stick = 1},
	stack_max= 999,
})

minetest.register_node("testventure:skydirt", {
		description = "".. core.colorize("#00eaff", "sky dirt\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_skydirt.png"},
	stack_max= 999,
	groups = {crumbly = 3},
	sunlight_propagates = true,
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("testventure:skywood", {
		description = "".. core.colorize("#00eaff", "Skywood planks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_skywood.png"},
	stack_max= 999,
	groups = {choppy = 3,oddly_breakable_by_hand=3},
	sunlight_propagates = true,
	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("testventure:skystone", {
		description = "".. core.colorize("#00eaff", "Skystone\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_skystone.png"},
	stack_max= 999,
	groups = {cracky = 3},
	sunlight_propagates = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:sky_window", {
		description = "".. core.colorize("#00eaff", "Sky window\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_sky_window.png"},
	drawtype = "glasslike",
	stack_max= 999,
	groups = {cracky = 3,oddly_breakable_by_hand=3},
	sunlight_propagates = true,
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_node("testventure:skystone_bricks", {
		description = "".. core.colorize("#00eaff", "Skystone bricks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_skystone_bricks.png"},
	stack_max= 999,
	groups = {cracky = 3},
	sunlight_propagates = true,
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:skystone_roofing", {
		description = "".. core.colorize("#00eaff", "Skystone roofing\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_skystone_roofing.png"},
	stack_max= 999,
	groups = {cracky = 3},
	sunlight_propagates = true,
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:skystone_carving", {
		description = "".. core.colorize("#00eaff", "Skystone carving\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_skystone_carving.png"},
	stack_max= 999,
	groups = {cracky = 3},
	sunlight_propagates = true,
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:skystone_pillar", {
		description = "".. core.colorize("#00eaff", "Skystone pillar\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_skystone_pillar_top.png", "testventure_skystone_pillar_top.png", "testventure_skystone_pillar_side.png"},
	stack_max= 999,
	groups = {cracky = 3},
	sunlight_propagates = true,
	paramtype2 = "facedir",
	sounds = default.node_sound_stone_defaults(),
	on_place = minetest.rotate_node,
})

minetest.register_node("testventure:grassy_skydirt", {
		description = "".. core.colorize("#00eaff", "Grassy sky dirt\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_sky_grass_top.png", "testventure_skydirt.png",
		{name = "testventure_skydirt.png^testventure_sky_grass_side.png",
			tileable_vertical = false}},
	groups = {crumbly = 3},
	sunlight_propagates = true,
	drop = "testventure:skydirt 1",
	stack_max= 999,
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_grass_footstep", gain = 0.25},
	}),
})

minetest.register_node("testventure:thick_cloud", {
		description = "".. core.colorize("#00eaff", "Thick cloud\n")..core.colorize("#FFFFFF", "Reduces falling damage by 90% and is slightly bouncy\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_thick_cloud.png"},
	groups = {oddly_breakable_by_hand = 3, fall_damage_add_percent=-90, bouncy = 40},
	sunlight_propagates = true,
	light_source = 2,
	stack_max= 999,
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("testventure:rain_cloud", {
		description = "".. core.colorize("#00eaff", "Rain cloud\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_rain_cloud.png"},
	stack_max= 999,
	groups = {oddly_breakable_by_hand = 3},
	sunlight_propagates = true,
	sounds = default.node_sound_dirt_defaults(),
})


minetest.register_node("testventure:sky_water_source", {
	description = "sky water Source",
	drawtype = "liquid",
	tiles = {
		{
		name = "testventure_sky_water_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	special_tiles = {
		{
			name = "testventure_sky_water_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
			backface_culling = false,
		},
	},
	alpha = 175,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	sunlight_propagates = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "testventure:sky_water_flowing",
	liquid_alternative_source = "testventure:sky_water_source",
	liquid_viscosity = 1,
	light_source = 6,
	post_effect_color = {a = 100, r = 0, g = 100, b = 200},
	groups = {water = 3, liquid = 3, puts_out_fire = 1, cools_lava = 1},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_node("testventure:sky_water_flowing", {
	description = "Flowing sky water",
	drawtype = "flowingliquid",
	tiles = {"testventure_sky_water.png"},
	special_tiles = {
		{
			name = "testventure_sky_water_flowing_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = "testventure_sky_water_flowing_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = 175,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	sunlight_propagates = true,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "testventure:sky_water_flowing",
	liquid_alternative_source = "testventure:sky_water_source",
	liquid_viscosity = 1,
	light_source = 6,
	post_effect_color = {a = 100, r = 0, g = 100, b = 200},
	groups = {water = 3, liquid = 3, puts_out_fire = 1,
		not_in_creative_inventory = 1, cools_lava = 1},
	sounds = default.node_sound_water_defaults(),
})




bucket.register_liquid(
	"testventure:sky_water_source",
	"testventure:sky_water_flowing",
	"testventure:bucket_sky_water",
	"bucket_sky_water.png",
	"".. core.colorize("#00eaff", "Sky water bucket\n")..core.colorize("#FFFFFF", "A Liquid"),
	{sky_water_bucket = 1}
)

minetest.register_node("testventure:sky_treasure", {
		description = "".. core.colorize("#00eaff", "Sky treasure\n")..core.colorize("#FFFFFF", "Contains some booty!"),
	tiles = {
		"testventure_sky_treasure_top.png", "testventure_sky_treasure_top.png",
		"testventure_sky_treasure_side.png", "testventure_sky_treasure_side.png",
		"testventure_sky_treasure_side.png", "testventure_sky_treasure_front.png"
	},
	groups = {oddly_breakable_by_hand = 3},
	paramtype2 = "facedir",
	drop = "",
	stack_max= 999,
	on_blast = function() end,
	sounds = default.node_sound_stone_defaults(),
})

sky_booty_table = {
  "testventure:arrowstorm 1",
  "testventure:sword_fallingstar 1",
}

minetest.register_on_dignode(function(pos, oldnode, digger)
	if digger ~= nil and digger:is_player() then
	if oldnode.name == "testventure:sky_treasure" then
	for i=1,math.random(2,4) do
local booty = minetest.add_item(pos, booty_table[math.random(#booty_table)])
end
end
end
end)
minetest.register_on_dignode(function(pos, oldnode, digger)
	if digger ~= nil and digger:is_player() then
	if oldnode.name == "testventure:sky_treasure" then
local booty = minetest.add_item(pos, sky_booty_table[math.random(#sky_booty_table)])
end
end
end)

minetest.register_node("testventure:sky_leaves", {
		description = "".. core.colorize("#00eaff", "Sky leaves\n")..core.colorize("#FFFFFF", "A placable block"),
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"testventure_sky_leaves.png"},
	stack_max= 999,
	paramtype = "light",
	is_ground_content = false,
	sunlight_propagates = true,
	groups = {snappy = 3, flammable = 2, leaves = 1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("testventure:skywood_log", {
		description = "".. core.colorize("#00eaff", "Skywood log\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_skywood_log_top.png", "testventure_skywood_log_top.png", "testventure_skywood_log_side.png"},
	stack_max= 999,
	groups = {choppy = 1,oddly_breakable_by_hand=1},
	sunlight_propagates = true,
	paramtype2 = "facedir",
	sounds = default.node_sound_wood_defaults(),
	on_place = minetest.rotate_node,
})

minetest.register_node("testventure:skytree_seed", {
		description = "".. core.colorize("#00eaff", "Bloodstone\n")..core.colorize("#FFFFFF", "YOU HACKER! YOU!"),
	tiles = {"testventure_skydirt.png"},
	drop = "",
	groups = {cracky = 4,not_in_creative_inventory=1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_abm({
	nodenames = {"testventure:skytree_seed"},
	interval = 1,
	chance = 1,
	catch_up = false,
	action = function(pos, node)
	pos.y = pos.y+1
	if minetest.get_node(pos).name == "testventure:sky_water_source" or minetest.get_node(pos).name == "testventure:sky_water_flowing" then
	pos.y = pos.y-1
	node.name = "testventure:grassy_skydirt"
	minetest.set_node(pos, node)
else
	pos.y = pos.y-1
	node.name = "testventure:skydirt"
	minetest.set_node(pos, node)
	pos.x = pos.x - 4
	pos.y = pos.y - 0
	pos.z = pos.z - 4
	minetest.place_schematic(pos, minetest.get_modpath("testventure") .. "/schematics/skytree.mts","random",nil, false)
	end
	end
})

minetest.register_abm({
	nodenames = {"testventure:rain_cloud"},
	interval = 1,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y-1
		if minetest.get_node(pos).name == "air" then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-0.25,0.25), y=math.random(-5.0,-20.0), z=math.random(-0.25,0.25)},
		expirationtime = 2.0,
		size = 5,
		collisiondetection = true,
		collision_removal = true,
		vertical = true,
		texture = "testventure_raindrop.png",
		glow = 3,
	})
		end
	end
})