--
-- what's cookin' doc?
--

minetest.register_craft({
	type = "cooking",
	cooktime = 11,
	output = "testventure:niobium_bar",
	recipe = "testventure:niobium_lump",
})


minetest.register_craft({
	type = "cooking",
	cooktime = 7,
	output = "testventure:crimrubite_bar",
	recipe = "testventure:crimrubite_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 6,
	output = "testventure:shadowsteel_bar",
	recipe = "testventure:shadowsteel_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 8,
	output = "testventure:black_silver_bar",
	recipe = "testventure:black_silver_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 7,
	output = "testventure:smaranium_bar",
	recipe = "testventure:smaranium_lump",
})
minetest.register_craft({
	type = "cooking",
	cooktime = 7,
	output = "testventure:cloudantite_bar",
	recipe = "testventure:cloudantite_lump",
})

--
-- what are we cooking on??
--

minetest.register_craft({
	type = "fuel",
	recipe = "testventure:slimeball",
	burntime = 16,
})

minetest.register_craft({
	type = "fuel",
	recipe = "testventure:crimson_slimeball",
	burntime = 34,
})

minetest.register_craft({
	type = "fuel",
	recipe = "testventure:pink_slimeball",
	burntime = 30,
})

minetest.register_craft({
	type = "fuel",
	recipe = "testventure:sandy_slimeball",
	burntime = 25,
})

minetest.register_craft({
	type = "fuel",
	recipe = "testventure:frozen_slimeball",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "testventure:skywood",
	burntime = 13,
})

minetest.register_craft({
	type = "fuel",
	recipe = "testventure:sky_tree",
	burntime = 36,
})

minetest.register_craft({
	type = "fuel",
	recipe = "testventure:darkwood",
	burntime = 12,
})

minetest.register_craft({
	type = "fuel",
	recipe = "testventure:dark_tree",
	burntime = 30,
})

--
-- blocks
--

minetest.register_craft({
	output = 'default:water_source',
	recipe = {
		{"testventure:rain_cloud", "testventure:rain_cloud","testventure:rain_cloud"},
		{"testventure:rain_cloud", "testventure:rain_cloud","testventure:rain_cloud"},
		{"testventure:rain_cloud", "testventure:rain_cloud","testventure:rain_cloud"},
	}
})

minetest.register_craft({
	output = 'testventure:skystone_pillar 3',
	recipe = {
		{'testventure:skystone_bricks'},
		{'testventure:skystone_bricks'},
		{'testventure:skystone_bricks'},
	}
})

minetest.register_craft({
	output = 'testventure:skystone_carving 4',
	recipe = {
	{'testventure:skystone_bricks','testventure:skystone_bricks'},
	{'testventure:skystone_bricks','testventure:skystone_bricks'},
	}
})

minetest.register_craft({
	output = 'testventure:skystone_roofing 4',
	recipe = {
	{'testventure:skystone_carving','testventure:skystone_carving'},
	{'testventure:skystone_carving','testventure:skystone_carving'},
	}
})

minetest.register_craft({
	output = 'testventure:skystone_bricks 4',
	recipe = {
		{'testventure:skystone','testventure:skystone'},
		{'testventure:skystone','testventure:skystone'},
	}
})

minetest.register_craft({
	output = 'testventure:marble_bricks 4',
	recipe = {
		{'testventure:marble','testventure:marble'},
		{'testventure:marble','testventure:marble'},
	}
})

minetest.register_craft({
	output = 'default:furnace 1',
	recipe = {
	{'testventure:skystone','testventure:skystone','testventure:skystone'},
	{'testventure:skystone','','testventure:skystone'},
	{'testventure:skystone','testventure:skystone','testventure:skystone'},
	}
})

minetest.register_craft({
	output = 'testventure:skywood 4',
	recipe = {
		{'testventure:skywood_log'},
	}
})

minetest.register_craft({
	output = 'testventure:sky_window 3',
	recipe = {
		{'testventure:skywood','default:glass','testventure:skywood'},
	}
})

minetest.register_craft({
	output = 'testventure:bloodstone_bricks 4',
	recipe = {
		{'testventure:bloodstone','testventure:bloodstone'},
		{'testventure:bloodstone','testventure:bloodstone'},
	}
})

minetest.register_craft({
	output = 'testventure:wooden_support 3',
	recipe = {
		{'default:tree'},
		{'default:tree'},
	}
})

minetest.register_craft({
	output = 'testventure:planked_rocks 3',
	recipe = {
		{'default:cobble'},
		{'default:wood'},
		{'default:cobble'},
	}
})

minetest.register_craft({
	output = 'default:torch 3',
	recipe = {
		{'testventure:slimeball'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'default:torch 4',
	recipe = {
		{'testventure:crimson_slimeball'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'testventure:aquastone_brick 4',
	recipe = {
		{"testventure:aquastone", "testventure:aquastone"},
		{"testventure:aquastone", "testventure:aquastone"},
	}
})

minetest.register_craft({
	output = 'testventure:purple_encrusted_block 3',
	recipe = {
		{"", "testventure:amethyst",""},
		{"testventure:amethyst", "default:glass","testventure:amethyst"},
		{"", "default:cobble",""},
	}
})
minetest.register_craft({
	output = 'testventure:blue_encrusted_block 3',
	recipe = {
		{"", "testventure:sapphire",""},
		{"testventure:sapphire", "default:glass","testventure:sapphire"},
		{"", "default:cobble",""},
	}
})
minetest.register_craft({
	output = 'testventure:green_encrusted_block 3',
	recipe = {
		{"", "testventure:emerald",""},
		{"testventure:emerald", "default:glass","testventure:emerald"},
		{"", "default:cobble",""},
	}
})
minetest.register_craft({
	output = 'testventure:orange_encrusted_block 3',
	recipe = {
		{"", "testventure:topaz",""},
		{"testventure:topaz", "default:glass","testventure:topaz"},
		{"", "default:cobble",""},
	}
})
minetest.register_craft({
	output = 'testventure:red_encrusted_block 3',
	recipe = {
		{"", "testventure:ruby",""},
		{"testventure:ruby", "default:glass","testventure:ruby"},
		{"", "default:cobble",""},
	}
})
minetest.register_craft({
	output = 'testventure:cyan_encrusted_block 3',
	recipe = {
		{"", "testventure:aquamarine_shards",""},
		{"testventure:aquamarine_shards", "default:glass","testventure:aquamarine_shards"},
		{"", "default:cobble",""},
	}
})
minetest.register_craft({
	output = 'testventure:white_encrusted_block 3',
	recipe = {
		{"", "default:diamond",""},
		{"default:diamond", "default:glass","default:diamond"},
		{"", "default:cobble",""},
	}
})
minetest.register_craft({
	output = 'testventure:yellow_encrusted_block 3',
	recipe = {
		{"", "default:mese_crystal",""},
		{"default:mese_crystal", "default:glass","default:mese_crystal"},
		{"", "default:cobble",""},
	}
})

minetest.register_craft({
	output = 'testventure:skywood_stick 4',
	recipe = {
		{"testventure:skywood"},
	}
})


minetest.register_craft({
	output = 'testventure:grass_rope 1',
	recipe = {
		{"default:junglegrass"},
		{"default:junglegrass"},
		{"default:junglegrass"},
	}
})

minetest.register_craft({
	output = 'testventure:grass_rope 1',
	recipe = {
		{"testventure:vine"},
		{"testventure:vine"},
	}
})

minetest.register_craft({
	output = 'testventure:grass_rope 1',
	recipe = {
		{"","default:leaves","default:leaves" },
		{"default:leaves","default:leaves","default:leaves" },
		{"default:leaves","default:leaves","" },
	}
})

minetest.register_craft({
	output = 'testventure:darkwood 3',
	recipe = {
		{"testventure:dark_tree"},
	}
})

-- slimeblox

minetest.register_craft({
	output = 'testventure:slime_block',
	recipe = {
		{"testventure:slimeball", "testventure:slimeball","testventure:slimeball"},
		{"testventure:slimeball", "testventure:slimeball","testventure:slimeball"},
		{"testventure:slimeball", "testventure:slimeball","testventure:slimeball"},
	}
})

minetest.register_craft({
	output = 'testventure:magic_slime_block',
	recipe = {
		{"testventure:magic_slimeball", "testventure:magic_slimeball","testventure:magic_slimeball"},
		{"testventure:magic_slimeball", "testventure:magic_slimeball","testventure:magic_slimeball"},
		{"testventure:magic_slimeball", "testventure:magic_slimeball","testventure:magic_slimeball"},
	}
})

minetest.register_craft({
	output = 'testventure:pink_slime_block',
	recipe = {
		{"testventure:pink_slimeball", "testventure:pink_slimeball","testventure:pink_slimeball"},
		{"testventure:pink_slimeball", "testventure:pink_slimeball","testventure:pink_slimeball"},
		{"testventure:pink_slimeball", "testventure:pink_slimeball","testventure:pink_slimeball"},
	}
})

minetest.register_craft({
	output = 'testventure:sandy_slime_block',
	recipe = {
		{"testventure:sandy_slimeball", "testventure:sandy_slimeball","testventure:sandy_slimeball"},
		{"testventure:sandy_slimeball", "testventure:sandy_slimeball","testventure:sandy_slimeball"},
		{"testventure:sandy_slimeball", "testventure:sandy_slimeball","testventure:sandy_slimeball"},
	}
})

minetest.register_craft({
	output = 'testventure:crimson_slime_block',
	recipe = {
		{"testventure:crimson_slimeball", "testventure:crimson_slimeball","testventure:crimson_slimeball"},
		{"testventure:crimson_slimeball", "testventure:crimson_slimeball","testventure:crimson_slimeball"},
		{"testventure:crimson_slimeball", "testventure:crimson_slimeball","testventure:crimson_slimeball"},
	}
})

minetest.register_craft({
	output = 'testventure:frozen_slime_block',
	recipe = {
		{"testventure:frozen_slimeball", "testventure:frozen_slimeball","testventure:frozen_slimeball"},
		{"testventure:frozen_slimeball", "testventure:frozen_slimeball","testventure:frozen_slimeball"},
		{"testventure:frozen_slimeball", "testventure:frozen_slimeball","testventure:frozen_slimeball"},
	}
})

-- oreblox

minetest.register_craft({
	output = 'testventure:amethyst_block',
	recipe = {
		{"testventure:amethyst", "testventure:amethyst","testventure:amethyst"},
		{"testventure:amethyst", "testventure:amethyst","testventure:amethyst"},
		{"testventure:amethyst", "testventure:amethyst","testventure:amethyst"},
	}
})

minetest.register_craft({
	output = 'testventure:amethyst 9',
	recipe = {
		{"testventure:amethyst_block"},
	}
})
minetest.register_craft({
	output = 'testventure:topaz_block',
	recipe = {
		{"testventure:topaz", "testventure:topaz","testventure:topaz"},
		{"testventure:topaz", "testventure:topaz","testventure:topaz"},
		{"testventure:topaz", "testventure:topaz","testventure:topaz"},
	}
})

minetest.register_craft({
	output = 'testventure:topaz 9',
	recipe = {
		{"testventure:topaz_block"},
	}
})
minetest.register_craft({
	output = 'testventure:emerald_block',
	recipe = {
		{"testventure:emerald", "testventure:emerald","testventure:emerald"},
		{"testventure:emerald", "testventure:emerald","testventure:emerald"},
		{"testventure:emerald", "testventure:emerald","testventure:emerald"},
	}
})

minetest.register_craft({
	output = 'testventure:emerald 9',
	recipe = {
		{"testventure:emerald_block"},
	}
})
minetest.register_craft({
	output = 'testventure:sapphire_block',
	recipe = {
		{"testventure:sapphire", "testventure:sapphire","testventure:sapphire"},
		{"testventure:sapphire", "testventure:sapphire","testventure:sapphire"},
		{"testventure:sapphire", "testventure:sapphire","testventure:sapphire"},
	}
})

minetest.register_craft({
	output = 'testventure:sapphire 9',
	recipe = {
		{"testventure:sapphire_block"},
	}
})
minetest.register_craft({
	output = 'testventure:ruby_block',
	recipe = {
		{"testventure:ruby", "testventure:ruby","testventure:ruby"},
		{"testventure:ruby", "testventure:ruby","testventure:ruby"},
		{"testventure:ruby", "testventure:ruby","testventure:ruby"},
	}
})

minetest.register_craft({
	output = 'testventure:ruby 9',
	recipe = {
		{"testventure:ruby_block"},
	}
})

minetest.register_craft({
	output = 'testventure:niobium_block',
	recipe = {
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:niobium_bar 9',
	recipe = {
		{"testventure:niobium_block"},
	}
})

minetest.register_craft({
	output = 'testventure:cloudantite_block',
	recipe = {
		{"testventure:cloudantite_bar", "testventure:cloudantite_bar","testventure:cloudantite_bar"},
		{"testventure:cloudantite_bar", "testventure:cloudantite_bar","testventure:cloudantite_bar"},
		{"testventure:cloudantite_bar", "testventure:cloudantite_bar","testventure:cloudantite_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:cloudantite_bar 9',
	recipe = {
		{"testventure:cloudantite_block"},
	}
})

minetest.register_craft({
	output = 'testventure:black_silver_block',
	recipe = {
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:black_silver_bar 9',
	recipe = {
		{"testventure:black_silver_block"},
	}
})

minetest.register_craft({
	output = 'testventure:crimrubite_block',
	recipe = {
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:crimrubite_bar 9',
	recipe = {
		{"testventure:crimrubite_block"},
	}
})

minetest.register_craft({
	output = 'testventure:shadowsteel_block',
	recipe = {
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","testventure:shadowsteel_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:shadowsteel_bar 9',
	recipe = {
		{"testventure:shadowsteel_block"},
	}
})

minetest.register_craft({
	output = 'testventure:smaranium_block',
	recipe = {
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:smaranium_bar 9',
	recipe = {
		{"testventure:smaranium_block"},
	}
})

--
-- items
--

minetest.register_craft({
	output = 'testventure:darkness_spores 1',
	recipe = {
		{"testventure:darkshroom", "testventure:darkshroom", "testventure:darkshroom" },
		{"testventure:darkshroom", "testventure:darkshroom", "testventure:darkshroom"},
	}
})

--
-- tools
--

--skywood 
minetest.register_craft({
	output = 'testventure:pick_skywood',
	recipe = {
		{"testventure:skywood", "testventure:skywood","testventure:skywood"},
		{"", "testventure:skywood_stick",""},
		{"", "testventure:skywood_stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:sword_skywood',
	recipe = {
		{"", "testventure:skywood",""},
		{"", "testventure:skywood",""},
		{"", "testventure:skywood_stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_skywood',
	recipe = {
		{"testventure:skywood", "testventure:skywood",""},
		{"testventure:skywood", "testventure:skywood_stick",""},
		{"", "testventure:skywood_stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_skywood',
	recipe = {
		{"", "testventure:skywood","testventure:skywood"},
		{"", "testventure:skywood_stick","testventure:skywood"},
		{"", "testventure:skywood_stick",""},
	}
})

--cloudantite 
minetest.register_craft({
	output = 'testventure:pick_cloudantite',
	recipe = {
		{"testventure:cloudantite_bar", "testventure:cloudantite_bar","testventure:cloudantite_bar"},
		{"", "testventure:skywood_stick",""},
		{"", "testventure:skywood_stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:sword_cloudantite',
	recipe = {
		{"", "testventure:cloudantite_bar",""},
		{"", "testventure:cloudantite_bar",""},
		{"", "testventure:skywood_stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_cloudantite',
	recipe = {
		{"testventure:cloudantite_bar", "testventure:cloudantite_bar",""},
		{"testventure:cloudantite_bar", "testventure:skywood_stick",""},
		{"", "testventure:skywood_stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_cloudantite',
	recipe = {
		{"", "testventure:cloudantite_bar","testventure:cloudantite_bar"},
		{"", "testventure:skywood_stick","testventure:cloudantite_bar"},
		{"", "testventure:skywood_stick",""},
	}
})

--skystone 
minetest.register_craft({
	output = 'testventure:pick_skystone',
	recipe = {
		{"testventure:skystone", "testventure:skystone","testventure:skystone"},
		{"", "testventure:skywood_stick",""},
		{"", "testventure:skywood_stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:sword_skystone',
	recipe = {
		{"", "testventure:skystone",""},
		{"", "testventure:skystone",""},
		{"", "testventure:skywood_stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_skystone',
	recipe = {
		{"testventure:skystone", "testventure:skystone",""},
		{"testventure:skystone", "testventure:skywood_stick",""},
		{"", "testventure:skywood_stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_skystone',
	recipe = {
		{"", "testventure:skystone","testventure:skystone"},
		{"", "testventure:skywood_stick","testventure:skystone"},
		{"", "testventure:skywood_stick",""},
	}
})



--darkwood 
minetest.register_craft({
	output = 'testventure:pick_darkwood',
	recipe = {
		{"testventure:darkwood", "testventure:darkwood","testventure:darkwood"},
		{"", "group:stick",""},
		{"", "group:stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:sword_darkwood',
	recipe = {
		{"", "testventure:darkwood",""},
		{"", "testventure:darkwood",""},
		{"", "group:stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_darkwood',
	recipe = {
		{"testventure:darkwood", "testventure:darkwood",""},
		{"testventure:darkwood", "group:stick",""},
		{"", "group:stick",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_darkwood',
	recipe = {
		{"", "testventure:darkwood","testventure:darkwood"},
		{"", "group:stick","testventure:darkwood"},
		{"", "group:stick",""},
	}
})

--smaranium 
minetest.register_craft({
	output = 'testventure:pick_smaranium',
	recipe = {
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"", "default:steel_ingot",""},
		{"", "default:steel_ingot",""},
	}
})

minetest.register_craft({
	output = 'testventure:sword_smaranium',
	recipe = {
		{"", "testventure:smaranium_bar",""},
		{"", "testventure:smaranium_bar",""},
		{"", "default:steel_ingot",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_smaranium',
	recipe = {
		{"testventure:smaranium_bar", "testventure:smaranium_bar",""},
		{"testventure:smaranium_bar", "default:steel_ingot",""},
		{"", "default:steel_ingot",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_smaranium',
	recipe = {
		{"", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"", "default:steel_ingot","testventure:smaranium_bar"},
		{"", "default:steel_ingot",""},
	}
})


--aqua 
minetest.register_craft({
	output = 'testventure:oceanic_trident',
	recipe = {
		{"testventure:aquamarine_shards", "default:gold_ingot",""},
		{"testventure:aquamarine_shards", "default:goldblock","testventure:aquamarine_shards"},
		{"testventure:aquamarine_shards", "default:gold_ingot",""},
	}
})

minetest.register_craft({
	output = 'testventure:pick_aqua',
	recipe = {
		{"testventure:aquamarine_shards", "testventure:aquamarine_shards","testventure:aquastone"},
		{"", "default:gold_ingot","testventure:aquamarine_shards"},
		{"default:diamond", "","testventure:aquamarine_shards"},
	}
})

minetest.register_craft({
	output = 'testventure:sword_aqua',
	recipe = {
		{"", "","testventure:aquamarine_shards"},
		{"default:diamond", "testventure:aquamarine_shards",""},
		{"default:gold_ingot", "default:diamond",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_aqua',
	recipe = {
		{"testventure:aquamarine_shards", "testventure:aquastone","testventure:aquamarine_shards"},
		{"testventure:aquamarine_shards", "default:gold_ingot","testventure:aquamarine_shards"},
		{"", "default:diamond",""},
	}
})

--shadow

minetest.register_craft({
	output = 'testventure:pick_shadow',
	recipe = {
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","default:obsidian_shard"},
		{"", "default:obsidian_shard","testventure:shadowsteel_bar"},
		{"default:obsidian_shard", "","testventure:shadowsteel_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:sword_shadow',
	recipe = {
		{"", "","testventure:shadowsteel_bar"},
		{"default:obsidian_shard", "testventure:shadowsteel_bar",""},
		{"testventure:shadowsteel_bar", "default:obsidian_shard",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_shadow',
	recipe = {
		{"testventure:shadowsteel_bar", "default:obsidian_shard","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "default:obsidian_shard","testventure:shadowsteel_bar"},
		{"", "default:obsidian_shard",""},
	}
})

--crimson

minetest.register_craft({
	output = 'testventure:pick_crimson',
	recipe = {
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:bloodstone"},
		{"", "testventure:bloodstone","testventure:crimrubite_bar"},
		{"testventure:bloodstone", "","testventure:crimrubite_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:sword_crimson',
	recipe = {
		{"", "","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar",""},
		{"testventure:bloodstone", "testventure:crimrubite_bar",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_crimson',
	recipe = {
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "testventure:bloodstone","testventure:crimrubite_bar"},
		{"", "testventure:bloodstone",""},
	}
})

--black_silver

minetest.register_craft({
	output = 'testventure:pick_black_silver',
	recipe = {
		{"testventure:black_silver_bar", "testventure:black_silver_bar",""},
		{"", "testventure:shadowsteel_bar","testventure:black_silver_bar"},
		{"testventure:shadowsteel_bar", "","testventure:black_silver_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:sword_black_silver',
	recipe = {
		{"", "","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "testventure:black_silver_bar",""},
		{"testventure:shadowsteel_bar", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:axe_black_silver',
	recipe = {
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "testventure:shadowsteel_bar","testventure:black_silver_bar"},
		{"", "testventure:shadowsteel_bar",""},
	}
})



---
--- armor
---

-- darkwood

minetest.register_craft({
	output = 'testventure:helmet_darkwood',
	recipe = {
		{"testventure:darkwood", "testventure:darkwood","testventure:darkwood"},
		{"testventure:darkwood", "","testventure:darkwood"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_darkwood',
	recipe = {
		{"testventure:darkwood", "testventure:darkwood","testventure:darkwood"},
		{"testventure:darkwood", "","testventure:darkwood"},
		{"testventure:darkwood", "","testventure:darkwood"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_darkwood',
	recipe = {
		{"testventure:darkwood", "","testventure:darkwood"},
		{"testventure:darkwood", "testventure:darkwood","testventure:darkwood"},
		{"testventure:darkwood", "testventure:darkwood","testventure:darkwood"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_darkwood',
	recipe = {
		{"testventure:darkwood", "","testventure:darkwood"},
		{"testventure:darkwood", "","testventure:darkwood"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_darkwood',
	recipe = {
		{"testventure:darkwood", "testventure:darkwood","testventure:darkwood"},
		{"testventure:darkwood", "testventure:darkwood","testventure:darkwood"},
		{"", "testventure:darkwood",""},
	}
})

-- skywood

minetest.register_craft({
	output = 'testventure:helmet_skywood',
	recipe = {
		{"testventure:skywood", "testventure:skywood","testventure:skywood"},
		{"testventure:skywood", "","testventure:skywood"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_skywood',
	recipe = {
		{"testventure:skywood", "testventure:skywood","testventure:skywood"},
		{"testventure:skywood", "","testventure:skywood"},
		{"testventure:skywood", "","testventure:skywood"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_skywood',
	recipe = {
		{"testventure:skywood", "","testventure:skywood"},
		{"testventure:skywood", "testventure:skywood","testventure:skywood"},
		{"testventure:skywood", "testventure:skywood","testventure:skywood"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_skywood',
	recipe = {
		{"testventure:skywood", "","testventure:skywood"},
		{"testventure:skywood", "","testventure:skywood"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_skywood',
	recipe = {
		{"testventure:skywood", "testventure:skywood","testventure:skywood"},
		{"testventure:skywood", "testventure:skywood","testventure:skywood"},
		{"", "testventure:skywood",""},
	}
})


-- niobium

minetest.register_craft({
	output = 'testventure:helmet_niobium',
	recipe = {
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
		{"testventure:niobium_bar", "","testventure:niobium_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_niobium',
	recipe = {
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
		{"testventure:niobium_bar", "","testventure:niobium_bar"},
		{"testventure:niobium_bar", "","testventure:niobium_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_niobium',
	recipe = {
		{"testventure:niobium_bar", "","testventure:niobium_bar"},
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_niobium',
	recipe = {
		{"testventure:niobium_bar", "","testventure:niobium_bar"},
		{"testventure:niobium_bar", "","testventure:niobium_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_niobium',
	recipe = {
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
		{"", "testventure:niobium_bar",""},
	}
})


-- crimson

minetest.register_craft({
	output = 'testventure:helmet_crimson',
	recipe = {
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "","testventure:crimrubite_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_crimson',
	recipe = {
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "","testventure:crimrubite_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_crimson',
	recipe = {
		{"testventure:crimrubite_bar", "","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_crimson',
	recipe = {
		{"testventure:crimrubite_bar", "","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "","testventure:crimrubite_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_crimson',
	recipe = {
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
		{"testventure:crimrubite_bar", "testventure:crimrubite_bar","testventure:crimrubite_bar"},
		{"", "testventure:crimrubite_bar",""},
	}
})

-- shadow

minetest.register_craft({
	output = 'testventure:helmet_shadow',
	recipe = {
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "","testventure:shadowsteel_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_shadow',
	recipe = {
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "","testventure:shadowsteel_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_shadow',
	recipe = {
		{"testventure:shadowsteel_bar", "","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","testventure:shadowsteel_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_shadow',
	recipe = {
		{"testventure:shadowsteel_bar", "","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "","testventure:shadowsteel_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_shadow',
	recipe = {
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","testventure:shadowsteel_bar"},
		{"testventure:shadowsteel_bar", "testventure:shadowsteel_bar","testventure:shadowsteel_bar"},
		{"", "testventure:shadowsteel_bar",""},
	}
})

-- smaranium

minetest.register_craft({
	output = 'testventure:helmet_smaranium',
	recipe = {
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "","testventure:smaranium_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_smaranium',
	recipe = {
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "","testventure:smaranium_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_smaranium',
	recipe = {
		{"testventure:smaranium_bar", "","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_smaranium',
	recipe = {
		{"testventure:smaranium_bar", "","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "","testventure:smaranium_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_smaranium',
	recipe = {
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"", "testventure:smaranium_bar",""},
	}
})

-- heavenly

minetest.register_craft({
	output = 'testventure:helmet_heavenly',
	recipe = {
		{"testventure:cloudantite_bar", "default:gold_ingot","testventure:cloudantite_bar"},
		{"testventure:cloudantite_bar", "testventure:ruby","testventure:cloudantite_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_heavenly',
	recipe = {
		{"default:gold_ingot", "testventure:cloudantite_bar","default:gold_ingot"},
		{"testventure:cloudantite_bar", "","testventure:cloudantite_bar"},
		{"testventure:cloudantite_bar", "","testventure:cloudantite_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_heavenly',
	recipe = {
		{"default:gold_ingot", "","default:gold_ingot"},
		{"testventure:cloudantite_bar", "testventure:ruby","testventure:cloudantite_bar"},
		{"testventure:cloudantite_bar", "testventure:cloudantite_bar","testventure:cloudantite_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_heavenly',
	recipe = {
		{"testventure:cloudantite_bar", "","testventure:cloudantite_bar"},
		{"default:gold_ingot", "","default:gold_ingot"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_heavenly',
	recipe = {
		{"default:gold_ingot", "testventure:cloudantite_bar","default:gold_ingot"},
		{"testventure:cloudantite_bar", "testventure:ruby","testventure:cloudantite_bar"},
		{"", "default:gold_ingot",""},
	}
})

-- black_silver

minetest.register_craft({
	output = 'testventure:helmet_black_silver',
	recipe = {
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "","testventure:black_silver_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_black_silver',
	recipe = {
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "","testventure:black_silver_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_black_silver',
	recipe = {
		{"testventure:black_silver_bar", "","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_black_silver',
	recipe = {
		{"testventure:black_silver_bar", "","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "","testventure:black_silver_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_black_silver',
	recipe = {
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"", "testventure:black_silver_bar",""},
	}
})

--------frost

minetest.register_craft({
	output = 'testventure:helmet_frost',
	recipe = {
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	{"testventure:eternal_ice_shards", "testventure:helmet_black_silver","testventure:eternal_ice_shards"},
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_frost',
	recipe = {
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	{"testventure:eternal_ice_shards", "testventure:chestplate_black_silver","testventure:eternal_ice_shards"},
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_frost',
	recipe = {
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	{"testventure:eternal_ice_shards", "testventure:leggings_black_silver","testventure:eternal_ice_shards"},
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_frost',
	recipe = {
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	{"testventure:eternal_ice_shards", "testventure:boots_black_silver","testventure:eternal_ice_shards"},
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	}
})

minetest.register_craft({
	output = 'testventure:shield_frost',
	recipe = {
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	{"testventure:eternal_ice_shards", "testventure:shield_black_silver","testventure:eternal_ice_shards"},
		{"testventure:frozen_slimeball", "testventure:eternal_ice_shards","testventure:frozen_slimeball"},
	}
})

-- amber

minetest.register_craft({
	output = 'testventure:helmet_amber',
	recipe = {
		{"testventure:amber", "testventure:amber","testventure:amber"},
		{"testventure:amber", "","testventure:amber"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_amber',
	recipe = {
		{"testventure:amber", "testventure:amber","testventure:amber"},
		{"testventure:amber", "","testventure:amber"},
		{"testventure:amber", "","testventure:amber"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_amber',
	recipe = {
		{"testventure:amber", "","testventure:amber"},
		{"testventure:amber", "testventure:amber","testventure:amber"},
		{"testventure:amber", "testventure:amber","testventure:amber"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_amber',
	recipe = {
		{"testventure:amber", "","testventure:amber"},
		{"testventure:amber", "","testventure:amber"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_amber',
	recipe = {
		{"testventure:amber", "testventure:amber","testventure:amber"},
		{"testventure:amber", "testventure:amber","testventure:amber"},
		{"", "testventure:amber",""},
	}
})


--aqua

minetest.register_craft({
	output = 'testventure:helmet_aqua',
	recipe = {
		{"default:gold_ingot", "testventure:aquamarine_shards","default:gold_ingot"},
		{"testventure:aquamarine_shards", "","testventure:aquamarine_shards"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:leggings_aqua',
	recipe = {
		{"default:gold_ingot", "default:gold_ingot","default:gold_ingot"},
		{"testventure:aquamarine_shards", "","testventure:aquamarine_shards"},
		{"testventure:aquamarine_shards", "","testventure:aquamarine_shards"},
	}
})

minetest.register_craft({
	output = 'testventure:chestplate_aqua',
	recipe = {
		{"default:gold_ingot", "","default:gold_ingot"},
		{"testventure:aquamarine_shards", "default:gold_ingot","testventure:aquamarine_shards"},
		{"testventure:aquamarine_shards", "testventure:aquamarine_shards","testventure:aquamarine_shards"},
	}
})

minetest.register_craft({
	output = 'testventure:boots_aqua',
	recipe = {
		{"testventure:aquamarine_shards", "","testventure:aquamarine_shards"},
		{"default:gold_ingot", "","default:gold_ingot"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:shield_aqua',
	recipe = {
		{"default:gold_ingot", "testventure:aquamarine_shards","default:gold_ingot"},
		{"testventure:aquamarine_shards", "testventure:aquamarine_shards","testventure:aquamarine_shards"},
		{"", "default:gold_ingot",""},
	}
})

minetest.register_craft({
	output = 'testventure:sunglasses',
	recipe = {
		{"testventure:black_lens", "testventure:black_lens"},
	}
})

minetest.register_craft({
	output = 'testventure:goggles',
	recipe = {
		{"testventure:lens", "testventure:lens"},
	}
})

----other-------

minetest.register_craft({
	output = 'default:stick 3',
	recipe = {
		{"testventure:darkwood"},
	}
})

minetest.register_craft({
	output = 'testventure:snowball 60',
	recipe = {
		{"", "default:snowblock",""},
		{"default:snowblock", "default:snowblock","default:snowblock"},
		{"", "default:snowblock",""},
	}
})

minetest.register_craft({
	output = 'testventure:niobium_sword 1',
	recipe = {
		{"", "","testventure:niobium_bar"},
		{"testventure:niobium_bar", "testventure:niobium_bar",""},
		{"testventure:niobium_bar", "testventure:niobium_bar",""},
	}
})

minetest.register_craft({
	output = 'testventure:niobium_machinegun 1',
	recipe = {
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
		{"testventure:niobium_bar", "","testventure:niobium_bar"},
		{"testventure:niobium_bar", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:niobium_repeater 1',
	recipe = {
		{"testventure:niobium_bar", "farming:string",""},
		{"testventure:niobium_bar", "testventure:niobium_bar","testventure:niobium_bar"},
		{"testventure:niobium_bar", "farming:string","testventure:niobium_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:blood_scepter 1',
	recipe = {
		{"testventure:crimrubite_bar", "testventure:dark_blood","testventure:dark_blood"},
		{"testventure:black_silver_bar", "testventure:oceanic_trident","testventure:dark_blood"},
		{"testventure:ruby", "testventure:black_silver_bar","testventure:crimrubite_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:bloodstone_sculpture 1',
	recipe = {
		{"testventure:bloodstone", "testventure:dark_blood","testventure:bloodstone"},
		{"testventure:dark_blood", "testventure:crimrubite_block","testventure:dark_blood"},
		{"testventure:bloodstone", "testventure:dark_blood","testventure:bloodstone"},
	}
})

minetest.register_craft({
	output = 'testventure:sticky_bomb',
	type = "shapeless",
	recipe = 
		{"testventure:bomb", "testventure:slimeball"},
})

minetest.register_craft({
	output = 'testventure:shadow_bullet 75',
	recipe = {
		{"", "",""},
		{"testventure:shadow_magic", "testventure:shadowsteel_bar","testventure:black_silver_bar"},
		{"", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:flare 10',
	recipe = {
		{"","testventure:slimeball",""},
		{"","group:wool",""},
		{"","default:copper_ingot",""},
	}
})

minetest.register_craft({
	output = 'testventure:flare 10',
	recipe = {
		{"","testventure:slimeball",""},
		{"","default:coal_lump",""},
		{"","default:copper_ingot",""},
	}
})

minetest.register_craft({
	output = 'testventure:black_silver_bullet 100',
	recipe = {
		{'testventure:black_silver_bar'},
	}
})

minetest.register_craft({
	output = 'testventure:standard_bullet 75',
	recipe = {
{"","default:steel_ingot",""},
{"default:copper_ingot","tnt:gunpowder","default:copper_ingot"},
{"default:copper_ingot","tnt:gunpowder","default:copper_ingot"},
	}
})

minetest.register_craft({
	output = 'testventure:worm_dagger',
	recipe = {
		{"", "testventure:worm_tooth",""},
		{"testventure:worm_tooth", "testventure:worm_tooth","testventure:worm_tooth"},
		{"", "testventure:crimrubite_bar",""},
	}
})

minetest.register_craft({
	output = 'testventure:cactus_sword',
	recipe = {
		{"", "default:cactus",""},
		{"default:cactus", "default:cactus","default:cactus"},
		{"default:cactus", "default:cactus","default:cactus"},
	}
})

minetest.register_craft({
	output = 'testventure:thorny_whip',
	recipe = {
		{"default:dry_shrub", "default:dry_shrub","default:dry_shrub"},
		{"default:dry_shrub", "","default:dry_shrub"},
		{"default:dry_shrub", "",""},
	}
})

minetest.register_craft({
	output = 'testventure:rainbow_gem_sword',
	recipe = {
		{"","testventure:topaz","testventure:ruby"},
		{"testventure:amethyst","default:diamond","testventure:emerald"},
		{"default:gold_ingot","testventure:sapphire",""},

	}
})

minetest.register_craft({
	output = 'testventure:amber_sword',
	recipe = {
		{"testventure:amber","testventure:amber","testventure:amber"},
		{"testventure:amber","testventure:amber",""},
		{"default:bronze_ingot","default:bronze_ingot",""},

	}
})

minetest.register_craft({
	output = 'testventure:adventurer_sword',
	recipe = {
		{"default:gold_ingot","testventure:sword_black_silver","default:gold_ingot"},
		{"default:gold_ingot","testventure:sword_basic","default:gold_ingot"},
		{"default:gold_ingot","testventure:ruby","default:gold_ingot"},

	}
})

---bows---

minetest.register_craft({
	output = 'testventure:bow_black_silver',
	recipe = {
		{"", "testventure:black_silver_bat","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "","farming:string"},
		{"testventure:black_silver_bar", "farming:string",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_smaranium',
	recipe = {
		{"", "testventure:smaranium_bat","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "","farming:string"},
		{"testventure:smaranium_bar", "farming:string",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_gold',
	recipe = {
		{"", "default:gold_ingot","default:gold_ingot"},
		{"default:gold_ingot", "","farming:string"},
		{"default:gold_ingot", "farming:string",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_tin',
	recipe = {
		{"", "default:tin_ingot","default:tin_ingot"},
		{"default:tin_ingot", "","farming:string"},
		{"default:tin_ingot", "farming:string",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_copper',
	recipe = {
		{"", "default:copper_ingot","default:copper_ingot"},
		{"default:copper_ingot", "","farming:string"},
		{"default:copper_ingot", "farming:string",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_bronze',
	recipe = {
		{"", "default:bronze_ingot","default:bronze_ingot"},
		{"default:bronze_ingot", "","farming:string"},
		{"default:bronze_ingot", "farming:string",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_steel',
	recipe = {
		{"", "default:steel_ingot","default:steel_ingot"},
		{"default:steel_ingot", "","farming:string"},
		{"default:steel_ingot", "farming:string",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_wooden',
	recipe = {
		{"", "group:wood","group:wood"},
		{"group:wood", "","testventure:grass_rope"},
		{"group:wood", "testventure:grass_rope",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_wooden',
	recipe = {
		{"", "group:wood","group:wood"},
		{"group:wood", "","farming:string"},
		{"group:wood", "farming:string",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_skywood',
	recipe = {
		{"", "testventure:skywood","testventure:skywood"},
		{"testventure:skywood", "","testventure:grass_rope"},
		{"testventure:skywood", "testventure:grass_rope",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_skywood',
	recipe = {
		{"", "testventure:skywood","testventure:skywood"},
		{"testventure:skywood", "","farming:string"},
		{"testventure:skywood", "farming:string",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_darkwood',
	recipe = {
		{"", "testventure:darkwood","testventure:darkwood"},
		{"testventure:darkwood", "","testventure:grass_rope"},
		{"testventure:darkwood", "testventure:grass_rope",""},
	}
})

minetest.register_craft({
	output = 'testventure:bow_darkwood',
	recipe = {
		{"", "testventure:darkwood","testventure:darkwood"},
		{"testventure:darkwood", "","farming:string"},
		{"testventure:darkwood", "farming:string",""},
	}
})


minetest.register_craft({
	output = 'testventure:bow_nightmare_injector',
	recipe = {
		{"", "testventure:worm_tooth","testventure:shadowsteel_bar"},
		{"testventure:worm_tooth", "testventure:shadowsteel_bar","farming:string"},
		{"testventure:shadowsteel_bar", "farming:string","farming:string"},
	}
})

minetest.register_craft({
	output = 'testventure:golden_handgun',
	recipe = {
		{"default:gold_ingot", "default:gold_ingot","default:gold_ingot"},
		{"default:gold_ingot", "testventure:handgun","default:gold_ingot"},
		{"default:gold_ingot", "default:gold_ingot","default:gold_ingot"},
	}
})


minetest.register_craft({
	output = 'testventure:shadow_eagle',
	recipe = {
		{"testventure:black_silver_bar", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"testventure:shadow_magic", "testventure:handgun","testventure:shadowsteel_bar"},
		{"testventure:shadow_magic", "testventure:shadow_magic","testventure:shadowsteel_bar"},
	}
})

-------- accessories


minetest.register_craft({
	output = 'testventure:magical_scope',
	recipe = {
		{"testventure:black_silver_bar", "testventure:shadow_magic","testventure:black_silver_bar"},
		{"testventure:black_lens", "default:diamond","testventure:black_lens"},
		{"testventure:black_silver_bar", "default:steel_ingot","testventure:black_silver_bar"},
	}
})

minetest.register_craft({
	output = 'testventure:emerald_bracelets',
	recipe = {
		{"default:gold_ingot", "default:gold_ingot","default:gold_ingot"},
		{"testventure:emerald", "testventure:emerald","testventure:emerald"},
		{"default:gold_ingot", "default:gold_ingot","default:gold_ingot"},
	}
})
minetest.register_craft({
	output = 'testventure:sapphire_bracelets',
	recipe = {
		{"default:gold_ingot", "default:gold_ingot","default:gold_ingot"},
		{"testventure:sapphire", "testventure:sapphire","testventure:sapphire"},
		{"default:gold_ingot", "default:gold_ingot","default:gold_ingot"},
	}
})
minetest.register_craft({
	output = 'testventure:ruby_bracelets',
	recipe = {
		{"default:gold_ingot", "default:gold_ingot","default:gold_ingot"},
		{"testventure:ruby", "testventure:ruby","testventure:ruby"},
		{"default:gold_ingot", "default:gold_ingot","default:gold_ingot"},
	}
})
minetest.register_craft({
	output = 'testventure:encrusted_bracelets',
	type = "shapeless",
	recipe = 
		{"testventure:emerald_bracelets", "testventure:sapphire_bracelets","testventure:ruby_bracelets"},
	
})

minetest.register_craft({
	output = 'testventure:bloody_scope',
	type = "shapeless",
	recipe = 
		{"testventure:magical_scope", "testventure:bloody_bullet_shell"},
	
})

minetest.register_craft({
	output = 'testventure:restoration_amulet',
	type = "shapeless",
	recipe = 
		{"testventure:mana_amulet", "testventure:regen_amulet"},
	
})

minetest.register_craft({
	output = 'testventure:adventurer_amulet',
	type = "shapeless",
	recipe = 
		{"testventure:restoration_amulet", "testventure:boots_mobility","testventure:smaranium_bar","testventure:black_silver_bar"},
	
})

minetest.register_craft({
	output = 'testventure:mana_crystal',
	type = "shapeless",
	recipe = 
		{"testventure:fallen_star", "testventure:fallen_star", "testventure:fallen_star", "testventure:fallen_star", "testventure:amethyst"},
	
})

minetest.register_craft({
	output = 'testventure:boots_mobility',
	type = "shapeless",
	recipe = 
		{"testventure:boots_slime", "testventure:boots_speed"},
	
})

----magic

minetest.register_craft({
	output = 'testventure:niobium_staff',
	recipe = {
		{"testventure:shadow_magic","testventure:shadow_magic","testventure:niobium_bar"},
		{"", "testventure:niobium_bar","testventure:niobium_bar"},
		{"testventure:niobium_bar", "testventure:niobium_bar",""},

	}
})

minetest.register_craft({
	output = 'testventure:amethyst_staff',
	recipe = {
		{"testventure:amethyst","testventure:amethyst","default:copper_ingot"},
		{"", "default:copper_ingot","default:copper_ingot"},
		{"default:copper_ingot", "testventure:amethyst",""},

	}
})

minetest.register_craft({
	output = 'testventure:topaz_staff',
	recipe = {
		{"testventure:topaz","testventure:topaz","default:tin_ingot"},
		{"", "default:tin_ingot","default:tin_ingot"},
		{"default:tin_ingot", "testventure:topaz",""},

	}
})

minetest.register_craft({
	output = 'testventure:emerald_staff',
	recipe = {
		{"testventure:emerald","testventure:emerald","default:bronze_ingot"},
		{"", "default:bronze_ingot","default:bronze_ingot"},
		{"default:bronze_ingot", "testventure:emerald",""},

	}
})


minetest.register_craft({
	output = 'testventure:sapphire_staff',
	recipe = {
		{"testventure:sapphire","testventure:sapphire","default:gold_ingot"},
		{"", "default:gold_ingot","default:gold_ingot"},
		{"default:gold_ingot", "testventure:sapphire",""},

	}
})
minetest.register_craft({
	output = 'testventure:ruby_staff',
	recipe = {
		{"testventure:ruby","testventure:ruby","testventure:smaranium_bar"},
		{"", "testventure:smaranium_bar","testventure:smaranium_bar"},
		{"testventure:smaranium_bar", "testventure:ruby",""},

	}
})

minetest.register_craft({
	output = 'testventure:diamond_staff',
	recipe = {
		{"default:diamond","default:diamond","testventure:black_silver_bar"},
		{"", "testventure:black_silver_bar","testventure:black_silver_bar"},
		{"testventure:black_silver_bar", "default:diamond",""},

	}
})

--orebrix---

minetest.register_craft({
	output = 'testventure:niobium_bricks',
	type = "shapeless",
	recipe = 
		{"default:cobble", "testventure:niobium_lump"},
})


minetest.register_craft({
	output = 'testventure:cloudantite_bricks',
	type = "shapeless",
	recipe = 
		{"default:cobble", "testventure:cloudantite_lump"},
})


minetest.register_craft({
	output = 'testventure:black_silver_bricks',
	type = "shapeless",
	recipe = 
		{"default:cobble", "testventure:black_silver_lump"},
})

minetest.register_craft({
	output = 'testventure:shadowsteel_bricks',
	type = "shapeless",
	recipe = 
		{"default:cobble", "testventure:shadowsteel_lump"},
})

minetest.register_craft({
	output = 'testventure:crimrubite_bricks',
	type = "shapeless",
	recipe = 
		{"default:cobble", "testventure:crimrubite_lump"},
})

minetest.register_craft({
	output = 'testventure:smaranium_bricks',
	type = "shapeless",
	recipe = 
		{"default:cobble", "testventure:smaranium_lump"},
})


----potions

minetest.register_craft({
	output = 'testventure:mana_potion_small',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:fallen_star", "testventure:slimeball"},
})

minetest.register_craft({
	output = 'testventure:mana_potion',
	type = "shapeless",
	recipe = 
		{"testventure:mana_potion_small", "testventure:glowshroom", "testventure:glowshroom","testventure:glowshroom","testventure:sunglow"},
})
minetest.register_craft({
	output = 'testventure:health_potion',
	type = "shapeless",
	recipe = 
		{"testventure:health_potion_small", "testventure:glowshroom", "testventure:glowshroom","testventure:glowshroom","testventure:sunglow"},
})

minetest.register_craft({
	output = 'testventure:health_potion_small',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:shroom", "testventure:slimeball"},
})
minetest.register_craft({
	output = 'testventure:regen_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:shroom", "testventure:slimeball","testventure:sunglow"},
})
minetest.register_craft({
	output = 'testventure:recall_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:frostonica", "testventure:frozen_slimeball","testventure:sunglow","default:mese_crystal_fragment"},
})
minetest.register_craft({
	output = 'testventure:oxygen_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "default:sapling", "testventure:slimeball","testventure:rockweed"},
})
minetest.register_craft({
	output = 'testventure:wealth_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "default:gold_ingot", "testventure:coin_gold","testventure:sandshine","testventure:crimson_slimeball"},
})
minetest.register_craft({
	output = 'testventure:featherweight_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "mobs:chicken_feather", "testventure:pink_slimeball","testventure:rockweed"},
})
minetest.register_craft({
	output = 'testventure:antigravity_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:frostonica", "testventure:crimson_slimeball","default:mese_crystal","default:iron_lump"},
})
minetest.register_craft({
	output = 'testventure:manaregen_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:shroom", "testventure:slimeball","testventure:fallen_star"},
})
minetest.register_craft({
	output = 'testventure:strenght_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:darkshroom", "testventure:crimson_slimeball","testventure:bloodbloom"},
})
minetest.register_craft({
	output = 'testventure:invincibility_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:black_silver_lump", "testventure:crimson_slimeball","testventure:frostonica"},
})
minetest.register_craft({
	output = 'testventure:mining_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:amber", "default:diamond","testventure:sandshine","testventure:slimeball"},
})
minetest.register_craft({
	output = 'testventure:teleportation_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:slimeball", "default:mese_crystal_fragment","testventure:frostonica"},
})
minetest.register_craft({
	output = 'testventure:nightvision_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:slimeball", "testventure:lens","testventure:sunglow"},
})
minetest.register_craft({
	output = 'testventure:swiftness_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:slimeball","testventure:sunglow"},	
})
minetest.register_craft({
	output = 'testventure:jumping_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:pink_slimeball","testventure:rockweed"},	
})
minetest.register_craft({
	output = 'testventure:ironskin_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle", "testventure:rockweed", "testventure:slimeball","default:iron_lump"},	
})
minetest.register_craft({
	output = 'testventure:spelunkin_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle","testventure:rockweed", "testventure:sandy_slimeball","default:gold_lump"},
	
})
minetest.register_craft({
	output = 'testventure:force_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle","testventure:rockweed", "testventure:crimson_slimeball","default:iron_lump"},
	
})
minetest.register_craft({
	output = 'testventure:glowing_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle","testventure:sunglow_plant", "testventure:magical_rose_plant","default:mese_crystal_fragment"},
	
})
minetest.register_craft({
	output = 'testventure:sharpshooting_potion',
	type = "shapeless",
	recipe = 
		{"vessels:glass_bottle","testventure:slimeball", "testventure:magical_rose_plant","testventure:lens"},
	
})
