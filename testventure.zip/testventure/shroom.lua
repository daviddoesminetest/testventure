
	minetest.register_biome({
		name = "shroom_underground",
		--node_dust = "",
		node_top = "testventure:mycelium_mud",
		depth_top = 1,
		node_filler = "testventure:mud",
		depth_filler = 1,
		node_stone = "testventure:mycelium_stone",
		--node_water_top = "",
		--depth_water_top = ,
		--node_water = "",
		--node_river_water = "",
		y_min = -1000,
		y_max = -750,
		heat_point = 90,
		humidity_point = 90,
	})


	minetest.register_ore({
		ore_type        = "blob",
		ore             = "testventure:mycelium_mud",
		wherein         = {"testventure:mycelium_stone"},
		clust_scarcity  = 5 * 5 * 5,
		clust_size      = 5,
		y_min           = -1000,
		y_max           = -700,
		noise_threshold = 0.0,
		noise_params    = {
			offset = 0.5,
			scale = 0.2,
			spread = {x = 5, y = 5, z = 5},
			seed = 17676,
			octaves = 1,
			persist = 0.0
		},
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:bigshroom_seed",
		wherein        = "testventure:mycelium_mud",
		clust_scarcity = 9 * 9 * 9,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -1000,
		y_max          = -750,
	})


minetest.register_node("testventure:mycelium_stone", {
		description = "".. core.colorize("#00eaff", "Mycelium-ed stone\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"default_stone.png^testventure_mycelium_stone.png"},
	groups = {cracky = 3},
	stack_max= 999,
	light_source = 5,
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:mycelium_mud", {
		description = "".. core.colorize("#00eaff", "Mycelium mud\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_mycelium_grass_top.png", "testventure_mud.png",
		{name = "testventure_mud.png^testventure_mycelium_grass_side.png",
			tileable_vertical = false}},
	groups = {crumbly = 3},
drop = {
		max_items = 2,
		items = {
{items = {'testventure:glowshroom_grass_seeds'},rarity = 25,},
{items = {'testventure:mud'},rarity = 1,},
		}
	},
	stack_max= 999,
	light_source = 8,
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_grass_footstep", gain = 0.25},
	}),
})

minetest.register_node("testventure:glowshroom_cap", {
		description = "".. core.colorize("#00eaff", "Glowshroom cap\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_glowshroom_cap.png"},
	stack_max= 999,
	groups = {snappy= 3},
	light_source = 9,
	sounds = default.node_sound_wood_defaults(),
})
minetest.register_node("testventure:glowshroom_spores", {
		description = "".. core.colorize("#00eaff", "Glowshroom spores\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_glowshroom_spores.png"},
	stack_max= 999,
	groups = {snappy = 3},
	light_source = 5,
	sounds = default.node_sound_dirt_defaults(),
})
minetest.register_node("testventure:glowshroom_stem", {
		description = "".. core.colorize("#00eaff", "Glowshroom stem\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_glowshroom_stem_top.png", "testventure_glowshroom_stem_top.png", "testventure_glowshroom_stem_side.png"},
	stack_max= 999,
	groups = {snappy= 3},
	light_source = 5,
	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("testventure:bigshroom_seed", {
		description = "".. core.colorize("#00eaff", "shroom seed\n")..core.colorize("#FFFFFF", "YOU HACKER! YOU!"),
	tiles = {"testventure_glowshroom_spores.png"},
	drop = "",
	groups = {cracky = 4},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_abm({
	nodenames = {"testventure:glowshroom_plant"},
	interval = 25,
	chance = 90,
	catch_up = false,
	action = function(pos, node)
	if pos.y > 0 then
	node.name = "testventure:glowshroom_stem"
	minetest.set_node(pos, node)
	pos.x = pos.x - 3
	pos.z = pos.z - 3
	minetest.place_schematic(pos, minetest.get_modpath("testventure") .. "/schematics/glowshroom.mts","random",nil, false)
	end
	end
})

minetest.register_abm({
	nodenames = {"testventure:bigshroom_seed"},
	interval = 1,
	chance = 1,
	catch_up = false,
	action = function(pos, node)
	node.name = "testventure:mud"
	minetest.set_node(pos, node)
	pos.x = pos.x - 3
	pos.z = pos.z - 3
	minetest.place_schematic(pos, minetest.get_modpath("testventure") .. "/schematics/glowshroom.mts","random",nil, false)
	end
})

minetest.register_abm({
	nodenames = {"testventure:mycelium_mud"},
	interval = 20,
	chance = 25,
	action = function(pos, node)
		pos.z = pos.z+1
		if minetest.get_node(pos).name == "testventure:mud" then
			node.name = "testventure:mycelium_mud"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:mycelium_mud"},
	interval = 20,
	chance = 25,
	action = function(pos, node)
		pos.z = pos.z-1
		if minetest.get_node(pos).name == "testventure:mud" then
			node.name = "testventure:mycelium_mud"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:mycelium_mud"},
	interval = 20,
	chance = 25,
	action = function(pos, node)
		pos.x = pos.x+1
		if minetest.get_node(pos).name == "testventure:mud" then
			node.name = "testventure:mycelium_mud"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:mycelium_mud"},
	interval = 20,
	chance = 25,
	action = function(pos, node)
		pos.x = pos.x-1
		if minetest.get_node(pos).name == "testventure:mud" then
			node.name = "testventure:mycelium_mud"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_craftitem("testventure:glowshroom_grass_seeds", {
		description = "".. core.colorize("#00eaff", "Glowshroom grass seeds\n")..core.colorize("#FFFFFF", "Use them on mud, to plant glowshroom grass on it"),
	inventory_image = "testventure_glowshroom_grass_seeds.png",
	stack_max= 999,
})

minetest.register_on_punchnode(function(pos, node, puncher, pointed_thing)
	if puncher:get_wielded_item():get_name() == "testventure:glowshroom_grass_seeds"
	and node.name == "testventure:mud" then
	if puncher:get_inventory():remove_item('main', "testventure:glowshroom_grass_seeds") 
then
		minetest.set_node(pos,{name="testventure:mycelium_mud"}) 
	end
	end
end)