

minetest.register_craftitem("testventure:fallen_ree", {
		description = "".. core.colorize("#00eaff", "Fallen REEEEEE\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_star.png",
	wield_scale = {x=1.33,y=1.33,z=1.33},
	stack_max= 999,
	tool_capabilities = {full_punch_interval = 0.8,	
	max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=4.75, [2]=2.0, [3]=1.0}, uses=15, maxlevel=2},
			crumbly = {times={[1]=2.0, [2]=1.10, [3]=0.50}, uses=15, maxlevel=2},
		},
		damage_groups = {fleshy=4},},
on_secondary_use = function(itemstack, tool_capabilities, user,  pointed_thing)
	itm_mt = itemstack:get_meta() 
	itm_mt:set_string("description", "oof")
	digpower = itemstack:get_tool_capabilities().full_punch_interval
	local caps = itemstack:get_tool_capabilities()
      yeet = digpower + 1
	itm_mt:set_tool_capabilities({
full_punch_interval = yeet,
		groupcaps={
			cracky = {times={[1]=0.05, [2]=0.05, [3]=0.05}, uses=15, maxlevel=2},
		},
})
	minetest.chat_send_all(digpower)
	return itemstack
end,
})


minetest.register_craftitem("testventure:fallen_star", {
		description = "".. core.colorize("#00eaff", "Fallen star\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_star.png",
	wield_scale = {x=1.33,y=1.33,z=1.33},
	stack_max= 999,
})



minetest.register_craftitem("testventure:eternal_ice_shards", {
		description = "".. core.colorize("#00eaff", "Eternal ice shards\n")..core.colorize("#FFFFFF", "Crafting material\n")..core.colorize("#6b9f45", "Cold, sharp and completelly unmeltable."),
	inventory_image = "testventure_eternal_ice_shards.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:amber", {
		description = "".. core.colorize("#00eaff", "Amber\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_amber.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:amethyst", {
		description = "".. core.colorize("#00eaff", "Amethyst\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_amethyst.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:topaz", {
		description = "".. core.colorize("#00eaff", "topaz\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_topaz.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:emerald", {
		description = "".. core.colorize("#00eaff", "emerald\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_emerald.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:sapphire", {
		description = "".. core.colorize("#00eaff", "sapphire\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_sapphire.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:ruby", {
		description = "".. core.colorize("#00eaff", "ruby\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_ruby.png",
	stack_max= 999,
})



minetest.register_craftitem("testventure:black_lens", {
		description = "".. core.colorize("#00eaff", "Black lens\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_black_lens.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:shadow_magic", {
		description = "".. core.colorize("#00eaff", "Shadow magic\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_shadow_magic.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:lens", {
		description = "".. core.colorize("#00eaff", "Lens\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_lens.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:magic_slimeball", {
		description = "".. core.colorize("#2a00ff", "Magical Slimeball\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_magic_slimeball.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:slimeball", {
		description = "".. core.colorize("#00eaff", "Slimeball\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_slimeball.png",
	stack_max= 999,
})


minetest.register_craftitem("testventure:pink_slimeball", {
		description = "".. core.colorize("#00eaff", "Pink slimeball\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_pink_slimeball.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:crimson_slimeball", {
		description = "".. core.colorize("#00eaff", "Crimson slimeball\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_crimson_slimeball.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:sandy_slimeball", {
		description = "".. core.colorize("#00eaff", "Sandy slimeball\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_sandy_slimeball.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:frozen_slimeball", {
		description = "".. core.colorize("#00eaff", "Frozen slimeball\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_frozen_slimeball.png",
	stack_max= 999,
})


minetest.register_craftitem("testventure:worm_tooth", {
		description = "".. core.colorize("#00eaff", "Huge worm tooth\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_worm_tooth.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:dark_blood", {
		description = "".. core.colorize("#00eaff", "Dark blood\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_dark_blood.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:aquamarine_shards", {
		description = "".. core.colorize("#00eaff", "Aquamarine shards\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_aquamarine_shards.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:niobium_lump", {
		description = "".. core.colorize("#2a00ff", "Niobium lump\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_niobium_lump.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:crimrubite_lump", {
		description = "".. core.colorize("#00eaff", "Crimrubite lump\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_crimrubite_lump.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:niobium_bar", {
		description = "".. core.colorize("#2a00ff", "Niobium bar\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_niobium_bar.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:crimrubite_bar", {
		description = "".. core.colorize("#00eaff", "Crimrubite bar\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_crimrubite_bar.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:shadowsteel_lump", {
		description = "".. core.colorize("#00eaff", "Shadowsteel lump\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_shadowsteel_lump.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:shadowsteel_bar", {
		description = "".. core.colorize("#00eaff", "Shadowsteel bar\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_shadowsteel_bar.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:smaranium_lump", {
		description = "".. core.colorize("#00eaff", "Smaranium lump\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_smaranium_lump.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:smaranium_bar", {
		description = "".. core.colorize("#00eaff", "Smaranium bar\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_smaranium_bar.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:black_silver_lump", {
		description = "".. core.colorize("#00eaff", "Black Silver lump\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_black_silver_lump.png",
	stack_max= 999,
})

minetest.register_craftitem("testventure:black_silver_bar", {
		description = "".. core.colorize("#00eaff", "Black Silver bar\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_black_silver_bar.png",
	stack_max= 999,
})

--
--coins
--

minetest.register_craftitem("testventure:coin_copper", {
		description = "" ..core.colorize("#00eaff","Copper coin\n")..core.colorize("#FFFFFF", "The cheapest of coins. \n")..core.colorize("#FFFFFF", "Left-click 100 to convert them into a silver coin"),
	stack_max = 65535,
	wield_scale = {x=0.5,y=0.5,z=0.5},
	inventory_image = "testventure_coin_copper.png",
	on_use = function(itemstack, user, pointed_thing)
		local inv = user:get_inventory()
	if itemstack:get_count() <= 99 then
	return itemstack
	end
		itemstack:take_item(100)
		inv:add_item("main", "testventure:coin_silver 1")
	return itemstack
	end,

})

minetest.register_craftitem("testventure:coin_silver", {
		description = "" ..core.colorize("#00eaff","Silver coin\n")..core.colorize("#FFFFFF", "More valuable than copper. \n")..core.colorize("#FFFFFF", "Left-click 100 to convert them into a Gold coin\n")..core.colorize("#FFFFFF", "Right-click to convert it into 100 Copper coins"),
	stack_max = 65535,
	wield_scale = {x=0.55,y=0.55,z=0.55},
	inventory_image = "testventure_coin_silver.png",
	on_use = function(itemstack, user, pointed_thing)
		local inv = user:get_inventory()
	if itemstack:get_count() <= 99 then
	return itemstack
	end
		itemstack:take_item(100)
		inv:add_item("main", "testventure:coin_gold 1")
	return itemstack
	end,
	on_secondary_use = function(itemstack, user, pointed_thing)
		local inv = user:get_inventory()
		itemstack:take_item()
		inv:add_item("main", "testventure:coin_copper 100")
	return itemstack
	end,

})

minetest.register_craftitem("testventure:coin_gold", {
		description = "" ..core.colorize("#00eaff","Gold coin\n")..core.colorize("#FFFFFF", "More valuable than silver. \n")..core.colorize("#FFFFFF", "Left-click 100 to convert them into a Platinum coin\n")..core.colorize("#FFFFFF", "Right-click to convert it into 100 Silver coins"),
	stack_max = 65535,
	wield_scale = {x=0.6,y=0.6,z=0.6},
	inventory_image = "testventure_coin_gold.png",
	on_use = function(itemstack, user, pointed_thing)
		local inv = user:get_inventory()
	if itemstack:get_count() <= 99 then
	return itemstack
	end
		itemstack:take_item(100)
		inv:add_item("main", "testventure:coin_platinum 1")
	return itemstack
	end,
	on_secondary_use = function(itemstack, user, pointed_thing)
		local inv = user:get_inventory()
		itemstack:take_item()
		inv:add_item("main", "testventure:coin_silver 100")
	return itemstack
	end,

})

minetest.register_craftitem("testventure:coin_platinum", {
		description = "" ..core.colorize("#00eaff","Platinum coin\n")..core.colorize("#FFFFFF", "The most valuable of coins. \n")..core.colorize("#FFFFFF", "Right-click to convert it into 100 Gold coins"),
	stack_max = 65535,
	wield_scale = {x=0.65,y=0.65,z=0.65},
	inventory_image = "testventure_coin_platinum.png",
	on_secondary_use = function(itemstack, user, pointed_thing)
		local inv = user:get_inventory()
		itemstack:take_item()
		inv:add_item("main", "testventure:coin_gold 100")
	return itemstack
	end,

})




