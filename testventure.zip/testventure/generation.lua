schem_table = {
  "/schematics/mine.mts",
  "/schematics/skyhouse.mts",
}

minetest.register_on_generated(function(minp, maxp, pos, node)
	local chk_area = VoxelArea:new{MinEdge=minp, MaxEdge=maxp}
	if not chk_area:contains(69, 69, 69) then
		return
	end
	pos = {x = 69, y = 69 , z = 69}
minetest.set_node(pos,{name="default:diamondblock"}) 
	if not chk_area:contains(70, 70, 70) then
		return
	end
	pos = {x = 70, y = 70 , z = 70}
	minetest.place_schematic(pos, minetest.get_modpath("testventure") .. schem_table[math.random(#schem_table)],"random",nil, true)
end)

	minetest.register_biome({
		name = "jungle",
		node_top = "testventure:jungle_mud",
		node_stone = "testventure:junglestone",
		depth_top = 1,
		node_filler = "testventure:mud",
		depth_filler = 5,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		y_max = upper_limit,
		y_min = -1000,
		heat_point = 86,
		humidity_point = 65,
	})

	minetest.register_decoration({
		deco_type = "schematic",
		place_on = {"testventure:jungle_mud"},
		sidelen = 16,
		fill_ratio = 0.002,
		biomes = {"jungle"},
		y_min = -1,
		y_max = 31000,
		schematic = minetest.get_modpath("default") .. "/schematics/jungle_tree.mts",
		flags = "place_center_x, place_center_z",
		rotation = "random",
	})
	minetest.register_decoration({
		deco_type = "schematic",
		place_on = {"testventure:jungle_mud"},
		sidelen = 16,
		fill_ratio = 0.01,
		biomes = {"jungle"},
		y_min = -1,
		y_max = 31000,
		schematic = minetest.get_modpath("testventure") .. "/schematics/rich_mahogany.mts",
		flags = "place_center_x, place_center_z",
		rotation = "random",
	})
	minetest.register_decoration({
		deco_type = "simple",
		place_on = {"testventure:jungle_mud"},
		sidelen = 16,
		fill_ratio = 0.25,
		biomes = {"jungle"},
		y_min = -1000,
		y_max = 31000,
		decoration = {"default:junglegrass","testventure:thorny_jungle_bush",
"testventure:jungle_plant_1","testventure:jungle_plant_2",
"testventure:jungle_plant_3","testventure:jungle_plant_4",
"testventure:jungle_plant_5","testventure:jungle_plant_6",
"testventure:jungle_plant_7","testventure:jungle_plant_8",
"testventure:jungle_plant_9","testventure:jungle_plant_10",
},
	})

	minetest.register_biome({
		name = "gneis",
		--node_dust = "",
		--node_top = "",
		--depth_top = 1,
		--node_filler = "",
		--depth_filler = 1,
		node_stone = "testventure:gneis",
		--node_water_top = "",
		--depth_water_top = ,
		--node_water = "",
		--node_river_water = "",
		y_min = -1000,
		y_max = -700,
		heat_point = 25,
		humidity_point = 25,
	})

	minetest.register_biome({
		name = "marble",
		--node_dust = "",
		--node_top = "",
		--depth_top = 1,
		--node_filler = "",
		--depth_filler = 1,
		node_stone = "testventure:marble",
		--node_water_top = "",
		--depth_water_top = ,
		--node_water = "",
		--node_river_water = "",
		y_min = -1000,
		y_max = -700,
		heat_point = 75,
		humidity_point = 75,
	})

	minetest.register_biome({
		name = "desert",
		--node_dust = "",
		node_top = "default:desert_sand",
		depth_top = 1,
		node_filler = "default:desert_sand",
		depth_filler = 1,
		node_stone = "default:desert_stone",
		--node_water_top = "",
		--depth_water_top = ,
		--node_water = "",
		--node_river_water = "",
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		y_min = -1000,
		y_max = upper_limit,
		heat_point = 92,
		humidity_point = 16,
	})

	minetest.register_biome({
		name = "underground",
		--node_dust = "",
		--node_top = "",
		--depth_top = 1,
		--node_filler = "",
		--depth_filler = 2,
		node_stone = "default:stone",
		--node_water_top = "",
		--depth_water_top = ,
		node_water = "default:water_source",
		--node_river_water = "",
		y_min = -1000,
		y_max = -112,
		heat_point = 50,
		humidity_point = 50,
	})

	minetest.register_biome({
		name = "deep_underground",
		--node_dust = "",
		node_top = "default:tree",
		depth_top = 1,
		node_filler = "default:wood",
		depth_filler = 2,
		node_stone = "default:obsidian",
		--node_water_top = "",
		--depth_water_top = ,
		node_water = "default:lava_source",
		--node_river_water = "",
		y_min = -31000,
		y_max = -1000,
		heat_point = 50,
		humidity_point = 50,
	})

----------------------------------
	minetest.register_biome({
		name = "icesheet",
		node_dust = "default:snowblock",
		node_top = "default:snowblock",
		depth_top = 1,
		node_filler = "default:snowblock",
		depth_filler = 3,
		node_stone = "testventure:icestone",
		node_water_top = "default:ice",
		depth_water_top = 10,
		node_river_water = "default:ice",
		node_riverbed = "testventure:slush",
		depth_riverbed = 2,
		y_max = upper_limit,
		y_min = -8,
		heat_point = 0,
		humidity_point = 73,
	})
	minetest.register_biome({
		name = "tundra_highland",
		node_dust = "default:snow",
		node_riverbed = "testventure:slush",
		node_stone = "testventure:icestone",
		depth_riverbed = 2,
		y_max = upper_limit,
		y_min = 47,
		heat_point = 0,
		humidity_point = 40,
	})
	minetest.register_biome({
		name = "tundra",
		node_top = "default:permafrost_with_stones",
		depth_top = 1,
		node_filler = "default:permafrost",
		node_stone = "testventure:icestone",
		depth_filler = 1,
		node_riverbed = "testventure:slush",
		depth_riverbed = 2,
		vertical_blend = 4,
		y_max = 46,
		y_min = 2,
		heat_point = 0,
		humidity_point = 40,
	})
	minetest.register_biome({
		name = "tundra_beach",
		node_top = "default:gravel",
		node_stone = "testventure:icestone",
		depth_top = 1,
		node_filler = "testventure:slush",
		depth_filler = 2,
		node_riverbed = "testventure:slush",
		depth_riverbed = 2,
		vertical_blend = 1,
		y_max = 1,
		y_min = -1000,
		heat_point = 0,
		humidity_point = 40,
	})
	minetest.register_biome({
		name = "taiga",
		node_dust = "default:snow",
		node_stone = "testventure:icestone",
		node_top = "default:dirt_with_snow",
		depth_top = 1,
		node_filler = "default:dirt",
		depth_filler = 3,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		y_max = upper_limit,
		y_min = -1000,
		heat_point = 25,
		humidity_point = 70,
	})
	minetest.register_biome({
		name = "snowy_grassland",
		node_dust = "default:snow",
		node_stone = "testventure:icestone",
		node_top = "default:dirt_with_snow",
		depth_top = 1,
		node_filler = "default:dirt",
		depth_filler = 1,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		y_max = upper_limit,
		y_min = -1000,
		heat_point = 20,
		humidity_point = 35,
	})
	minetest.register_biome({
		name = "icesheet_ocean",
		node_dust = "default:snowblock",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_water_top = "default:ice",
		depth_water_top = 10,
		y_max = -9,
		y_min = -112,
		heat_point = 0,
		humidity_point = 73,
	})
	minetest.register_biome({
		name = "tundra_ocean",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_riverbed = "testventure:slush",
		depth_riverbed = 2,
		vertical_blend = 1,
		y_max = -4,
		y_min = -112,
		heat_point = 0,
		humidity_point = 40,
	})
	minetest.register_biome({
		name = "taiga_ocean",
		node_dust = "default:snow",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		vertical_blend = 1,
		y_max = 3,
		y_min = -112,
		heat_point = 25,
		humidity_point = 70,
	})
	minetest.register_biome({
		name = "snowy_grassland_ocean",
		node_dust = "default:snow",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		vertical_blend = 1,
		y_max = 3,
		y_min = -112,
		heat_point = 20,
		humidity_point = 35,
	})
	minetest.register_biome({
		name = "grassland_ocean",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		y_max = 3,
		y_min = -112,
		heat_point = 50,
		humidity_point = 35,
	})
	minetest.register_biome({
		name = "coniferous_forest_ocean",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		y_max = 3,
		y_min = -112,
		heat_point = 45,
		humidity_point = 70,
	})
	minetest.register_biome({
		name = "deciduous_forest_ocean",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		vertical_blend = 1,
		y_max = -2,
		y_min = -112,
		heat_point = 60,
		humidity_point = 68,
	})
	minetest.register_biome({
		name = "desert_ocean",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_stone = "default:desert_stone",
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		vertical_blend = 1,
		y_max = 3,
		y_min = -112,
		heat_point = 92,
		humidity_point = 16,
	})
	minetest.register_biome({
		name = "sandstone_desert_ocean",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_stone = "default:sandstone",
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		y_max = 3,
		y_min = -112,
		heat_point = 60,
		humidity_point = 0,
	})
	minetest.register_biome({
		name = "cold_desert_ocean",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		vertical_blend = 1,
		y_max = 3,
		y_min = -112,
		heat_point = 40,
		humidity_point = 0,
	})
	minetest.register_biome({
		name = "savanna_ocean",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		vertical_blend = 1,
		y_max = -2,
		y_min = -112,
		heat_point = 89,
		humidity_point = 42,
	})
	minetest.register_biome({
		name = "rainforest_ocean",
		node_top = "default:sand",
		depth_top = 3,
		node_filler = "testventure:aquastone",
		depth_filler = 25,
		node_riverbed = "default:sand",
		depth_riverbed = 2,
		vertical_blend = 1,
		y_max = -2,
		y_min = -112,
		heat_point = 86,
		humidity_point = 65,
	})


	minetest.register_ore({
		ore_type        = "blob",
		ore             = "testventure:slush",
		wherein         = {"testventure:icestone"},
		clust_scarcity  = 13 * 13 * 13,
		clust_size      = 7,
		y_max           = -100,
		y_min           = -31000,
		noise_threshold = 0.0,
		noise_params    = {
			offset = 0.5,
			scale = 0.2,
			spread = {x = 5, y = 5, z = 5},
			seed = 766,
			octaves = 1,
			persist = 0.0
		},
	})


	minetest.register_ore({
		ore_type        = "blob",
		ore             = "default:snowblock",
		wherein         = {"testventure:icestone"},
		clust_scarcity  = 20 * 20 * 20,
		clust_size      = 8,
		y_max           = -100,
		y_min           = -31000,
		noise_threshold = 0.0,
		noise_params    = {
			offset = 0.5,
			scale = 0.2,
			spread = {x = 5, y = 5, z = 5},
			seed = 767,
			octaves = 1,
			persist = 0.0
		},
	})
	minetest.register_ore({
		ore_type        = "blob",
		ore             = "default:snowblock",
		wherein         = {"testventure:icestone"},
		clust_scarcity  = 9 * 9 * 9,
		clust_size      = 8,
		y_max           = 31000,
		y_min           = -100,
		noise_threshold = 0.0,
		noise_params    = {
			offset = 0.5,
			scale = 0.2,
			spread = {x = 5, y = 5, z = 5},
			seed = 767,
			octaves = 1,
			persist = 0.0
		},
	})


-----------------------------------


minetest.register_node("testventure:mine_seed", {
		description = "".. core.colorize("#00eaff", "mine seed\n")..core.colorize("#FFFFFF", "YOU HACKER! YOU!"),
	tiles = {"default_stone.png"},
	drop = "",
	groups = {cracky = 4,not_in_creative_inventory=1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_abm({
	nodenames = {"testventure:mine_seed"},
	neighbors = {"default:stone"},
	interval = 1,
	chance = 1,
	catch_up = false,
	action = function(pos, node)
	minetest.place_schematic(pos, minetest.get_modpath("testventure") .. "/schematics/mine.mts","random",nil, true)
	end
})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:mine_seed",
		wherein        = "default:stone",
		clust_scarcity = 50 * 50 * 50,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -1000,
		y_max          = -100,
	})
	

	minetest.register_ore({
		ore_type        = "blob",
		ore             = "testventure:mud",
		wherein         = {"default:stone"},
		clust_scarcity  = 15 * 15 * 15,
		clust_size      = 5,
		y_min           = -31000,
		y_max           = -50,
		noise_threshold = 0.0,
		noise_params    = {
			offset = 0.5,
			scale = 0.2,
			spread = {x = 5, y = 5, z = 5},
			seed = 17000,
			octaves = 1,
			persist = 0.0
		},
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:aquamarine_ore",
		wherein        = "testventure:aquastone",
		clust_scarcity = 8 * 8 * 8,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -120,
		y_max          = -20,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:eternal_ice_ore",
		wherein        = "testventure:icestone",
		clust_scarcity = 20 * 20 * 20,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -550,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:aquatic_lamp",
		wherein        = "testventure:aquastone",
		clust_scarcity = 6 * 6 * 6,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -120,
		y_max          = -5,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:silver_heart",
		wherein        = "default:stone",
		clust_scarcity = 50 * 50 * 50,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -500,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:silver_heart",
		wherein        = "testvneture:marble",
		clust_scarcity = 42 * 42 * 42,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -500,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:silver_heart",
		wherein        = "testventure:gneis",
		clust_scarcity = 42 * 42 * 42,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -500,
	})
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:silver_heart",
		wherein        = "testventure:junglestone",
		clust_scarcity = 38 * 38 * 38,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -500,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:silver_heart",
		wherein        = "default:desert_stone",
		clust_scarcity = 45 * 45 * 45,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -500,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:silver_heart",
		wherein        = "testventure:icestone",
		clust_scarcity = 42 * 42 * 42,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -500,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:swordstone",
		wherein        = "default:stone",
		clust_scarcity = 69 * 69 * 69,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -100,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:treasure",
		wherein        = "default:stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -10,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:amethyst_ore",
		wherein        = "default:stone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -40,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:topaz_ore",
		wherein        = "default:stone",
		clust_scarcity = 11 * 11 * 11,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -55,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:emerald_ore",
		wherein        = "default:stone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -70,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:sapphire_ore",
		wherein        = "default:stone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -85,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:ruby_ore",
		wherein        = "default:stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -100,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:smaranium_ore",
		wherein        = "default:stone",
		clust_scarcity = 25 * 25 * 25,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -300,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "testventure:black_silver_ore",
		wherein        = "default:stone",
		clust_scarcity = 28 * 28 * 28,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -750,
	})