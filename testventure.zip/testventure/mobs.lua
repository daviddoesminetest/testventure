
---
--- armsdealer
---

mobs:register_mob("testventure:armsdealer", {
	type = "npc",
	damage = 5,
	attack_type = "dogfight",
	attacks_monsters = true,
	pathfinding = false,
	hp_min = 100,
	hp_max = 150,
	armor = 100,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "old_character.b3d",
	textures = {
		{"testventure_armsdealer.png"}, 
	},
	makes_footstep_sound = true,
	sounds = {},
	walk_velocity = 2,
	run_velocity = 5,
	jump = true,
	drops = {},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	view_range = 5,
	owner = "",
	fear_height = 3,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
	on_rightclick = function(self, clicker, param)
	for _, player in pairs(minetest.get_connected_players()) do
		minetest.show_formspec(player:get_player_name(), "testventure:armsdealer_form", armsdealer_form)
	end
end
})

mobs:spawn({
	name = "testventure:armsdealer",
	nodes = {"default:dirt_with_grass", "default:dirt_with_dry_grass","default:desert_sand"},
	min_light = 10,
	chance = 500000,
	active_object_count = 1,
	max_height = 31000,
})

minetest.register_craftitem("testventure:spawnegg_armsdealer", {
		description = "" ..core.colorize("#00eaff","Armsdealer spawnegg \n")..core.colorize("#ffffff", "Spawns an armsdealer."),
	inventory_image = "testventure_spawnegg_armsdealer.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:armsdealer")
			itemstack:take_item()
		end
		return itemstack
	end,
})

---
--- merchant
---

mobs:register_mob("testventure:merchant", {
	type = "npc",

	damage = 4,
	attack_type = "dogfight",
	attacks_monsters = true,
	pathfinding = false,
	hp_min = 150,
	hp_max = 200,
	armor = 100,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "old_character.b3d",
	textures = {
		{"testventure_merchant.png"}, 
	},
	makes_footstep_sound = true,
	sounds = {},
	walk_velocity = 2,
	run_velocity = 4,
	jump = true,
	drops = {},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	view_range = 5,
	owner = "",
	fear_height = 3,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
	on_rightclick = function(self, clicker, param)
	for _, player in pairs(minetest.get_connected_players()) do
		minetest.show_formspec(player:get_player_name(), "testventure:merchant_form", merchant_form)
	end
end
})

mobs:spawn({
	name = "testventure:merchant",
	nodes = {"default:dirt_with_grass", "default:dirt_with_dry_grass","default:desert_sand"},
	min_light = 10,
	chance = 500000,
	active_object_count = 1,
	max_height = 31000,
})

minetest.register_craftitem("testventure:spawnegg_merchant", {
		description = "" ..core.colorize("#00eaff","merchant spawnegg \n")..core.colorize("#ffffff", "Spawns an merchant."),
	inventory_image = "testventure_spawnegg_merchant.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:merchant")
			itemstack:take_item()
		end
		return itemstack
	end,
})


-----
----- demonworm
-----
local timer = 0
mobs:register_mob("testventure:demonworm", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 8,
	hp_min = 40,
	hp_max = 55,
	armor = 100,
	collisionbox = {-0.5, -1, -0.5, 0.5, 0.9, 0.5},
	visual = "mesh",
	mesh = "testventure_demonworm.b3d",
	textures = {
		{"testventure_demonworm.png"},
	},
	blood_texture = "testventure_dark_dirt.png",
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_sandmonster",
	},
	walk_velocity = 1.25,
	run_velocity = 2.5,
	view_range = 15,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:dark_dirt", chance = 1, min = 1, max = 2},
		{name = "testventure:endarkener", chance = 500, min = 1, max = 1},
		{name = "testventure:quick_end", chance = 750, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 90},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 3},
		{name = "testventure:spawnegg_demonworm", chance = 200, min = 1, max = 1},
		{name = "testventure:worm_tooth", chance = 6, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 60,
		speed_run = 120,
		stand_start = 41,
		stand_end = 79,
		walk_start = 0,
		walk_end = 39,
		run_start = 0,
		run_end = 39,
		punch_start = 81,
		punch_end = 130,
	},

})

mobs:spawn({
	name = "testventure:demonworm",
	nodes = {"testventure:grassy_dark_dirt","testventure:bloodstone","testventure:dark_sand"},
	chance = 2000,
	active_object_count = 2,
	min_height = -31000,
})

minetest.register_craftitem("testventure:spawnegg_demonworm", {
		description = "" ..core.colorize("#00eaff","Demon worm spawnegg \n")..core.colorize("#ffffff", "Spawns a Demon Worm."),
	inventory_image = "testventure_spawnegg_demonworm.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:demonworm")
			itemstack:take_item()
		end
		return itemstack
	end,
})

-----
----- sandworm
-----
local timer = 0
mobs:register_mob("testventure:sandworm", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 8,
	hp_min = 35,
	hp_max = 45,
	armor = 100,
	collisionbox = {-0.5, -1, -0.5, 0.5, 0.9, 0.5},
	visual = "mesh",
	mesh = "testventure_demonworm.b3d",
	textures = {
		{"testventure_sandworm.png"},
	},
	blood_texture = "default_desert_sand.png",
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_sandmonster",
	},
	walk_velocity = 1.25,
	run_velocity = 2.5,
	view_range = 15,
	jump = true,
	floats = 0,
	drops = {
		{name = "default:desert_sand", chance = 1, min = 1, max = 2},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 50},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 3},
		{name = "testventure:spawnegg_sandworm", chance = 200, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 60,
		speed_run = 120,
		stand_start = 41,
		stand_end = 79,
		walk_start = 0,
		walk_end = 39,
		run_start = 0,
		run_end = 39,
		punch_start = 81,
		punch_end = 130,
	},

})

mobs:spawn({
	name = "testventure:sandworm",
	nodes = {"default:desert_stone"},
	chance = 2000,
	active_object_count = 3,

})

minetest.register_craftitem("testventure:spawnegg_sandworm", {
		description = "" ..core.colorize("#00eaff","Sand worm spawnegg \n")..core.colorize("#ffffff", "Spawns a sand Worm."),
	inventory_image = "testventure_spawnegg_sandworm.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:sandworm")
			itemstack:take_item()
		end
		return itemstack
	end,
})

-----
----- ghoul
-----

mobs:register_mob("testventure:ghoul", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 11,
	hp_min = 20,
	hp_max = 25,
	armor = 100,
	collisionbox = {-0.35, -1, -0.35, 0.35, 0.75, 0.35},
	visual = "mesh",
	mesh = "testventure_monsterchar.b3d",
	textures = {
		{"testventure_ghoul.png"},
	},
	blood_texture = "testventure_dark_blood.png",
	makes_footstep_sound = true,
	walk_velocity = 3.00,
	run_velocity = 4.20,
	view_range = 21,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:endarkener", chance = 500, min = 1, max = 1},
		{name = "testventure:quick_end", chance = 750, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 75},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 3},
		{name = "testventure:spawnegg_ghoul", chance = 200, min = 1, max = 1},
		{name = "testventure:dark_blood", chance = 3, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
})

mobs:spawn({
	name = "testventure:ghoul",
	nodes = {"testventure:grassy_dark_dirt","testventure:dark_sand"},
	chance = 5000,
	active_object_count = 2,
	min_height = -31000,
})

minetest.register_craftitem("testventure:spawnegg_ghoul", {
		description = "" ..core.colorize("#00eaff","ghoul spawnegg \n")..core.colorize("#ffffff", "Spawns a ghoul."),
	inventory_image = "testventure_spawnegg_ghoul.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:ghoul")
			itemstack:take_item()
		end
		return itemstack
	end,
})


-----
----- skeleton
-----

mobs:register_mob("testventure:skeleton", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 9,
	hp_min = 30,
	hp_max = 40,
	armor = 100,
	collisionbox = {-0.35, -1, -0.35, 0.35, 0.75, 0.35},
	visual = "mesh",
	mesh = "testventure_monsterchar.b3d",
	textures = {
		{"testventure_skeleton.png"},
	},
	blood_texture = "testventure_bone.png",
	makes_footstep_sound = true,
	walk_velocity = 2.00,
	run_velocity = 3.0,
	view_range = 15,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:bone_sword", chance = 75, min = 1, max = 1},
		{name = "testventure:pick_bone", chance = 75, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 85},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 2},
		{name = "testventure:spawnegg_skeleton", chance = 200, min = 1, max = 1},
		{name = "testventure:bone", chance = 1, min = 1, max = 3},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
})

mobs:spawn({
	name = "testventure:skeleton",
	nodes = {"default:stone"},
	chance = 8000,
	max_light = 11,
	active_object_count = 3,
	max_height = -250,
})

minetest.register_craftitem("testventure:spawnegg_skeleton", {
		description = "" ..core.colorize("#00eaff","Skeleton spawnegg \n")..core.colorize("#ffffff", "Spawns a Skeleton."),
	inventory_image = "testventure_spawnegg_skeleton.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:skeleton")
			itemstack:take_item()
		end
		return itemstack
	end,
})

-----
----- seaweedy_skeleton
-----

mobs:register_mob("testventure:seaweedy_skeleton", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 15,
	hp_min = 50,
	hp_max = 60,
	armor = 100,
	collisionbox = {-0.35, -1, -0.35, 0.35, 0.75, 0.35},
	visual = "mesh",
	mesh = "testventure_monsterchar.b3d",
	textures = {
		{"testventure_seaweedy_skeleton.png"},
	},
	blood_texture = "testventure_bone.png",
	makes_footstep_sound = true,
	walk_velocity = 2.1,
	run_velocity = 3.2,
	view_range = 15,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 85},
		{name = "testventure:coin_silver", chance = 1, min = 2, max = 6},
		{name = "testventure:spawnegg_seaweedy_skeleton", chance = 200, min = 1, max = 1},
		{name = "testventure:bone", chance = 1, min = 1, max = 3},
		{name = "testventure:aquamarine_shards", chance = 6, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
})

mobs:spawn({
	name = "testventure:seaweedy_skeleton",
	nodes = {"testventure:aquastone"},
	chance = 4200,
	active_object_count = 5,
	max_height = -5,
})

minetest.register_abm({
	nodenames = {"default:water_source"},
	interval = 15,
	chance = 50000,
		action = function(pos, node)
		if pos.y < -10 then
	if minetest.get_node(pos).name == "default:water_source" then
	minetest.env:add_entity(pos, "testventure:seaweedy_skeleton")
	end end end
})

minetest.register_craftitem("testventure:spawnegg_seaweedy_skeleton", {
		description = "" ..core.colorize("#00eaff","seaweedy_skeleton spawnegg \n")..core.colorize("#ffffff", "Spawns a seaweedy_skeleton."),
	inventory_image = "testventure_spawnegg_seaweedy_skeleton.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:seaweedy_skeleton")
			itemstack:take_item()
		end
		return itemstack
	end,
})


-----
----- mummy
-----

mobs:register_mob("testventure:mummy", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 8,
	hp_min = 25,
	hp_max = 35,
	armor = 100,
	collisionbox = {-0.35, -1, -0.35, 0.35, 0.75, 0.35},
	visual = "mesh",
	mesh = "testventure_monsterchar.b3d",
	textures = {
		{"testventure_mummy.png"},
	},
	blood_texture = "default_sand.png",
	makes_footstep_sound = true,
	walk_velocity = 2.00,
	run_velocity = 3.0,
	view_range = 15,
	jump = true,
	floats = 0,
	drops = {
		{name = "default:gold_ingot", chance = 10, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 5, max = 50},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 2},
		{name = "testventure:spawnegg_mummy", chance = 200, min = 1, max = 1},
		{name = "default:paper", chance = 1, min = 1, max = 2},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
})

mobs:spawn({
	name = "testventure:mummy",
	nodes = {"default:desert_sand"},
	chance = 9001,
	active_object_count = 3,
	max_height = 31000,
})

minetest.register_craftitem("testventure:spawnegg_mummy", {
		description = "" ..core.colorize("#00eaff","mummy spawnegg \n")..core.colorize("#ffffff", "Spawns a mummy."),
	inventory_image = "testventure_spawnegg_mummy.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:mummy")
			itemstack:take_item()
		end
		return itemstack
	end,
})


-----
----- green slime
-----

mobs:register_mob("testventure:slime_green", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 2.25,
	damage = 2,
	hp_min = 6,
	hp_max = 8,
	armor = 100,
	collisionbox = {-0.3, -0.3, -0.3, 0.3, 0.3, 0.3},
	visual = "wielditem",
	textures = {
		{"testventure:slime_green"},
	},
	blood_texture = "testventure_green_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 2,
	run_velocity = 2,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 6,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:slimeball", chance = 1, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 5, max = 15},
		{name = "testventure:spawnegg_green_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 250, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:slime_green",
	nodes = {"default:dirt_with_grass"},
	min_light = 10,
	chance = 3500,
	active_object_count = 4,
	max_height = 31000,
})


minetest.register_craftitem("testventure:spawnegg_green_slime", {
		description = "" ..core.colorize("#00eaff","Green slime spawnegg \n")..core.colorize("#ffffff", "Spawns a green slime."),
	inventory_image = "testventure_spawnegg_greenslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_green")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_green", {
	tiles = {
		"testventure_green_slime_top.png",
		"testventure_green_slime_top.png",
		"testventure_green_slime_side.png",
		"testventure_green_slime_side.png",
		"testventure_green_slime_side.png",
		"testventure_green_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.4,y=0.4,z=0.4},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})

-----
----- blue slime
-----

mobs:register_mob("testventure:slime_blue", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 2.5,
	damage = 3,
	hp_min = 10,
	hp_max = 14,
	armor = 100,
	collisionbox = {-0.4, -0.4, -0.4, 0.4, 0.4, 0.4},
	visual = "wielditem",
	textures = {
		{"testventure:slime_blue"},
	},
	blood_texture = "testventure_blue_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 3,
	run_velocity = 3,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 7,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:slimeball", chance = 1, min = 1, max = 2},
		{name = "testventure:coin_copper", chance = 1, min = 9, max = 28},
		{name = "testventure:spawnegg_blue_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 225, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:slime_blue",
	nodes = {"default:dirt_with_grass"},
	min_light = 10,
	chance = 8000,
	active_object_count = 3,
	max_height = 31000,
})


minetest.register_craftitem("testventure:spawnegg_blue_slime", {
		description = "" ..core.colorize("#00eaff","blue slime spawnegg \n")..core.colorize("#ffffff", "Spawns a blue slime."),
	inventory_image = "testventure_spawnegg_blueslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_blue")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_blue", {
	tiles = {
		"testventure_blue_slime_top.png",
		"testventure_blue_slime_top.png",
		"testventure_blue_slime_side.png",
		"testventure_blue_slime_side.png",
		"testventure_blue_slime_side.png",
		"testventure_blue_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.55,y=0.55,z=0.55},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})


-----
----- jungle slime
-----

mobs:register_mob("testventure:slime_jungle", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 2.75,
	damage = 10,
	hp_min = 35,
	hp_max = 45,
	armor = 100,
	collisionbox = {-0.75, -0.75, -0.75, 0.75, 0.75, 0.75},
	visual = "wielditem",
	textures = {
		{"testventure:slime_jungle"},
	},
	blood_texture = "testventure_jungle_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 3.5,
	run_velocity = 3.5,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 8,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:slimeball", chance = 1, min = 1, max = 2},
		{name = "testventure:coin_copper", chance = 1, min = 9, max = 60},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 6},
		{name = "testventure:spawnegg_jungle_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 150, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:slime_jungle",
	nodes = {"testventure:jungle_mud","testventure:junglestone"},
	chance = 5000,
	active_object_count = 4,
})


minetest.register_craftitem("testventure:spawnegg_jungle_slime", {
		description = "" ..core.colorize("#00eaff","jungle slime spawnegg \n")..core.colorize("#ffffff", "Spawns a jungle slime."),
	inventory_image = "testventure_spawnegg_jungleslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_jungle")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_jungle", {
	tiles = {
		"testventure_jungle_slime_top.png",
		"testventure_jungle_slime_top.png",
		"testventure_jungle_slime_side.png",
		"testventure_jungle_slime_side.png",
		"testventure_jungle_slime_side.png",
		"testventure_jungle_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.9,y=0.9,z=0.9},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})



-----
----- red slime
-----

mobs:register_mob("testventure:slime_red", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 2.75,
	damage = 4,
	hp_min = 16,
	hp_max = 22,
	armor = 100,
	collisionbox = {-0.45, -0.45, -0.45, 0.45, 0.45, 0.45},
	visual = "wielditem",
	textures = {
		{"testventure:slime_red"},
	},
	blood_texture = "testventure_red_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 3,
	run_velocity = 3,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 7,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:slimeball", chance = 1, min = 1, max = 3},
		{name = "testventure:coin_copper", chance = 1, min = 20, max = 80},
		{name = "testventure:spawnegg_red_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 200, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:slime_red",
	nodes = {"default:stone"},
	max_light = 12,
	chance = 7500,
	active_object_count = 4,
	max_height = 0,
})


minetest.register_craftitem("testventure:spawnegg_red_slime", {
		description = "" ..core.colorize("#00eaff","red slime spawnegg \n")..core.colorize("#ffffff", "Spawns a red slime."),
	inventory_image = "testventure_spawnegg_redslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_red")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_red", {
	tiles = {
		"testventure_red_slime_top.png",
		"testventure_red_slime_top.png",
		"testventure_red_slime_side.png",
		"testventure_red_slime_side.png",
		"testventure_red_slime_side.png",
		"testventure_red_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.62,y=0.62,z=0.62},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})

-----
----- blood slime
-----

mobs:register_mob("testventure:slime_blood", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 3.5,
	damage = 10,
	hp_min = 35,
	hp_max = 40,
	armor = 100,
	collisionbox = {-0.8, -0.8, -0.8, 0.8, 0.8, 0.8},
	visual = "wielditem",
	textures = {
		{"testventure:slime_blood"},
	},
	blood_texture = "testventure_blood_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 4.5,
	run_velocity = 4.5,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 9,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:crimson_slimeball", chance = 1, min = 1, max = 3},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 80},
		{name = "testventure:coin_silver", chance = 1, min = 2, max = 6},
		{name = "testventure:spawnegg_blood_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 150, min = 1, max = 1},
		{name = "testventure:endarkener", chance = 500, min = 1, max = 1},
		{name = "testventure:quick_end", chance = 750, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:slime_blood",
	nodes = {"testventure:grassy_dark_dirt","testventure:bloodstone","testventure:dark_sand"},
	min_light = 0,
	chance = 9001,
	active_object_count = 3,
	max_height = 31000,
})


minetest.register_craftitem("testventure:spawnegg_blood_slime", {
		description = "" ..core.colorize("#00eaff","blood slime spawnegg \n")..core.colorize("#ffffff", "Spawns a blood slime."),
	inventory_image = "testventure_spawnegg_bloodslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_blood")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_blood", {
	tiles = {
		"testventure_blood_slime_top.png",
		"testventure_blood_slime_top.png",
		"testventure_blood_slime_side.png",
		"testventure_blood_slime_side.png",
		"testventure_blood_slime_side.png",
		"testventure_blood_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=1.10,y=1.10,z=1.10},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})




-----
----- sand slime
-----

mobs:register_mob("testventure:slime_sand", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 2.75,
	damage = 6,
	hp_min = 20,
	hp_max = 30,
	armor = 100,
	collisionbox = {-0.45, -0.45, -0.45, 0.45, 0.45, 0.45},
	visual = "wielditem",
	textures = {
		{"testventure:slime_sand"},
	},
	blood_texture = "testventure_sand_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 3.25,
	run_velocity = 3.25,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 7,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:sandy_slimeball", chance = 1, min = 1, max = 2},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 40},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 1},
		{name = "testventure:spawnegg_sand_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 190, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:slime_sand",
	nodes = {"default:desert_sand"},
	max_light = 15,
	chance = 7500,
	active_object_count = 4,
	max_height = 31000,
})


minetest.register_craftitem("testventure:spawnegg_sand_slime", {
		description = "" ..core.colorize("#00eaff","sand slime spawnegg \n")..core.colorize("#ffffff", "Spawns a sand slime."),
	inventory_image = "testventure_spawnegg_sandslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_sand")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_sand", {
	tiles = {
		"testventure_sand_slime_top.png",
		"testventure_sand_slime_top.png",
		"testventure_sand_slime_side.png",
		"testventure_sand_slime_side.png",
		"testventure_sand_slime_side.png",
		"testventure_sand_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.62,y=0.62,z=0.62},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})

-----
----- frost slime
-----

mobs:register_mob("testventure:slime_frost", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 2.75,
	damage = 6,
	hp_min = 25,
	hp_max = 35,
	armor = 100,
	collisionbox = {-0.45, -0.45, -0.45, 0.45, 0.45, 0.45},
	visual = "wielditem",
	textures = {
		{"testventure:slime_frost"},
	},
	blood_texture = "testventure_frost_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 2.75,
	run_velocity = 2.75,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 6,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:frozen_slimeball", chance = 1, min = 1, max = 2},
		{name = "testventure:swordsicle", chance = 400, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 40},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 1},
		{name = "testventure:spawnegg_frost_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 190, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:slime_frost",
	nodes = {"default:ice","default:dirt_with_snow","default:snow","default:snowblock","default:silver_sand","testventure:icestone","default:permafrost_with_moss","default:permafrost_with_stones","default:permafrost"},
	max_light = 15,
	chance = 7500,
	active_object_count = 4,
	max_height = 31000,
})


minetest.register_craftitem("testventure:spawnegg_frost_slime", {
		description = "" ..core.colorize("#00eaff","frost slime spawnegg \n")..core.colorize("#ffffff", "Spawns a frost slime."),
	inventory_image = "testventure_spawnegg_frostslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_frost")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_frost", {
	tiles = {
		"testventure_frost_slime_top.png",
		"testventure_frost_slime_top.png",
		"testventure_frost_slime_side.png",
		"testventure_frost_slime_side.png",
		"testventure_frost_slime_side.png",
		"testventure_frost_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.62,y=0.62,z=0.62},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})

-----
----- pinky
-----

mobs:register_mob("testventure:pinky", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 2.25,
	damage = 3,
	hp_min = 150,
	hp_max = 200,
	armor = 100,
	collisionbox = {-0.15, -0.15, -0.15, 0.15, 0.15, 0.15},
	visual = "wielditem",
	textures = {
		{"testventure:pinky"},
	},
	blood_texture = "testventure_pinky_side.png",
	makes_footstep_sound = true,
	walk_velocity = 4.20,
	run_velocity = 4.20,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 8,
	stepheight = 1.1,
	floats = 0,
	view_range = 50,
	drops = {
		{name = "testventure:pink_slimeball", chance = 1, min = 5, max = 25},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 40},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 1},
		{name = "testventure:coin_gold", chance = 1, min = 1, max = 1},
		{name = "testventure:spawnegg_pinky", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 20, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:pinky",
	nodes = {"default:dirt_with_grass","default:stone"},
	max_light = 15,
	chance = 1000000,
	active_object_count = 1,
	min_height = -100,
})


minetest.register_craftitem("testventure:spawnegg_pinky", {
		description = "" ..core.colorize("#00eaff","Pinky spawnegg \n")..core.colorize("#ffffff", "Spawns a pinky."),
	inventory_image = "testventure_spawnegg_pinky.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:pinky")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:pinky", {
	tiles = {
		"testventure_pinky_top.png",
		"testventure_pinky_top.png",
		"testventure_pinky_side.png",
		"testventure_pinky_side.png",
		"testventure_pinky_side.png",
		"testventure_pinky_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.16,y=0.16,z=0.16},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})

-----
----- yellow slime
-----

mobs:register_mob("testventure:slime_yellow", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 3.0,
	damage = 6,
	hp_min = 25,
	hp_max = 40,
	armor = 100,
	collisionbox = {-0.55, -0.55, -0.55, 0.55, 0.55, 0.55},
	visual = "wielditem",
	textures = {
		{"testventure:slime_yellow"},
	},
	blood_texture = "testventure_yellow_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 3,
	run_velocity = 3,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 7,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:slimeball", chance = 1, min = 1, max = 3},
		{name = "testventure:coin_copper", chance = 1, min = 21, max = 96},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 2},
		{name = "testventure:spawnegg_yellow_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 200, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:slime_yellow",
	nodes = {"default:stone"},
	max_light = 12,
	chance = 13500,
	active_object_count = 3,
	max_height = 0,
})


minetest.register_craftitem("testventure:spawnegg_yellow_slime", {
		description = "" ..core.colorize("#00eaff","yellow slime spawnegg \n")..core.colorize("#ffffff", "Spawns a yellow slime."),
	inventory_image = "testventure_spawnegg_yellowslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_yellow")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_yellow", {
	tiles = {
		"testventure_yellow_slime_top.png",
		"testventure_yellow_slime_top.png",
		"testventure_yellow_slime_side.png",
		"testventure_yellow_slime_side.png",
		"testventure_yellow_slime_side.png",
		"testventure_yellow_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.725,y=0.725,z=0.725},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})

-----
----- demoneye
-----

mobs:register_mob("testventure:demoneye", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = false,
	reach = 2,
	damage = 8,
	hp_min = 26,
	hp_max = 32,
	armor = 100,
	collisionbox = {-0.4, -0.4, -0.4, 0.4, 0.4, 0.4},
	visual = "mesh",
	mesh = "testventure_demoneye.b3d",
	textures = {
		{"testventure_demoneye.png"},
	},
	blood_texture = "default_glass.png",
	makes_footstep_sound = true,
	walk_velocity = 3.35,
	run_velocity = 3.35,
	view_range = 30,
	jump = true,
  	stepheight = 3,
  	fall_speed = 0,
  	fly = true,
	drops = {
		{name = "testventure:lens", chance = 2, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 50},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 1},
		{name = "testventure:spawnegg_demoneye", chance = 200, min = 1, max = 1},
		{name = "testventure:black_lens", chance = 30, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	animation = {
		speed_normal = 50,
		speed_run = 50,
		stand_start = 1,
		stand_end = 80,
		walk_start = 1,
		walk_end = 80,
		run_start = 1,
		run_end = 80,
		punch_start = 1,
		punch_end = 80,
	},
})

mobs:spawn({
	name = "testventure:demoneye",
	nodes = {"air"},
	chance = 200000,
	active_object_count = 1,
	min_height = -25,
	min_light = 0,
	max_light = 7,
	day_toggle = false,
})

minetest.register_craftitem("testventure:spawnegg_demoneye", {
		description = "" ..core.colorize("#00eaff","Demon eye spawnegg \n")..core.colorize("#ffffff", "Spawns a Demon eye."),
	inventory_image = "testventure_spawnegg_demoneye.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:demoneye")
			itemstack:take_item()
		end
		return itemstack
	end,
})

-----
----- cave_bat
-----

mobs:register_mob("testventure:cave_bat", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = false,
	reach = 2,
	damage = 10,
	hp_min = 20,
	hp_max = 30,
	armor = 100,
	collisionbox = {-0.4, -0.4, -0.4, 0.4, 0.4, 0.4},
	visual = "mesh",
	mesh = "testventure_bat.b3d",
	textures = {
		{"testventure_bat.png"},
	},
	blood_texture = "mobs_blood.png",
	makes_footstep_sound = true,
	walk_velocity = 4.0,
	run_velocity = 4.0,
	view_range = 20,
	jump = true,
  	stepheight = 3,
  	fall_speed = 0,
  	fly = true,
	drops = {
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 70},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 2},
		{name = "testventure:spawnegg_cave_bat", chance = 200, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	animation = {
		speed_normal = 50,
		speed_run = 69,
		stand_start = 1,
		stand_end = 20,
		walk_start = 21,
		walk_end = 40,
		run_start = 21,
		run_end = 40,
		punch_start = 41,
		punch_end = 60,
	},
})

mobs:spawn({
	name = "testventure:cave_bat",
	nodes = {"air"},
	chance = 15000,
	active_object_count = 3,
	max_height = -100,
	min_height = -1000,
	min_light = 0,
	max_light = 7,
})

minetest.register_craftitem("testventure:spawnegg_cave_bat", {
		description = "" ..core.colorize("#00eaff","Cave bat spawnegg \n")..core.colorize("#ffffff", "Spawns a cave bat."),
	inventory_image = "testventure_spawnegg_cave_bat.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:cave_bat")
			itemstack:take_item()
		end
		return itemstack
	end,
})

-----
----- jungle_bat
-----

mobs:register_mob("testventure:jungle_bat", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = false,
	reach = 2,
	damage = 8,
	hp_min = 18,
	hp_max = 26,
	armor = 100,
	collisionbox = {-0.4, -0.4, -0.4, 0.4, 0.4, 0.4},
	visual = "mesh",
	mesh = "testventure_bat.b3d",
	textures = {
		{"testventure_jungle_bat.png"},
	},
	blood_texture = "mobs_blood.png",
	makes_footstep_sound = true,
	walk_velocity = 3.75,
	run_velocity = 3.75,
	view_range = 25,
	jump = true,
  	stepheight = 3,
  	fall_speed = 0,
  	fly = true,
	drops = {
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 80},
		{name = "testventure:coin_silver", chance = 2, min = 1, max = 1},
		{name = "testventure:spawnegg_jungle_bat", chance = 200, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	animation = {
		speed_normal = 50,
		speed_run = 69,
		stand_start = 1,
		stand_end = 20,
		walk_start = 21,
		walk_end = 40,
		run_start = 21,
		run_end = 40,
		punch_start = 41,
		punch_end = 60,
	},
})

mobs:spawn({
	name = "testventure:jungle_bat",
	nodes = {"testventure:junglestone","testventure:jungle_mud","testventure:rich_mahogany_leaves"},
	chance = 6000,
	active_object_count = 3,
})

minetest.register_craftitem("testventure:spawnegg_jungle_bat", {
		description = "" ..core.colorize("#00eaff","jungle bat spawnegg \n")..core.colorize("#ffffff", "Spawns a jungle bat."),
	inventory_image = "testventure_spawnegg_jungle_bat.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:jungle_bat")
			itemstack:take_item()
		end
		return itemstack
	end,
})



-----
----- frost_bat
-----

mobs:register_mob("testventure:frost_bat", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = false,
	reach = 2,
	damage = 12,
	hp_min = 30,
	hp_max = 40,
	armor = 100,
	collisionbox = {-0.4, -0.4, -0.4, 0.4, 0.4, 0.4},
	visual = "mesh",
	mesh = "testventure_bat.b3d",
	textures = {
		{"testventure_frost_bat.png"},
	},
	blood_texture = "mobs_blood.png",
	makes_footstep_sound = true,
	walk_velocity = 4.0,
	run_velocity = 4.0,
	view_range = 20,
	jump = true,
  	stepheight = 3,
  	fall_speed = 0,
  	fly = true,
	drops = {
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 80},
		{name = "testventure:coin_silver", chance = 1, min = 3, max = 5},
		{name = "testventure:spawnegg_frost_bat", chance = 200, min = 1, max = 1},
		{name = "testventure:bow_frost", chance = 400, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	animation = {
		speed_normal = 50,
		speed_run = 69,
		stand_start = 1,
		stand_end = 20,
		walk_start = 21,
		walk_end = 40,
		run_start = 21,
		run_end = 40,
		punch_start = 41,
		punch_end = 60,
	},
})

mobs:spawn({
	name = "testventure:frost_bat",
	nodes = {"testventure:icestone"},
	chance = 5000,
	active_object_count = 3,
	max_height = -125,
	max_light = 10,
})

minetest.register_craftitem("testventure:spawnegg_frost_bat", {
		description = "" ..core.colorize("#00eaff","frost bat spawnegg \n")..core.colorize("#ffffff", "Spawns a frost bat."),
	inventory_image = "testventure_spawnegg_frost_bat.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:frost_bat")
			itemstack:take_item()
		end
		return itemstack
	end,
})



-----
----- zombie
-----

mobs:register_mob("testventure:zombie", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 7,
	hp_min = 28,
	hp_max = 36,
	armor = 100,
	collisionbox = {-0.40, -1, -0.40, 0.40, 0.8, 0.40},
	visual = "mesh",
	mesh = "old_character.b3d",
	textures = {
		{"testventure_zombie.png"},
	},
	blood_texture = "mobs_blood.png",
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_stonemonster",
	},
	walk_velocity = 2.0,
	run_velocity = 2.0,
	view_range = 18,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:zombie_hand", chance = 100, min = 1, max = 1},
		{name = "testventure:bloody_bullet_shell", chance = 200, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 75, max = 100},
		{name = "testventure:coin_silver", chance = 5, min = 1, max = 1},
		{name = "testventure:spawnegg_zombie", chance = 200, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
	on_die = function(self, pos)
	local pos = self.object:getpos()
	local filepath = minetest.get_worldpath().."/bloodmoon"
	local bloodmoon = io.open(filepath, "r")
	if bloodmoon ~= nil then
	bmmode = bloodmoon:read("*l")
	bloodmoon:close()
	bloodmoon_rised = bmmode + 0
		if bloodmoon_rised == 1 then
	if math.random(1, 500) == 1 then
minetest.add_item(pos, "testventure:combat_shotgun")

	end end end end,
})

mobs:spawn({
	name = "testventure:zombie",
	nodes = {"default:dirt","default:dirt_with_grass","default:dirt_with_dry_grass","default:sand" },
	chance = 6000,
	active_object_count = 5,
	min_height = -75,
	min_light = 0,
	max_light = 7,
	day_toggle = false,
})

minetest.register_craftitem("testventure:spawnegg_zombie", {
		description = "" ..core.colorize("#00eaff","zombie spawnegg \n")..core.colorize("#ffffff", "Spawns a zombie."),
	inventory_image = "testventure_spawnegg_zombie.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:zombie")
			itemstack:take_item()
		end
		return itemstack
	end,
})


mobs:register_mob("testventure:blood_zombie", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 30,
	hp_min = 120,
	hp_max = 150,
	armor = 100,
	collisionbox = {-0.40, -1, -0.40, 0.40, 0.8, 0.40},
	visual = "mesh",
	mesh = "old_character.b3d",
	textures = {
		{"testventure_blood_zombie.png"},
	},
	blood_texture = "mobs_blood.png",
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_stonemonster",
	},
	walk_velocity = 5.0,
	run_velocity = 5.0,
	view_range = 18,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:bloody_zombie_hand", chance = 100, min = 1, max = 1},
		{name = "testventure:bloody_bullet_shell", chance = 200, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 75, max = 100},
		{name = "testventure:coin_silver", chance = 1, min = 5, max = 15},
		{name = "testventure:spawnegg_bloody_zombie", chance = 200, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
	on_die = function(self, pos)
	local pos = self.object:getpos()
	local filepath = minetest.get_worldpath().."/bloodmoon"
	local bloodmoon = io.open(filepath, "r")
	if bloodmoon ~= nil then
	bmmode = bloodmoon:read("*l")
	bloodmoon:close()
	bloodmoon_rised = bmmode + 0
		if bloodmoon_rised == 1 then
	if math.random(1, 500) == 1 then
minetest.add_item(pos, "testventure:combat_shotgun")

	end end end end,
})

minetest.register_craftitem("testventure:spawnegg_blood_zombie", {
		description = "" ..core.colorize("#2a00ff","blood zombie spawnegg \n")..core.colorize("#ffffff", "Spawns a blood zombie."),
	inventory_image = "testventure_spawnegg_blood_zombie.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:blood_zombie")
			itemstack:take_item()
		end
		return itemstack
	end,
})

-----
----- frozen_zombie
-----

mobs:register_mob("testventure:frozen_zombie", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 10,
	hp_min = 55,
	hp_max = 60,
	armor = 100,
	collisionbox = {-0.40, -1, -0.40, 0.40, 0.8, 0.40},
	visual = "mesh",
	mesh = "old_character.b3d",
	textures = {
		{"testventure_frozen_zombie.png"},
	},
	blood_texture = "mobs_blood.png",
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_stonemonster",
	},
	walk_velocity = 1.5,
	run_velocity = 1.5,
	view_range = 18,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:zombie_hand", chance = 100, min = 1, max = 1},
		{name = "testventure:bloody_bullet_shell", chance = 200, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 90, max = 100},
		{name = "testventure:coin_silver", chance = 2, min = 1, max = 2},
		{name = "testventure:spawnegg_frozen_zombie", chance = 200, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
	on_die = function(self, pos)
	local pos = self.object:getpos()
	local filepath = minetest.get_worldpath().."/bloodmoon"
	local bloodmoon = io.open(filepath, "r")
	if bloodmoon ~= nil then
	bmmode = bloodmoon:read("*l")
	bloodmoon:close()
	bloodmoon_rised = bmmode + 0
		if bloodmoon_rised == 1 then
	if math.random(1, 500) == 1 then
minetest.add_item(pos, "testventure:combat_shotgun")

	end end end end,
})

mobs:spawn({
	name = "testventure:frozen_zombie",
	nodes = {"default:ice","default:dirt_with_snow","default:snow","default:snowblock","default:silver_sand","testventure:icestone","default:permafrost_with_stones","default:permafrost"},
	chance = 6000,
	active_object_count = 5,
	min_height = -30,
	min_light = 0,
	max_light = 7,
	day_toggle = false,
})

minetest.register_craftitem("testventure:spawnegg_frozen_zombie", {
		description = "" ..core.colorize("#00eaff","frozen zombie spawnegg \n")..core.colorize("#ffffff", "Spawns a frozen zombie."),
	inventory_image = "testventure_spawnegg_frozen_zombie.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:frozen_zombie")
			itemstack:take_item()
		end
		return itemstack
	end,
})


-----
----- oerkki caster

mobs:register_mob("testventure:oerkki_caster", {
	type = "monster",
	passive = false,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 20, 
	dogshoot_count2_max = 5, 
	arrow = "testventure:shadowball",
	shoot_offset = 1.25,
	shoot_interval = 0.9,
	pathfinding = true,
	reach = 2,
	damage = 20,
	hp_min = 35,
	hp_max = 45,
	armor = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 0.9, 0.4},
	visual = "mesh",
	mesh = "mobs_oerkki.b3d",
	textures = {
		{"testventure_oerkki_caster.png"},
	},
	makes_footstep_sound = false,
	sounds = {
		random = "mobs_oerkki",
		shoot_attack = "mobs_fireball",
	},
	walk_velocity = 1,
	run_velocity = 3,
	view_range = 10,
	jump = true,
	drops = {
		{name = "default:obsidian", chance = 3, min = 1, max = 2},
		{name = "testventure:shadow_magic", chance = 4, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 50, max = 100},
		{name = "testventure:coin_silver", chance = 1, min = 5, max = 15},
		{name = "testventure:spawnegg_oerkki_caster", chance = 200, min = 1, max = 1},
	},
	water_damage = 1,
	lava_damage = 4,
	light_damage = 1,
	fear_height = 4,
	animation = {
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 36,
		run_start = 37,
		run_end = 49,
		punch_start = 37,
		punch_end = 49,
		speed_normal = 15,
		speed_run = 15,
	},
})

mobs:register_arrow("testventure:shadowball", {
	visual = "sprite",
	collisionbox = {-0.2, -0.2, -0.2, 0.2, 0.2, 0.2},
	visual_size = {x = 1, y = 1},
	textures = {"testventure_shadowball.png"},
	velocity = 8,
	tail = 1,
	tail_texture = "testventure_shadowball.png",
	tail_size = 10,
	glow = 15,
	expire = 0.1,
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 25},
		}, nil)
	end,
	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 25},
		}, nil)
	end,
	hit_node = function(self, pos, node)
	end
})


mobs:spawn({
	name = "testventure:oerkki_caster",
	nodes = {"default:stone"},
	max_light = 7,
	chance = 8000,
	max_height = -750,
})

minetest.register_craftitem("testventure:spawnegg_oerkki_caster", {
		description = "" ..core.colorize("#00eaff","Oerkki caster spawnegg \n")..core.colorize("#ffffff", "Spawns a Oerkki caster."),
	inventory_image = "testventure_spawnegg_oerkki_caster.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:oerkki_caster")
			itemstack:take_item()
		end
		return itemstack
	end,
})

-----
----- sky_warrior
-----

mobs:register_mob("testventure:sky_warrior", {
	type = "monster",
	passive = false,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 20, 
	dogshoot_count2_max = 10, 
	pathfinding = true,
	shoot_interval = 1.0,
	arrow = "testventure:sky_arrow",
	shoot_offset = 2.0,
	damage = 30,
	hp_min = 75,
	hp_max = 100,
	armor = 100,
	collisionbox = {-0.35, -1, -0.35, 0.35, 0.75, 0.35},
	visual = "mesh",
	mesh = "testventure_monsterchar.b3d",
	textures = {
		{"testventure_sky_warrior.png"},
	},
	sounds = {
		shoot_attack = "testventure_throw",
	},
	blood_texture = "testventure_shadowball.png",
	makes_footstep_sound = true,
	walk_velocity = 3.50,
	run_velocity = 4.50,
	view_range = 40,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:bow_sky", chance = 200, min = 1, max = 1},
		{name = "testventure:cloud_sword", chance = 200, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 80},
		{name = "testventure:coin_silver", chance = 1, min = 3, max = 7},
		{name = "testventure:spawnegg_sky_warrior", chance = 200, min = 1, max = 1},
		{name = "testventure:ruby", chance = 33, min = 1, max = 1},
		{name = "testventure:cloudantite_bar", chance = 20, min = 1, max = 1},
		{name = "default:gold_ingot", chance = 20, min = 1, max = 1},
		{name = "testventure:sky_arrow", chance = 1, min = 2, max = 8},
	},
	water_damage = 1,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
})

minetest.register_craftitem("testventure:spawnegg_sky_warrior", {
		description = "" ..core.colorize("#00eaff","Sky warrior spawnegg \n")..core.colorize("#ffffff", "Spawns a sky warrior."),
	inventory_image = "testventure_spawnegg_sky_warrior.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:sky_warrior")
			itemstack:take_item()
		end
		return itemstack
	end,
})

mobs:register_arrow("testventure:sky_arrow", {
	visual = "wielditem",
	collisionbox = {-0.2, -0.2, -0.2, 0.2, 0.2, 0.2},
	visual_size = {x = 0.5, y = 0.5},
	textures = {"testventure:sky_arrow_shot"},
	rotate = 180,
	velocity = 40,
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 25},
		}, nil)
	end,
	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 25},
		}, nil)
	end,
	hit_node = function(self, pos, node)
	end
})

mobs:spawn({
	name = "testventure:sky_warrior",
	nodes = {"testventure:grassy_skydirt","testventure:thick_cloud"},
	active_object_count = 5,
	chance = 6000,
})

-----
----- white slime
-----

mobs:register_mob("testventure:slime_white", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 3.0,
	damage = 20,
	hp_min = 30,
	hp_max = 40,
	armor = 100,
	collisionbox = {-0.6, -0.6, -0.6, 0.6, 0.6, 0.6},
	visual = "wielditem",
	textures = {
		{"testventure:slime_white"},
	},
	blood_texture = "testventure_white_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 4,
	run_velocity = 4,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 7,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:slimeball", chance = 1, min = 1, max = 4},
		{name = "testventure:cloud_sword", chance = 400, min = 1, max = 1},
		{name = "testventure:thick_cloud", chance = 1, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 9, max = 90},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 2},
		{name = "testventure:spawnegg_white_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 100, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


mobs:spawn({
	name = "testventure:slime_white",
	nodes = {"testventure:grassy_skydirt","testventure:thick_cloud"},
	chance = 5000,
	active_object_count = 3,
	max_height = 31000,
})


minetest.register_craftitem("testventure:spawnegg_white_slime", {
		description = "" ..core.colorize("#00eaff","white slime spawnegg \n")..core.colorize("#ffffff", "Spawns a white slime."),
	inventory_image = "testventure_spawnegg_whiteslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_white")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_white", {
	tiles = {
		"testventure_white_slime_top.png",
		"testventure_white_slime_top.png",
		"testventure_white_slime_side.png",
		"testventure_white_slime_side.png",
		"testventure_white_slime_side.png",
		"testventure_white_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.85,y=0.85,z=0.85},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})



-------
-------
------- bosses
-------
-------

local boulder_timer = 0

-----
----- bloodstone_golem
-----
local timer = 0
mobs:register_mob("testventure:bloodstone_golem", {
	type = "monster",
	passive = false,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 10, 
	dogshoot_count2_max = 10, 
	arrow = "testventure:bloodstone_boulder",
	shoot_offset = 1.5,
	shoot_interval = 0.5,
	pathfinding = true,
	knock_back = false,
	reach = 4.20,
	damage = 69,
	hp_min = 2500,
	hp_max = 2500,
	armor = 100,
	collisionbox = {-0.8, -1, -0.8, 0.8, 1.75, 0.8},
	visual = "mesh",
	mesh = "testventure_golem.b3d",
	textures = {
		{"testventure_bloodstone_golem.png"},
	},
	blood_texture = "testventure_bloodstone.png",
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_dirtmonster",
	},
	walk_velocity = 4.0,
	run_velocity = 5.0,
	view_range = 50,
	jump = true,
	fall_speed = -69,
	jump_height = 20,
	fall_damage = 0,
	floats = 0,
	drops = {
		{name = "testventure:crimrubite_lump", chance = 1, min = 9, max = 35},
		{name = "testventure:coin_gold", chance = 1, min = 3, max = 15},
		{name = "testventure:coin_silver", chance = 1, min = 10, max = 100},
		{name = "testventure:spiked_bracelets", chance = 2, min = 1, max = 1},
		{name = "testventure:bloodstone_club", chance = 2, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 40,
	animation = {
		speed_normal = 69,
		speed_run = 80,
		stand_start = 1,
		stand_end = 40,
		walk_start = 41,
		walk_end = 80,
		run_start = 41,
		run_end = 80,
		punch_start = 81,
		punch_end = 120,
	},
	do_custom = function(self, dtime)

			local bdr_pos = self.object:get_pos()
			if bdr_pos ~= nil then
	boulder_timer = boulder_timer + dtime
		if boulder_timer > 1 then
		boulder_timer = 0
minetest.add_entity({x=bdr_pos.x + math.random(-20, 20), y=bdr_pos.y + math.random(8, 12), z=bdr_pos.z + (math.random(-20, 20))}, "testventure:cboulder_projectile")
			
		end
		end
		end,
	on_die = function(self, pos)
 minetest.chat_send_all("" ..core.colorize("#c000ff","Bloodstone golem has been defeated"))
local filepath = minetest.get_worldpath().."/progression"
	local prog = io.open(filepath,"r")
	if prog ~= nil then
	destiny = prog:read("*l") or 0
	prog:close()
	destnum = destiny + 0
		if destnum < 1 then
local filepath = minetest.get_worldpath().."/progression"
		local prog = io.open(filepath,"w")
		prog:write("1")
		prog:close(prog)
 minetest.chat_send_all("" ..core.colorize("#00df7e","The pressence of dark magic feels stronger..."))
	end
	end end ,

})

mobs:register_arrow("testventure:bloodstone_boulder", {
	visual = "sprite",
	collisionbox = {-0.0, -0.0, -0.0, 0.0, 0.0, 0.0},
	visual_size = {x = 1.5, y = 1.5},
	hp_max = 1000,
	textures = {"testventure_bloodstone_boulder.png"},
	velocity = 30,
	tail = 0,
	tail_texture = "testventure_bloodstone_boulder.png",
	tail_size = 10,
	glow = 0,
	expire = 0.1,
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 100},
		}, nil)

	end,
	hit_node = function(self, pos, node)
	pos.y = pos.y+1
for i=1,9 do
local crack = minetest.add_entity(pos, 	"testventure:rockfrag_projectile")
crack:setvelocity({x=0, y=8, z=0})
	crack:setacceleration({x=math.random(-20, 20), y=math.random(-9, 3),z=math.random(-20, 20)})
	end
	end,
	hit_mob = function(self, player, pos)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 1},
		}, nil)

	end
})

local testventure_rockfrag_projectile = {
	physical = true,
	timer = 0,
	visual = "sprite",
	visual_size = {x=1.0, y=1.0},
	textures = {"testventure_bloodstone_rock.png"},
	lastpos= {},
	collisionbox = {-0.25, -0.25, -0.25, 0.25, 0.25, 0.25},
}
testventure_rockfrag_projectile.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.10 then
	local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.0)
	for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:rockfrag_projectile" and obj:get_luaentity().name ~= "__builtin:item" then
				local damage = 0 
				obj:punch(self.object, 1.0, {
				full_punch_interval = 1.0,
				damage_groups= {fleshy = damage,},
					}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
				else
				local damage = 45
				obj:punch(self.object, 1.0, {
				full_punch_interval = 1.0,
				damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
			end
		if self.timer >= 5 then
		self.object:remove()
			end

end
end
end

minetest.register_entity("testventure:rockfrag_projectile", testventure_rockfrag_projectile)

local testventure_cboulder_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=3.0, y=3.0},
	textures = {"testventure_bloodstone_boulder.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_cboulder_projectile.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.05 then
	self.object:setacceleration({x=0, y=-12, z=0})
	local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 3.0)
	for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:cboulder_projectile" and obj:get_luaentity().name ~= "__builtin:item" then
				local damage = 0
				obj:punch(self.object, 1.0, {
				full_punch_interval = 1.0,
				damage_groups= {fleshy = damage,},
					}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				end
			else
				local damage = 65
				obj:punch(self.object, 1.0, {
				full_punch_interval = 1.0,
				damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
for i=1,6 do
local crack = minetest.add_entity(pos, 	"testventure:rockfrag_projectile")
crack:setvelocity({x=0, y=12, z=0})
	crack:setacceleration({x=math.random(-20, 20), y=math.random(-9, 4),z=math.random(-20, 20)})
	end
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end
minetest.register_entity("testventure:cboulder_projectile", testventure_cboulder_projectile)

minetest.register_craftitem("testventure:bloodstone_sculpture", {
		description = "" ..core.colorize("#00eaff","Creepy bloodstone sculpture\n") ..core.colorize("#ffffff", "Summons the Bloodstone golem.\n")..core.colorize("#ffffff", "Only usable in underground darklands."),
	inventory_image = "testventure_bloodstone_sculpture.png",
	stack_max = 20,
	on_place = function(itemstack, placer, pointed_thing, pos)
		if pointed_thing.above then
		local pos = placer:getpos()
if minetest.find_node_near(pos, 6, {"group:spreads_darkness"}) then
	if pos.y < -5 then
			minetest.env:add_entity(pointed_thing.above, "testventure:bloodstone_golem")
			itemstack:take_item()
 minetest.chat_send_player(placer:get_player_name(),"" ..core.colorize("#c000ff","Bloodstone golem has been summoned!"))
		end
		end
		end
		return itemstack
	end,
})

----
---- progress_mode
----


----
---- pre-progress
----

-----
----- shadow_assasin
-----

mobs:register_mob("testventure:shadow_assasin", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 25,
	hp_min = 80,
	hp_max = 100,
	armor = 100,
	collisionbox = {-0.35, -1, -0.35, 0.35, 0.75, 0.35},
	visual = "mesh",
	mesh = "testventure_monsterchar.b3d",
	textures = {
		{"testventure_shadow_assasin.png"},
	},
	blood_texture = "testventure_shadowball.png",
	makes_footstep_sound = true,
	walk_velocity = 3.50,
	run_velocity = 4.50,
	view_range = 30,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:shadow_dagger", chance = 100, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 85},
		{name = "testventure:coin_silver", chance = 1, min = 2, max = 6},
		{name = "testventure:spawnegg_shadow_assasin", chance = 200, min = 1, max = 1},
		{name = "testventure:shadow_magic", chance = 11, min = 1, max = 1},
	},
	water_damage = 1,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
})

minetest.register_craftitem("testventure:spawnegg_shadow_assasin", {
		description = "" ..core.colorize("#00eaff","Shadow assasin spawnegg \n")..core.colorize("#ffffff", "Spawns a shadow assasin."),
	inventory_image = "testventure_spawnegg_shadow_assasin.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:shadow_assasin")
			itemstack:take_item()
		end
		return itemstack
	end,
})

-----
----- darkness_sniper
-----

mobs:register_mob("testventure:darkness_sniper", {
	type = "monster",
	passive = false,
	attack_type = "shoot",
	shoot_interval = 2.0,
	arrow = "testventure:sh_sniper_bullet",
	shoot_offset = 2.0,
	damage = 125,
	hp_min = 150,
	hp_max = 200,
	armor = 100,
	collisionbox = {-0.35, -1, -0.35, 0.35, 0.75, 0.35},
	visual = "mesh",
	mesh = "testventure_monsterchar.b3d",
	textures = {
		{"testventure_darkness_sniper.png"},
	},
	sounds = {
		shoot_attack = "testventure_rifle",
	},
	blood_texture = "testventure_shadowball.png",
	makes_footstep_sound = true,
	walk_velocity = 3.50,
	run_velocity = 4.50,
	view_range = 40,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:shadow_rifle", chance = 75, min = 1, max = 1},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 90},
		{name = "testventure:coin_silver", chance = 1, min = 3, max = 10},
		{name = "testventure:spawnegg_darkness_sniper", chance = 200, min = 1, max = 1},
		{name = "testventure:black_silver_bar", chance = 9, min = 1, max = 1},
		{name = "testventure:black_silver_bullet", chance = 1, min = 8, max = 16},
	},
	water_damage = 1,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
})

minetest.register_craftitem("testventure:spawnegg_darkness_sniper", {
		description = "" ..core.colorize("#00eaff","Darkness sniper spawnegg \n")..core.colorize("#ffffff", "Spawns a darkness sniper."),
	inventory_image = "testventure_spawnegg_darkness_sniper.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:darkness_sniper")
			itemstack:take_item()
		end
		return itemstack
	end,
})

mobs:register_arrow("testventure:sh_sniper_bullet", {
	visual = "sprite",
	collisionbox = {-0.2, -0.2, -0.2, 0.2, 0.2, 0.2},
	visual_size = {x = 0.5, y = 0.5},
	textures = {"testventure_bulletshot.png"},
	velocity = 60,
	tail = 1,
	tail_texture = "testventure_bulletshot.png",
	tail_size = 6,
	glow = 15,
	expire = 0.20,
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 125},
		}, nil)
	end,
	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 125},
		}, nil)
	end,
	hit_node = function(self, pos, node)
	end
})

---
---
---

-----
----- magic slime
-----

mobs:register_mob("testventure:slime_magic", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	reach = 2.5,
	damage = 19,
	hp_min = 30,
	hp_max = 50,
	armor = 100,
	collisionbox = {-0.4, -0.4, -0.4, 0.4, 0.4, 0.4},
	visual = "wielditem",
	textures = {
		{"testventure:slime_magic"},
	},
	blood_texture = "testventure_magic_slime_side.png",
	makes_footstep_sound = true,
	walk_velocity = 3.25,
	run_velocity = 3.25,
	walk_chance = 0,
	fall_speed = -50,
	jump_chance = 30,
	jump_height = 7,
	stepheight = 1.1,
	floats = 0,
	view_range = 20,
	drops = {
		{name = "testventure:magic_slimeball", chance = 1, min = 1, max = 2},
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 90},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 2},
		{name = "testventure:spawnegg_magic_slime", chance = 200, min = 1, max = 1},
		{name = "testventure:boots_slime", chance = 100, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 8,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
})


minetest.register_craftitem("testventure:spawnegg_magic_slime", {
		description = "" ..core.colorize("#2a00ff","magic slime spawnegg \n")..core.colorize("#ffffff", "Spawns a magic slime."),
	inventory_image = "testventure_spawnegg_magicslime.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:slime_magic")
			itemstack:take_item()
		end
		return itemstack
	end,
})


minetest.register_node("testventure:slime_magic", {
	tiles = {
		"testventure_magic_slime_top.png",
		"testventure_magic_slime_top.png",
		"testventure_magic_slime_side.png",
		"testventure_magic_slime_side.png",
		"testventure_magic_slime_side.png",
		"testventure_magic_slime_side.png"
	},
	drawtype = "nodebox",
	wield_scale = {x=0.55,y=0.55,z=0.55},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.3125, 0.3125}, -- NodeBox1
			{-0.375, -0.5, -0.3125, 0.375, 0.25, 0.3125}, -- NodeBox2
			{-0.3125, -0.5, -0.375, 0.3125, 0.25, 0.375}, -- NodeBox3
			{-0.3125, -0.4375, -0.4375, 0.3125, 0.125, 0.4375}, -- NodeBox4
			{-0.375, -0.4375, -0.375, 0.375, 0.125, 0.375}, -- NodeBox5
			{-0.4375, -0.4375, -0.3125, 0.4375, 0.125, 0.3125}, -- NodeBox6
			{-0.25, -0.375, -0.5, 0.25, 0, 0.5}, -- NodeBox7
			{-0.5, -0.375, -0.25, 0.5, 0, 0.25}, -- NodeBox8
		}
	}
})

-----
----- darkness_skeleton
-----

mobs:register_mob("testventure:darkness_skeleton", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 35,
	hp_min = 90,
	hp_max = 100,
	armor = 100,
	collisionbox = {-0.35, -1, -0.35, 0.35, 0.75, 0.35},
	visual = "mesh",
	mesh = "testventure_monsterchar.b3d",
	textures = {
		{"testventure_darkness_skeleton.png"},
	},
	blood_texture = "testventure_bone.png",
	makes_footstep_sound = true,
	walk_velocity = 2.50,
	run_velocity = 4.0,
	view_range = 15,
	jump = true,
	floats = 0,
	drops = {
		{name = "testventure:coin_copper", chance = 1, min = 10, max = 85},
		{name = "testventure:coin_silver", chance = 1, min = 3, max = 11},
		{name = "testventure:spawnegg_darkness_skeleton", chance = 200, min = 1, max = 1},
		{name = "testventure:bone", chance = 1, min = 1, max = 3},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
})

minetest.register_craftitem("testventure:spawnegg_darkness_skeleton", {
		description = "" ..core.colorize("#2a00ff","darkness skeleton spawnegg \n")..core.colorize("#ffffff", "Spawns a darkness skeleton."),
	inventory_image = "testventure_spawnegg_darkness_skeleton.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:darkness_skeleton")
			itemstack:take_item()
		end
		return itemstack
	end,
})


-----
----- living_cactus
-----

mobs:register_mob("testventure:living_cactus", {
	type = "monster",
	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	reach = 3,
	damage = 30,
	hp_min = 100,
	hp_max = 140,
	armor = 100,
	collisionbox = {-0.40, -1, -0.40, 0.40, 0.8, 0.40},
	visual = "mesh",
	mesh = "old_character.b3d",
	textures = {
		{"testventure_living_cactus.png"},
	},
	blood_texture = "default_cactus_top.png",
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_sandmonster",
	},
	walk_velocity = 3.0,
	run_velocity = 3.2,
	view_range = 18,
	jump = true,
	floats = 0,
	drops = {
		{name = "default:cactus", chance = 1, min = 1, max = 3},
		{name = "testventure:coin_copper", chance = 1, min = 40, max = 100},
		{name = "testventure:coin_silver", chance = 1, min = 1, max = 8},
		{name = "testventure:spawnegg_living_cactus", chance = 200, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	fear_height = 4,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
})


minetest.register_craftitem("testventure:spawnegg_living_cactus", {
		description = "" ..core.colorize("#2a00ff","Living cactus spawnegg \n")..core.colorize("#ffffff", "Spawns a living_cactus."),
	inventory_image = "testventure_spawnegg_living_cactus.png",
	
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			minetest.env:add_entity(pointed_thing.above, "testventure:living_cactus")
			itemstack:take_item()
		end
		return itemstack
	end,
})


--------critical hits-----------

for _,entity in pairs(minetest.registered_entities) do
	if entity.on_punch ~= nil then
		local EntPunch = entity.on_punch
		entity.on_punch = function(self, hitter,time_from_last_punch, tool_capabilities, direction, pos)
		if self.health ~= nil  then
				if hitter:is_player() then
		local name = hitter:get_player_name()
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	local melee_crit = armor.def[name].melee_crit
		local wpn_crit = tool_capabilities.damage_groups.critical or 3
		if math.random(1, 100) <= wpn_crit + melee_crit then
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
	tool_capabilities.damage_groups.fleshy = tool_capabilities.damage_groups.fleshy * 3
				end
			end
end
			return EntPunch(self, hitter, time_from_last_punch, tool_capabilities, direction)
		end
	end
end

for _,entity in pairs(minetest.registered_entities) do
	if entity.on_punch ~= nil then

		local EntPunch = entity.on_punch

		entity.on_punch = function(self, hitter,time_from_last_punch, tool_capabilities, direction, pos)

			if self.health ~= nil then

				if hitter:is_player() then
		local name = hitter:get_player_name()
		melee_bonus = armor.def[name].melee_dmg + 1
	tool_capabilities.damage_groups.fleshy = tool_capabilities.damage_groups.fleshy * melee_bonus
				end
			end

			return EntPunch(self, hitter, time_from_last_punch, tool_capabilities, direction)
		end
		
	end

end

for _,entity in pairs(minetest.registered_entities) do
	if entity.on_punch ~= nil then
		local EntPunch = entity.on_punch
		entity.on_punch = function(self, hitter,time_from_last_punch, tool_capabilities, direction, pos)

			if self.health ~= nil then

				if hitter:is_player() then
	local tod = minetest.get_timeofday()
	 if tod >= 0.8 or tod <= 0.2  then
		local name = hitter:get_player_name()
	local inv = minetest.get_inventory({type="player", name=hitter:get_player_name()})
		local armor = minetest.get_inventory({type="detached", name = name .. "_armor"})
		if armor then
			local set_part_a = ItemStack("testventure:helmet_shadow")
			local set_part_b = ItemStack("testventure:chestplate_shadow")
			local set_part_c = ItemStack("testventure:leggings_shadow")
			local set_part_d = ItemStack("testventure:boots_shadow")
			local set_part_e = ItemStack("testventure:shield_shadow")
			if armor:contains_item("armor", set_part_a)
			and armor:contains_item("armor", set_part_b)
			and armor:contains_item("armor", set_part_c)
			and armor:contains_item("armor", set_part_d)
			and armor:contains_item("armor", set_part_e)
			then
	tool_capabilities.damage_groups.fleshy = tool_capabilities.damage_groups.fleshy * 1.6
				end
			end
	end
	end
	end
			return EntPunch(self, hitter, time_from_last_punch, tool_capabilities, direction)
		end

	end
end

for _,entity in pairs(minetest.registered_entities) do
	if entity.on_punch ~= nil then
		local EntPunch = entity.on_punch
		entity.on_punch = function(self, hitter,time_from_last_punch, tool_capabilities, direction, pos)
			if self.health ~= nil then
				if hitter:is_player() then

	for playername, has_strenght in pairs(testventure.strenght) do
			if has_strenght then

	tool_capabilities.damage_groups.fleshy = tool_capabilities.damage_groups.fleshy * 1.5
				end
				end
				end
				end

			return EntPunch(self, hitter, time_from_last_punch, tool_capabilities, direction)
		end

	end
end


for _,entity in pairs(minetest.registered_entities) do
	if entity.on_punch ~= nil then
		local EntPunch = entity.on_punch
		entity.on_punch = function(self, hitter,time_from_last_punch, tool_capabilities, direction, pos)
			if self.health ~= nil then
				if hitter:is_player() then

	for playername, has_force in pairs(testventure.force) do
			if has_force then
if tool_capabilities.damage_groups.knockback ~= nil then

	tool_capabilities.damage_groups.knockback = tool_capabilities.damage_groups.knockback * 2.0 
				end

				end
				end
				end
				end

			return EntPunch(self, hitter, time_from_last_punch, tool_capabilities, direction)
		end

	end
end


