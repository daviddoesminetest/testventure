--
--bone
--

minetest.register_craftitem("testventure:bone", {
		description = "".. core.colorize("#00eaff", "Bone\n")..core.colorize("#FFFFFF", "Ranged damage: 9-12\n")..core.colorize("#FFFFFF", "accuracy: 85%\n")..core.colorize("#FFFFFF", "throwable gravitational pull: 7\n")..core.colorize("#FFFFFF", "knockback: 6\n")..core.colorize("#FFFFFF", "Critical chance: 3%\n")..core.colorize("#FFFFFF", "Throwing velocity: 15"),
	range = 0,
	stack_max= 999,
	inventory_image = "testventure_bone.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then

		local meta = user:get_meta()
		local meta_ranged_dmg = meta:get_int("ranged_dmg_meta")
		mrd = (1+(meta_ranged_dmg / 100))

	base_dmg = math.random(9,12)*mrd
	base_crit = 3
	base_kb = 6
		local name = user:get_player_name()
	dmg_bonus = armor.def[name].ranged_dmg + 1
	crit_bonus = armor.def[name].ranged_crit
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:bonethrow")
			if obj then
				obj:setvelocity({x=dir.x * 15, y=dir.y * 15, z=dir.z * 15})
				obj:setacceleration({x=math.random(-1.5,1.5), y=math.random(-5.5,-8.5), z=math.random(-1.5,1.5)})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_bonethrow = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.35, y=0.35},
	textures = {"testventure:bone"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_bonethrow.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.225 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:bonethrow" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or math.random(9,12)
	base_crit = base_crit or 3
	base_kb = base_kb or 6
	dmg_bonus = dmg_bonus or 1
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
if math.random(1, 100) <= 30 then
minetest.add_item(self.lastpos, "testventure:bone")
end
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
if math.random(1, 100) <= 30 then
minetest.add_item(self.lastpos, "testventure:bone")
end
				self.object:remove()
				end
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if self.timer > 0.9 then
if math.random(1, 100) <= 40 then
minetest.add_item(self.lastpos, "testventure:bone")
end
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:bonethrow", testventure_bonethrow)


--
--snowball
--

minetest.register_craftitem("testventure:snowball", {
		description = "".. core.colorize("#00eaff", "Snowball\n")..core.colorize("#FFFFFF", "Ranged damage: 1-2\n")..core.colorize("#FFFFFF", "accuracy: 75%\n")..core.colorize("#FFFFFF", "throwable gravitational pull: 10\n")..core.colorize("#FFFFFF", "knockback: 2\n")..core.colorize("#FFFFFF", "Critical chance: 1%\n")..core.colorize("#FFFFFF", "Throwing velocity: 15"),
	range = 0,
	stack_max= 999,
	inventory_image = "testventure_snowball.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then

		local meta = user:get_meta()
		local meta_ranged_dmg = meta:get_int("ranged_dmg_meta")
		mrd = (1+(meta_ranged_dmg / 100))

	base_dmg = math.random(1,2)*mrd
	base_crit = 1
	base_kb = 2
		local name = user:get_player_name()
	dmg_bonus = armor.def[name].ranged_dmg + 1
	crit_bonus = armor.def[name].ranged_crit
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:snowballthrow")
			if obj then
				obj:setvelocity({x=dir.x * 15, y=dir.y * 15, z=dir.z * 15})
				obj:setacceleration({x=math.random(-2.5,2.5), y=math.random(-7.5,-12.5), z=math.random(-2.5,2.5)})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_snowballthrow = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_snowball.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_snowballthrow.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.225 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:snowballthrow" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or math.random(1,2)
	base_crit = base_crit or 1
	base_kb = base_kb or 2
	dmg_bonus = dmg_bonus or 1
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:snowballthrow", testventure_snowballthrow)



--
--primitive_javelin
--

minetest.register_craftitem("testventure:prim_javelin_throw", {
	wield_scale = {x=1.25,y=1.0,z=1.0},
	inventory_image = "testventure_primitive_javelin.png",
})

minetest.register_craftitem("testventure:primitive_javelin", {
		description = "".. core.colorize("#00eaff", "Primitive javelin\n")..core.colorize("#FFFFFF", "Ranged damage: 13-16\n")..core.colorize("#FFFFFF", "accuracy: 90%\n")..core.colorize("#FFFFFF", "throwable gravitational pull: 7\n")..core.colorize("#FFFFFF", "knockback: 5\n")..core.colorize("#FFFFFF", "Critical chance: 6%\n")..core.colorize("#FFFFFF", "Throwing velocity: 20"),
	range = 0,
	stack_max= 999,
	inventory_image = "testventure_primitive_javelin_inv.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then
		local meta = user:get_meta()
		local meta_ranged_dmg = meta:get_int("ranged_dmg_meta")
		mrd = (1+(meta_ranged_dmg / 100))

	base_dmg = math.random(13,16)*mrd
	base_crit = 6
	base_kb = 5
		local name = user:get_player_name()
	dmg_bonus = armor.def[name].ranged_dmg + 1
	crit_bonus = armor.def[name].ranged_crit
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:primitive_javelinthrow")
			if obj then
				obj:setvelocity({x=dir.x * 20, y=dir.y * 20, z=dir.z * 20})
				obj:setacceleration({x=math.random(-1.0,1.0), y=math.random(-6.0,-8.0), z=math.random(-1.0,1.0)})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_primitive_javelinthrow = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.35, y=0.35},
	textures = {"testventure:prim_javelin_throw"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_primitive_javelinthrow.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.18 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:primitive_javelinthrow" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or math.random(13,16)
	base_crit = base_crit or 6
	base_kb = base_kb or 5
	dmg_bonus = dmg_bonus or 1
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = (base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
if math.random(1, 100) <= 30 then
minetest.add_item(self.lastpos, "testventure:primitive_javelin")
end
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = (base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
if math.random(1, 100) <= 30 then
minetest.add_item(self.lastpos, "testventure:primitive_javelin")
end
				self.object:remove()
				end
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if self.timer > 0.9 then
if math.random(1, 100) <= 40 then
minetest.add_item(self.lastpos, "testventure:primitive_javelin")
end
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:primitive_javelinthrow", testventure_primitive_javelinthrow)


--
--shuriken
--

minetest.register_craftitem("testventure:shuriken", {
		description = "".. core.colorize("#00eaff", "shuriken\n")..core.colorize("#FFFFFF", "Ranged damage: 2-5\n")..core.colorize("#FFFFFF", "accuracy: 95%\n")..core.colorize("#FFFFFF", "throwable gravitational pull: 5\n")..core.colorize("#FFFFFF", "knockback: 1\n") ..core.colorize("#FFFFFF", "Critical chance: 4%\n")..core.colorize("#FFFFFF", "Throwing velocity: 25\n") ..core.colorize("#FFFFFF", "Penetrates targets"),
	range = 0,
	stack_max= 999,
	inventory_image = "testventure_shuriken.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then
		local meta = user:get_meta()
		local meta_ranged_dmg = meta:get_int("ranged_dmg_meta")
		mrd = (1+(meta_ranged_dmg / 100))

	base_dmg = math.random(2,5)*mrd
	base_crit = 4
	base_kb = 1
		local name = user:get_player_name()
	dmg_bonus = armor.def[name].ranged_dmg + 1
	crit_bonus = armor.def[name].ranged_crit
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:shurikenthrow")
			if obj then
				obj:setvelocity({x=dir.x * 25, y=dir.y * 25, z=dir.z * 25})
				obj:setacceleration({x=math.random(-0.5,0.5), y=math.random(-4.5,-5.5), z=math.random(-0.5,0.5)})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_shurikenthrow = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.35, y=0.35},
	textures = {"testventure:shuriken"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_shurikenthrow.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.15 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:shurikenthrow" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or math.random(2,5)
	base_crit = base_crit or 4
	base_kb = base_kb or 1
	dmg_bonus = dmg_bonus or 1
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.timer = 0.08
					else
local damage = (base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})

					self.timer = 0.08
				end
			end
			else
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.timer = 0.08
				else
local damage = (base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.timer = 0.08
				end
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if self.timer > 0.9 then
if math.random(1, 100) <= 40 then
minetest.add_item(self.lastpos, "testventure:shuriken")
end
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:shurikenthrow", testventure_shurikenthrow)

--
--throwing_knife
--

minetest.register_craftitem("testventure:throwing_knife", {
		description = "".. core.colorize("#00eaff", "throwing knife\n")..core.colorize("#FFFFFF", "Ranged damage: 4-6\n")..core.colorize("#FFFFFF", "accuracy: 90%\n")..core.colorize("#FFFFFF", "throwable gravitational pull: 6\n")..core.colorize("#FFFFFF", "knockback: 2\n") ..core.colorize("#FFFFFF", "Critical chance: 4%\n")..core.colorize("#FFFFFF", "Throwing velocity: 20\n") ..core.colorize("#FFFFFF", "Penetrates targets"),
	range = 0,
	stack_max= 999,
	inventory_image = "testventure_throwing_knife.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then
		local meta = user:get_meta()
		local meta_ranged_dmg = meta:get_int("ranged_dmg_meta")
		mrd = (1+(meta_ranged_dmg / 100))

	base_dmg = math.random(4,6)*mrd
	base_crit = 4
	base_kb = 2
		local name = user:get_player_name()
	dmg_bonus = armor.def[name].ranged_dmg + 1
	crit_bonus = armor.def[name].ranged_crit
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:throwing_knifethrow")
			if obj then
				obj:setvelocity({x=dir.x * 20, y=dir.y * 20, z=dir.z * 20})
				obj:setacceleration({x=math.random(-1.0,1.0), y=math.random(-5.0,-7.0), z=math.random(-1.0,1.0)})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_throwing_knifethrow = {
	physical = false,
	timer = 0,
	visual = "wielditem",
	visual_size = {x=0.35, y=0.35},
	textures = {"testventure:throwing_knife"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_throwing_knifethrow.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.175 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:throwing_knifethrow" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or math.random(4,7)
	base_crit = base_crit or 4
	base_kb = base_kb or 2
	dmg_bonus = dmg_bonus or 1
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.timer = 0.06
					else
local damage = (base_dmg)  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})

					self.timer = 0.06
				end
			end
			else
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = (base_dmg) * 3 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.timer = 0.06
				else
local damage = (base_dmg)  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.timer = 0.06
				end
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
if self.timer > 0.9 then
if math.random(1, 100) <= 40 then
minetest.add_item(self.lastpos, "testventure:throwing_knife")
end
	end
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:throwing_knifethrow", testventure_throwing_knifethrow)


--
--grenade
--

minetest.register_craftitem("testventure:grenade", {
		description = "".. core.colorize("#00eaff", "grenade\n")..core.colorize("#FFFFFF", "Explosion damage: 30\n")..core.colorize("#FFFFFF", "throwable gravitational pull: 8\n")..core.colorize("#FFFFFF", "knockback: 20\n") ..core.colorize("#FFFFFF", "Explosion radius: 4\n")   ..core.colorize("#FFFFFF", "Throwing velocity: 12\n")   ..core.colorize("#FFFFFF", "Does not harm nodes"),
	range = 0,
	stack_max= 50,
	inventory_image = "testventure_grenade.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:grenadethrow")
			if obj then
				obj:setvelocity({x=dir.x * 12, y=dir.y * 12, z=dir.z * 12})
				obj:setacceleration({x=0, y=-8, z=0})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_grenadethrow = {
	physical = true,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.6, y=0.6},
	textures = {"testventure_grenade_thr.png"},
	lastpos= {},
	collisionbox = {-0.16, -0.16, -0.16, 0.16, 0.16, 0.16},
}
testventure_grenadethrow.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.4 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1.5)
		for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:grenadethrow" and  
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	for i=1,40 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-8, 8), y=math.random(-8, 8), z=math.random(-6, 6)},
		size = math.random(2, 6), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_spark.png",
		glow = 30,
	})
	end
	for i=1,25 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-8, 8), y=math.random(-8, 8), z=math.random(-6, 6)},
		size = math.random(5, 9), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_smoke.png",
		glow = 3,
	})
	end
		local in_blast = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 4)
for k,blasted in ipairs(in_blast) do
	if blasted:get_luaentity() ~= nil then
	if blasted:get_luaentity().name ~= "testventure:grenadethrow" and blasted:get_luaentity().name ~= "__builtin:item" then
				local damage = 30
				blasted:punch(self.object, 1.0, {
				full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 20},
					}, nil)
					minetest.sound_play("tnt_explode", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			end
			end
			else
				local damage = 30
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				self.object:remove()
						end

			if self.timer >= 3.0 then
		local in_blast = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 4)
for k,blasted in ipairs(in_blast) do
	if blasted:get_luaentity() ~= nil then
	if blasted:get_luaentity().name ~= "testventure:grenadethrow" and blasted:get_luaentity().name ~= "__builtin:item" then
				local damage = 30
				blasted:punch(self.object, 1.0, {
				full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 15},
					}, nil)
					self.object:remove()
				end
			end
			end
minetest.sound_play("tnt_explode", {pos = self.lastpos, gain = 0.8})
	for i=1,40 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-8, 8), y=math.random(-8, 8), z=math.random(-6, 6)},
		size = math.random(2, 6), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_spark.png",
		glow = 30,
	})
	end
	for i=1,25 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-8, 8), y=math.random(-8, 8), z=math.random(-6, 6)},
		size = math.random(5, 9), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_smoke.png",
		glow = 3,
	})
	end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
minetest.register_entity("testventure:grenadethrow", testventure_grenadethrow)

--
--bomb
--

local bomb_explosion = {
	name = "testventure:bomb_explosion",
	--description = "DuN mInD mEh...",
	radius = 3,
	tiles = {
		side = "testventure_invisible.png",
		top = "testventure_invisible.png",
		bottom = "testventure_invisible.png",
		burning = "testventure_invisible.png"
	},
}

minetest.register_craftitem("testventure:bomb", {
		description = "".. core.colorize("#00eaff", "bomb\n")..core.colorize("#FFFFFF", "throwable gravitational pull: 8\n")..core.colorize("#FFFFFF", "Explosion radius: 3\n")   ..core.colorize("#FFFFFF", "Throwing velocity: 12\n")   ..core.colorize("#FFFFFF", "The explosion can destroy nodes"),
	range = 0,
	stack_max= 30,
	inventory_image = "testventure_bomb.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:bombthrow")
			if obj then
				obj:setvelocity({x=dir.x * 12, y=dir.y * 12, z=dir.z * 12})
				obj:setacceleration({x=0, y=-8, z=0})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_bombthrow = {
	physical = true,
	timer = 0,
	hp_max = 1000,
	visual = "sprite",
	visual_size = {x=0.6, y=0.6},
	textures = {"testventure_bomb_thr.png"},
	lastpos= {},
	collisionbox = {-0.2, -0.2, -0.2, 0.2, 0.2, 0.2},
}
testventure_bombthrow.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	local tiem = 0.05
		if self.timer >= 0.05 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = {x=0, y=math.random(3, 5), z=0},
          acceleration = {x=math.random(-2, 2), y=math.random(-2, 2), z=math.random(-2, 2)},
		expirationtime = 1.2,
		size = math.random(2, 5),
		collisiondetection = false,
		vertical = false,
		texture = "testventure_spark.png",
		glow = 30,
	})
		tiem = tiem + 0.2 
			end

	if self.timer >= 3.0 then
	
	for i=1,45 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-9, 9), y=math.random(-9, 9), z=math.random(-7, 7)},
		size = math.random(4, 8), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_spark.png",
		glow = 30,
	})
	end
	for i=1,30 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-9, 9), y=math.random(-9, 9), z=math.random(-7, 7)},
		size = math.random(6, 10), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_smoke.png",
		glow = 3,
	})
	end
		tnt.boom(pos, bomb_explosion)
		self.object:remove()
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
minetest.register_entity("testventure:bombthrow", testventure_bombthrow)

minetest.register_craftitem("testventure:sticky_bomb", {
		description = "".. core.colorize("#00eaff", "Sticky bomb\n")..core.colorize("#FFFFFF", "throwable gravitational pull: 8\n")..core.colorize("#FFFFFF", "Explosion radius: 3\n")   ..core.colorize("#FFFFFF", "Throwing velocity: 10\n")..core.colorize("#FFFFFF", "Sticks to nodes\n")     ..core.colorize("#FFFFFF", "The explosion can destroy nodes"),
	range = 0,
	stack_max= 30,
	inventory_image = "testventure_sticky_bomb.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:sticky_bombthrow")
			if obj then
				obj:setvelocity({x=dir.x * 10, y=dir.y * 10, z=dir.z * 10})
				obj:setacceleration({x=0, y=-8, z=0})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_sticky_bombthrow = {
	physical = false,
	timer = 0,
	hp_max = 1000,
	visual = "sprite",
	visual_size = {x=0.6, y=0.6},
	textures = {"testventure_sticky_bomb_thr.png"},
	lastpos= {},
	collisionbox = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
}
testventure_sticky_bombthrow.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	local tiem = 0.05
		if self.timer >= 0.05 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = {x=0, y=math.random(3, 5), z=0},
          acceleration = {x=math.random(-2, 2), y=math.random(-2, 2), z=math.random(-2, 2)},
		expirationtime = 1.2,
		size = math.random(2, 5),
		collisiondetection = false,
		vertical = false,
		texture = "testventure_spark.png",
		glow = 30,
	})
		tiem = tiem + 0.2 
			end

	if self.timer >= 3.0 then
	
	for i=1,45 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-9, 9), y=math.random(-9, 9), z=math.random(-7, 7)},
		size = math.random(4, 8), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_spark.png",
		glow = 30,
	})
	end
	for i=1,30 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-9, 9), y=math.random(-9, 9), z=math.random(-7, 7)},
		size = math.random(6, 10), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_smoke.png",
		glow = 3,
	})
	end
		tnt.boom(pos, bomb_explosion)
		self.object:remove()
		end
		if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
	self.object:setacceleration({x=0, y=0, z=0})
	self.object:setvelocity({x=0, y=0, z=0})
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
minetest.register_entity("testventure:sticky_bombthrow", testventure_sticky_bombthrow)

--
--dynamite
--

local dynamite_explosion = {
	name = "testventure:dynamite_explosion",
	--description = "DuN mInD mEh...",
	radius = 5,
	tiles = {
		side = "testventure_invisible.png",
		top = "testventure_invisible.png",
		bottom = "testventure_invisible.png",
		burning = "testventure_invisible.png"
	},
}

minetest.register_craftitem("testventure:dynamite", {
		description = "".. core.colorize("#00eaff", "dynamite\n")..core.colorize("#FFFFFF", "throwable gravitational pull: 8\n")..core.colorize("#FFFFFF", "Explosion radius: 5\n")   ..core.colorize("#FFFFFF", "Throwing velocity: 12\n")   ..core.colorize("#FFFFFF", "The explosion can destroy nodes"),
	range = 0,
	stack_max= 10,
	inventory_image = "testventure_dynamite.png",
	on_use = function(itemstack, user, pointed_thing)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item()
		end
		if pointed_thing.type ~= "nothing" then
			local pointed = minetest.get_pointed_thing_position(pointed_thing)
			if vector.distance(user:getpos(), pointed) < 8 then
				return itemstack
			end
		end
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir then
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:dynamitethrow")
			if obj then
				obj:setvelocity({x=dir.x * 12, y=dir.y * 12, z=dir.z * 12})
				obj:setacceleration({x=0, y=-8, z=0})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or user
				end
			end
		end
		return itemstack
	end,
})

local testventure_dynamitethrow = {
	physical = true,
	timer = 0,
	hp_max = 1000,
	visual = "sprite",
	visual_size = {x=0.6, y=0.6},
	textures = {"testventure_dynamite_thr.png"},
	lastpos= {},
	collisionbox = {-0.22, -0.22, -0.22, 0.22, 0.22, 0.22},
}
testventure_dynamitethrow.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)
	local tiem = 0.05
		if self.timer >= 0.05 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = {x=0, y=math.random(3, 5), z=0},
          acceleration = {x=math.random(-2, 2), y=math.random(-2, 2), z=math.random(-2, 2)},
		expirationtime = 1.2,
		size = math.random(4, 10),
		collisiondetection = false,
		vertical = false,
		texture = "testventure_spark.png",
		glow = 30,
	})
		tiem = tiem + 0.2 
			end

	if self.timer >= 5.0 then
	
	for i=1,50 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-10, 10), y=math.random(-10, 10), z=math.random(-9, 9)},
		size = math.random(6, 12), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_spark.png",
		glow = 30,
	})
	end
	for i=1,40 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          	acceleration = {x=math.random(-10, 10), y=math.random(-9, 9), z=math.random(-9, 9)},
		size = math.random(8, 14), 
		expirationtime = 1.0,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_smoke.png",
		glow = 3,
	})
	end
		tnt.boom(pos, dynamite_explosion)
		self.object:remove()
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
minetest.register_entity("testventure:dynamitethrow", testventure_dynamitethrow)
