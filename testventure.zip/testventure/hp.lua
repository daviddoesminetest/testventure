

minetest.register_on_joinplayer(function(player)
 meta = player:get_meta()
 max_extra_hp = meta:get_int("max_extra_hp") or 0
if max_extra_hp > 80 then
 extra_hp_max = 
	player:hud_add({
	hud_elem_type = "statbar",
	name = "extra_hp_max",
	text = "testventure_silver_heart_bg.png",
	number = 80,
	scale = {x = 100, y = 20},
	position = {x = 0.3, y = 0.67},
	offset = {x = 30, y = 100},
	alignment = {x = 0, y = -1}
	})
else
 extra_hp_max = 
	player:hud_add({
	hud_elem_type = "statbar",
	name = "extra_hp_max",
	text = "testventure_silver_heart_bg.png",
	number = max_extra_hp + 0,
	scale = {x = 100, y = 20},
	position = {x = 0.3, y = 0.67},
	offset = {x = 30, y = 100},
	alignment = {x = 0, y = -1}
	})
end
extra_hp = meta:get_int("extra_hp") or 0
if extra_hp > 80 then
 the_hp = 
	player:hud_add({
	hud_elem_type = "statbar",
	name = "the_hp",
	text = "testventure_silver_heart.png",
	number = 80,
	scale = {x = 100, y = 20},
	position = {x = 0.3, y = 0.67},
	offset = {x = 30, y = 100},
	alignment = {x = 0, y = -1}
	})
else
 the_hp = 
	player:hud_add({
	hud_elem_type = "statbar",
	name = "the_hp",
	text = "testventure_silver_heart.png",
	number = extra_hp,
	scale = {x = 100, y = 20},
	position = {x = 0.3, y = 0.67},
	offset = {x = 30, y = 100},
	alignment = {x = 0, y = -1}
	})
end
player_crystal_hp = meta:get_int("extra_hp - 80") or 0
 crystal_hp = 
	player:hud_add({
	hud_elem_type = "statbar",
	name = "crystal_hp",
	text = "testventure_crystal_heart.png",
	number = player_crystal_hp,
	scale = {x = 100, y = 20},
	position = {x = 0.3, y = 0.67},
	offset = {x = 30, y = 100},
	alignment = {x = 0, y = -1}
	})
 heal_cdown = 
	player:hud_add({
	hud_elem_type = "image",
	text = "testventure_invisible.png",
	scale = {x = 1.5, y = 1.5},
	position = {x = 0.775, y = 0.1},
	offset = {x = 30, y = 100},
	alignment = {x = 0, y = -1}
	})
 cdown_text = 
	player:hud_add({
	hud_elem_type = "text",
	name = "",
	text = "",
	number = 0xFFFFFF,
	scale = {x = 100, y = 20},
	position = {x = 0.775, y = 0.125},
	offset = {x = 30, y = 100},
	alignment = {x = 0, y = -1}
	})
 grav = 
	player:hud_add({
	hud_elem_type = "image",
	text = "testventure_invisible.png",
	scale = {x = 1.5, y = 1.5},
	position = {x = 0.5, y = 0.7},
	offset = {x = 30, y = 100},
	alignment = {x = 0, y = -1}
	})
end)

local hctimer = 0
minetest.register_globalstep(function(dtime, player)
	hctimer = hctimer + dtime;
	if hctimer >= 1.0 then
	for _, player in pairs(minetest.get_connected_players()) do
		hctimer = 0
 meta = player:get_meta()
 heal_cooldown = meta:get_int("heal_cooldown") or 0
		if heal_cooldown > 0 then
		meta:set_int("heal_cooldown", heal_cooldown - 1)
		player:hud_change(heal_cdown, "text","testventure_noheal.png")
		player:hud_change(cdown_text, "text", heal_cooldown)
end
		if heal_cooldown == 0 then
		player:hud_change(cdown_text, "text", "")
		player:hud_change(heal_cdown, "text","testventure_invisible.png")
end
end
end
	end)


minetest.register_node("testventure:silver_heart", {
		description = "" ..core.colorize("#00eaff","Silver heart\n") ..core.colorize("#FFFFFF", "Consuming this, permanenently grants you a silver heart, to work as 2 extra HP points.\n") ..core.colorize("#FFFFFF", "The limit is 40 silver hearts [80 bonus HP]"),
	range = 4,
	stack_max= 20,
	drawtype = "mesh",
	mesh = "testventure_silver_heart.obj",
	tiles = {"testventure_silver_heart_texture.png"},
	inventory_image = "testventure_silver_heart_inv.png",
	paramtype = "light",
	sunlight_propagates = true,
	light_source = 10,
	sounds = default.node_sound_glass_defaults(),
	paramtype2 = "facedir",
	on_place = minetest.rotate_node,
	groups = {cracky = 2},

	on_use = function(itemstack, user, pointed_thing)
 meta = user:get_meta()
 max_extra_hp = meta:get_int("max_extra_hp") or 0
 extra_hp = meta:get_int("extra_hp") or 0
	if max_extra_hp < 80 then
 itemstack:take_item()
meta:set_int("max_extra_hp", max_extra_hp + 2)
meta:set_int("extra_hp", extra_hp + 1)

 max_extra_hp = meta:get_int("max_extra_hp") or 0
 extra_hp = meta:get_int("extra_hp") or 0
	user:hud_change(extra_hp_max, "number", max_extra_hp)
	user:hud_change(the_hp, "number", extra_hp)
end
		return itemstack
	end, true
})

minetest.register_craftitem("testventure:crystal_heart", {
		description = "" ..core.colorize("#00eaff","Crystal heart\n") ..core.colorize("#FFFFFF", "Consuming this, permanenently grants you a crystal heart, to work as 2 extra HP points.\n") ..core.colorize("#FFFFFF", "Only usable if you've maxed out on silver hearts\n")..core.colorize("#FFFFFF", "The limit is 40 crystal hearts [80 bonus HP]"),
	range = 4,
	stack_max= 20,
	drawtype = "mesh",
	inventory_image = "testventure_crystal_heart_inv.png",
	sounds = default.node_sound_glass_defaults(),
	on_use = function(itemstack, user, pointed_thing)
 meta = user:get_meta()
 max_extra_hp = meta:get_int("max_extra_hp") or 0
 extra_hp = meta:get_int("extra_hp") or 0
	if max_extra_hp >= 80 then
	if max_extra_hp < 160 then
 itemstack:take_item()
meta:set_int("max_extra_hp", max_extra_hp + 2)
meta:set_int("extra_hp", extra_hp + 1)

 end end
		return itemstack
	end, true
})

minetest.register_on_player_hpchange(function(player, hp_change)
		if hp_change <= -1 then
		for playername, has_invincibility in pairs(testventure.invincibility) do
			if has_invincibility then
	local player = player:get_player_name()
	if player and hp_change < -1 then
			hp_change = 0
	end
	end
	end
		for playername, has_ironskin in pairs(testventure.ironskin) do
			if has_ironskin then
	local player = player:get_player_name()
	if player and hp_change < -1 then
				hp_change = hp_change + 2
			if hp_change >= 0 then
				hp_change = -1

	end
	end
	end
	end
 meta = player:get_meta()
 extra_hp = meta:get_int("extra_hp") or 0
		if extra_hp ~= nil then
		if  hp_change >= (-1 * extra_hp) then
		minetest.sound_play("player_damage", {player})
meta:set_int("extra_hp", extra_hp + hp_change)
 extra_hp = meta:get_int("extra_hp") or 0
		if extra_hp < 80 then
		player:hud_change(the_hp, "number", extra_hp)
		end
player:hud_change(crystal_hp, "number", extra_hp - 80)
			hp_change = 0
else
 	extra_hp = meta:get_int("extra_hp") or 0
		hp_change = hp_change + extra_hp
		meta:set_int("extra_hp", 0)
		player:hud_change(the_hp, "number", 0)
		player:hud_change(crystal_hp, "number", 0)
end
end
end
	return hp_change
	end, true)

minetest.register_on_player_hpchange(function(player, hp_change)
		if hp_change <= 1 then
		health = player:get_hp()  
 meta = player:get_meta()
 max_extra_hp = meta:get_int("max_extra_hp") or 0
 extra_hp = meta:get_int("extra_hp") or 0
		if extra_hp ~= nil then
		if max_extra_hp~= nil then
			if extra_hp < 80 then
			player:hud_change(the_hp, "number", extra_hp)
			end 
else
 max_extra_hp = meta:get_int("max_extra_hp") or 0
	     meta:set_int("extra_hp", max_extra_hp)
 extra_hp = meta:get_int("extra_hp") or 0
			if extra_hp < 80 then
			player:hud_change(the_hp, "number", extra_hp)			end
	player:hud_change(crystal_hp, "number", extra_hp - 80)
end
end
end
	return hp_change
	end, true)


local timer = 0
minetest.register_globalstep(function(dtime, player)
	timer = timer + dtime;
	if timer >= 0.20 then
	for _, player in pairs(minetest.get_connected_players()) do
meta = player:get_meta()

extra_hp = meta:get_int("extra_hp") or 0
player:hud_change(crystal_hp, "number", extra_hp - 80)
if extra_hp < 80 then
player:hud_change(the_hp, "number", extra_hp)
end

if extra_hp >= 80 then
player:hud_change(the_hp, "number", 80)
end

 regen_power = meta:get_int("regen_amount") or 0
	if regen_power >= 10 then
 regen_power = meta:get_int("regen_amount") or 0
meta:set_int("regen_amount", regen_power - 10)
		timer = 0
		heal = player:get_hp() 
		if heal > 0 then
		heal = heal+1
		player:set_hp(tonumber(heal))
end
		if heal > 19 then
 meta = player:get_meta()
 max_extra_hp = meta:get_int("max_extra_hp") or 0
 extra_hp = meta:get_int("extra_hp") or 0
		if extra_hp < max_extra_hp then
		meta:set_int("extra_hp", extra_hp + 1)
end
end
end
end
end
	end)

minetest.register_craftitem("testventure:health_potion_small", {
		description = "" ..core.colorize("#00eaff","Small health potion\n") ..core.colorize("#FFFFFF", "Restores 10hp, with capability of restoring special hearts"),
	stack_max= 25,
	inventory_image = "testventure_health_potion_small.png",
on_use = function(itemstack, user, pointed_thing)
		 meta = user:get_meta()
		 heal_cooldown = meta:get_int("heal_cooldown") or 0
	mshield = user:get_attribute("shield_max") or 0
	extra_hp = meta:get_int("extra_hp") or 0
	max_extra_hp = meta:get_int("max_extra_hp") or 0
	if heal_cooldown < 1 then
 itemstack:take_item()
	meta:set_int("heal_cooldown", 25)
		health = user:get_hp() 
		restoration = health+10
		user:set_hp(tonumber(restoration))
if restoration > 20 then
	crystal = restoration - 20
local finalhp = extra_hp + crystal
if finalhp > max_extra_hp then
finalhp = max_extra_hp
end
	meta:set_int("extra_hp", finalhp)
	user:set_attribute("shield", finalhp)
	extra_hp = meta:get_int("extra_hp") or 0
	user:hud_change(the_hp, "number", extra_hp)
end
end
		return itemstack
	end, true
})

minetest.register_craftitem("testventure:health_potion", {
		description = "" ..core.colorize("#00eaff","Health potion\n") ..core.colorize("#FFFFFF", "Restores 20hp, with capability of restoring special hearts"),
	stack_max= 25,
	inventory_image = "testventure_health_potion.png",
on_use = function(itemstack, user, pointed_thing)
		 meta = user:get_meta()
		 heal_cooldown = meta:get_int("heal_cooldown") or 0
	mshield = user:get_attribute("shield_max") or 0
	extra_hp = meta:get_int("extra_hp") or 0
	max_extra_hp = meta:get_int("max_extra_hp") or 0
	if heal_cooldown < 1 then
 itemstack:take_item()
	meta:set_int("heal_cooldown", 25)
		health = user:get_hp() 
		restoration = health+20
		user:set_hp(tonumber(restoration))
if restoration > 20 then
	crystal = restoration - 20
local finalhp = extra_hp + crystal
if finalhp > max_extra_hp then
finalhp = max_extra_hp
end
	meta:set_int("extra_hp", finalhp)
	user:set_attribute("shield", finalhp)
	extra_hp = meta:get_int("extra_hp") or 0
	user:hud_change(the_hp, "number", extra_hp)
end
end
		return itemstack
	end, true
})

minetest.register_craftitem("testventure:health_potion_large", {
		description = "" ..core.colorize("#00eaff","Large health potion\n") ..core.colorize("#FFFFFF", "Restores 50hp, with capability of restoring special hearts"),
	stack_max= 25,
	inventory_image = "testventure_health_potion_large.png",
on_use = function(itemstack, user, pointed_thing)
		 meta = user:get_meta()
		 heal_cooldown = meta:get_int("heal_cooldown") or 0
	mshield = user:get_attribute("shield_max") or 0
	extra_hp = meta:get_int("extra_hp") or 0
	max_extra_hp = meta:get_int("max_extra_hp") or 0
	if heal_cooldown < 1 then
 itemstack:take_item()
	meta:set_int("heal_cooldown", 25)
		health = user:get_hp() 
		restoration = health+50
		user:set_hp(tonumber(restoration))
if restoration > 20 then
	crystal = restoration - 20
local finalhp = extra_hp + crystal
if finalhp > max_extra_hp then
finalhp = max_extra_hp
end
	meta:set_int("extra_hp", finalhp)
	user:set_attribute("shield", finalhp)
end
end
		return itemstack
	end, true
})