---
--- glowshroom
---

minetest.register_craftitem("testventure:glowshroom", {
		description = "".. core.colorize("#00eaff", "glowshroom\n")..core.colorize("#FFFFFF", "Restores 8hp, with capability of restoring special hearts"),
	inventory_image = "testventure_glowshroom.png",
	stack_max= 999,
on_use = function(itemstack, user, pointed_thing)
		healc = user:get_attribute("healcool") or 0
		heal_cd = tonumber(healc)
	mshield = user:get_attribute("shield_max") or 0
	cshield = user:get_attribute("shield") or 0
	nshield = tonumber(cshield)
	shieldnum = tonumber(mshield)
	if nshield  <= shieldnum and heal_cd < 1 then
 itemstack:take_item()
	user:set_attribute("healcool", 25)
		health = user:get_hp() 
		restoration = health+8
		user:set_hp(tonumber(restoration))
if restoration > 20 then
	silver = restoration - 20
local finalhp = nshield + silver
if finalhp > shieldnum then
finalhp = shieldnum
end
	user:set_attribute("shield", finalhp)
	local sh = user:get_attribute("shield") or 0
	user:hud_change(shl, "number", sh)
end
end
		return itemstack
	end, true
})

minetest.register_node("testventure:glowshroom_plant", {
		description = "".. core.colorize("#00eaff", "glowshroom plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_glowshroom_plant.png"},
	inventory_image = "testventure_glowshroom_plant.png",
	wield_image = "testventure_glowshroom_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	light_source = 10,
drop = {
		max_items = 2,
		items = {
{items = {'testventure:glowshroom_grass_seeds'},rarity = 20,},
{items = {'testventure:glowshroom'},rarity = 2,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})


minetest.register_abm({
	nodenames = {"testventure:mycelium_mud"},
	interval = 19,
	chance = 1337,
	action = function(pos, node)
		pos.y = pos.y+1
		if minetest.get_node(pos).name == "air" then
			node.name = "testventure:glowshroom_plant"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_abm({
	nodenames = {"testventure:mycelium_stone"},
	interval = 25,
	chance = 20000,
	action = function(pos, node)
		pos.y = pos.y+1
		if minetest.get_node(pos).name == "air" then
			node.name = "testventure:glowshroom_plant"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_abm({
	nodenames = {"testventure:glowshroom_plant"},
	interval = 20,
	chance = 36,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:glowshroom_plant" then
			node.name = "air"
			minetest.set_node(pos, node)
		end
	end
})

---
--- bloodbloom
---

minetest.register_craftitem("testventure:bloodbloom", {
		description = "".. core.colorize("#00eaff", "bloodbloom\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_bloodbloom.png",
	stack_max= 999,
})

minetest.register_node("testventure:bloodbloom_seeds", {
		description = "".. core.colorize("#00eaff", "bloodbloom seeds\n")..core.colorize("#FFFFFF", "Plant them on grassy darkened dirt to grow a bloodbloom"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_bloodbloom_grow_1.png"},
	inventory_image = "testventure_bloodbloom_seeds.png",
	wield_image = "testventure_bloodbloom_seeds.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:bloodbloom_seeds'},rarity = 2,}
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:bloodbloom_grow_2", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_bloodbloom_grow_2.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:bloodbloom_seeds'},rarity = 2,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		}
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:bloodbloom_grow_3", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_bloodbloom_grow_3.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:bloodbloom_seeds'},rarity = 2,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:bloodbloom_done", {
		description = "".. core.colorize("#00eaff", "bloodbloom plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_bloodbloom_plant.png"},
	inventory_image = "testventure_bloodbloom_plant.png",
	wield_image = "testventure_bloodbloom_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:bloodbloom_seeds'},rarity = 2,},
{items = {'testventure:bloodbloom_seeds'},rarity = 3,},
{items = {'testventure:bloodbloom_seeds'},rarity = 4,},
{items = {'testventure:bloodbloom_seeds'},rarity = 5,},
{items = {'testventure:bloodbloom'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_abm({
	nodenames = {"testventure:bloodbloom_seeds"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y-1
		if minetest.get_node(pos).name == "testventure:grassy_dark_dirt" then
		pos.y = pos.y+1
			node.name = "testventure:bloodbloom_grow_2"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:bloodbloom_grow_2"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:bloodbloom_grow_2" then
			node.name = "testventure:bloodbloom_grow_3"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:bloodbloom_grow_3"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:bloodbloom_grow_3" then
			node.name = "testventure:bloodbloom_done"
			minetest.set_node(pos, node)
		end
	end
})





minetest.register_node("testventure:bloodbloom_plant", {
		description = "".. core.colorize("#00eaff", "Bloodbloom\n")..core.colorize("#FFFFFF", "A placable block, which spreads the darklands"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_bloodbloom_plant.png"},
	inventory_image = "testventure_bloodbloom_plant.png",
	wield_image = "testventure_bloodbloom_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:bloodbloom_seeds'},rarity = 2,},
{items = {'testventure:bloodbloom_seeds'},rarity = 3,},
{items = {'testventure:bloodbloom_seeds'},rarity = 4,},
{items = {'testventure:bloodbloom_seeds'},rarity = 5,},
{items = {'testventure:bloodbloom'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1, spreads_darkness = 1, not_in_creative_inventory=1},
	sounds = default.node_sound_leaves_defaults(),
})


---
--- rockweed
---



minetest.register_craftitem("testventure:rockweed", {
		description = "".. core.colorize("#00eaff", "Rockweed\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_rockweed.png",
	stack_max= 999,
})

minetest.register_node("testventure:rockweed_seeds", {
		description = "".. core.colorize("#00eaff", "rockweed seeds\n")..core.colorize("#FFFFFF", "Plant them on stone to grow a rockweed"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_rockweed_grow_1.png"},
	inventory_image = "testventure_rockweed_seeds.png",
	wield_image = "testventure_rockweed_seeds.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:rockweed_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:rockweed_grow_2", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_rockweed_grow_2.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:rockweed_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:rockweed_grow_3", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_rockweed_grow_3.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:rockweed_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:rockweed_done", {
		description = "".. core.colorize("#00eaff", "rockweed plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_rockweed_plant.png"},
	inventory_image = "testventure_rockweed_plant.png",
	wield_image = "testventure_rockweed_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:rockweed_seeds'},rarity = 2,},
{items = {'testventure:rockweed_seeds'},rarity = 3,},
{items = {'testventure:rockweed_seeds'},rarity = 4,},
{items = {'testventure:rockweed_seeds'},rarity = 5,},
{items = {'testventure:rockweed'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_abm({
	nodenames = {"testventure:rockweed_seeds"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y-1
		if minetest.get_node(pos).name == "default:stone" then
		pos.y = pos.y+1
			node.name = "testventure:rockweed_grow_2"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:rockweed_grow_2"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:rockweed_grow_2" then
			node.name = "testventure:rockweed_grow_3"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:rockweed_grow_3"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:rockweed_grow_3" then
			node.name = "testventure:rockweed_done"
			minetest.set_node(pos, node)
		end
	end
})


minetest.register_node("testventure:rockweed_plant", {
		description = "".. core.colorize("#00eaff", "Rockweed plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_rockweed_plant.png"},
	inventory_image = "testventure_rockweed_plant.png",
	wield_image = "testventure_rockweed_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:rockweed_seeds'},rarity = 2,},
{items = {'testventure:rockweed_seeds'},rarity = 3,},
{items = {'testventure:rockweed_seeds'},rarity = 4,},
{items = {'testventure:rockweed_seeds'},rarity = 5,},
{items = {'testventure:rockweed'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.4, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})


minetest.register_abm({
	nodenames = {"default:stone"},
	interval = 10,
	chance = 42000,
	action = function(pos, node)
		pos.y = pos.y+1
		if minetest.get_node(pos).name == "air" then
			node.name = "testventure:rockweed_plant"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_abm({
	nodenames = {"testventure:rockweed_plant"},
	interval = 15,
	chance = 30,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:rockweed_plant" then
			node.name = "air"
			minetest.set_node(pos, node)
		end
	end
})

---
--- sandshine
---

minetest.register_node("testventure:sandshine_seeds", {
		description = "".. core.colorize("#00eaff", "sandshine seeds\n")..core.colorize("#FFFFFF", "Plant them on desert sand to grow a sandshine"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sandshine_grow_1.png"},
	inventory_image = "testventure_sandshine_seeds.png",
	wield_image = "testventure_sandshine_seeds.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:sandshine_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:sandshine_grow_2", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sandshine_grow_2.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:sandshine_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:sandshine_grow_3", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sandshine_grow_3.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:sandshine_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:sandshine_done", {
		description = "".. core.colorize("#00eaff", "sandshine plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sandshine_plant.png"},
	inventory_image = "testventure_sandshine_plant.png",
	wield_image = "testventure_sandshine_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:sandshine_seeds'},rarity = 2,},
{items = {'testventure:sandshine_seeds'},rarity = 3,},
{items = {'testventure:sandshine_seeds'},rarity = 4,},
{items = {'testventure:sandshine_seeds'},rarity = 5,},
{items = {'testventure:sandshine'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_abm({
	nodenames = {"testventure:sandshine_seeds"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y-1
		if minetest.get_node(pos).name == "default:desert_sand" then
		pos.y = pos.y+1
			node.name = "testventure:sandshine_grow_2"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:sandshine_grow_2"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:sandshine_grow_2" then
			node.name = "testventure:sandshine_grow_3"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:sandshine_grow_3"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:sandshine_grow_3" then
			node.name = "testventure:sandshine_done"
			minetest.set_node(pos, node)
		end
	end
})


minetest.register_craftitem("testventure:sandshine", {
		description = "".. core.colorize("#00eaff", "sandshine\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_sandshine.png",
	stack_max= 999,
})

minetest.register_node("testventure:sandshine_plant", {
		description = "".. core.colorize("#00eaff", "sandshine plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sandshine_plant.png"},
	inventory_image = "testventure_sandshine_plant.png",
	wield_image = "testventure_sandshine_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:sandshine_seeds'},rarity = 2,},
{items = {'testventure:sandshine_seeds'},rarity = 3,},
{items = {'testventure:sandshine_seeds'},rarity = 4,},
{items = {'testventure:sandshine_seeds'},rarity = 5,},
{items = {'testventure:sandshine'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.4, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})


minetest.register_abm({
	nodenames = {"default:desert_sand"},
	interval = 10,
	chance = 90000,
	action = function(pos, node)
		pos.y = pos.y+1
		if minetest.get_node(pos).name == "air" then
			node.name = "testventure:sandshine_plant"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_abm({
	nodenames = {"testventure:sandshine_plant"},
	interval = 15,
	chance = 25,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:sandshine_plant" then
			node.name = "air"
			minetest.set_node(pos, node)
		end
	end
})

---
--- frostonica
---


minetest.register_node("testventure:frostonica_seeds", {
		description = "".. core.colorize("#00eaff", "frostonica seeds\n")..core.colorize("#FFFFFF", "Plant them on a block of snow to grow a frostonica"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_frostonica_grow_1.png"},
	inventory_image = "testventure_frostonica_seeds.png",
	wield_image = "testventure_frostonica_seeds.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:frostonica_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:frostonica_grow_2", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_frostonica_grow_2.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:frostonica_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:frostonica_grow_3", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_frostonica_grow_3.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:frostonica_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:frostonica_done", {
		description = "".. core.colorize("#00eaff", "frostonica plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_frostonica_plant.png"},
	inventory_image = "testventure_frostonica_plant.png",
	wield_image = "testventure_frostonica_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:frostonica_seeds'},rarity = 2,},
{items = {'testventure:frostonica_seeds'},rarity = 3,},
{items = {'testventure:frostonica_seeds'},rarity = 4,},
{items = {'testventure:frostonica_seeds'},rarity = 5,},
{items = {'testventure:frostonica'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_abm({
	nodenames = {"testventure:frostonica_seeds"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y-1
		if minetest.get_node(pos).name == "default:snowblock" then
		pos.y = pos.y+1
			node.name = "testventure:frostonica_grow_2"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:frostonica_grow_2"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:frostonica_grow_2" then
			node.name = "testventure:frostonica_grow_3"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:frostonica_grow_3"},
	interval = 35,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:frostonica_grow_3" then
			node.name = "testventure:frostonica_done"
			minetest.set_node(pos, node)
		end
	end
})



minetest.register_craftitem("testventure:frostonica", {
		description = "".. core.colorize("#00eaff", "frostonica\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_frostonica.png",
	stack_max= 999,
})

minetest.register_node("testventure:frostonica_plant", {
		description = "".. core.colorize("#00eaff", "frostonica plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_frostonica_plant.png"},
	inventory_image = "testventure_frostonica_plant.png",
	wield_image = "testventure_frostonica_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	light_source = 5,
	walkable = false,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:frostonica_seeds'},rarity = 2,},
{items = {'testventure:frostonica_seeds'},rarity = 3,},
{items = {'testventure:frostonica_seeds'},rarity = 4,},
{items = {'testventure:frostonica_seeds'},rarity = 5,},
{items = {'testventure:frostonica'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.4, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})


minetest.register_abm({
	nodenames = {"default:snowblock","default:dirt_with_snow","default:ice"},
	interval = 10,
	chance = 90000,
	action = function(pos, node)
		pos.y = pos.y+1
		if minetest.get_node(pos).name == "air" then
			node.name = "testventure:frostonica_plant"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_abm({
	nodenames = {"testventure:frostonica_plant"},
	interval = 15,
	chance = 25,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:frostonica_plant" then
			node.name = "air"
			minetest.set_node(pos, node)
		end
	end
})



---
--- shroom
---

minetest.register_craftitem("testventure:shroom", {
		description = "".. core.colorize("#00eaff", "shroom\n")..core.colorize("#FFFFFF", "Restores 4hp, with capability of restoring special hearts"),
	inventory_image = "testventure_shroom.png",
	stack_max= 999,
on_use = function(itemstack, user, pointed_thing)
		healc = user:get_attribute("healcool") or 0
		heal_cd = tonumber(healc)
	mshield = user:get_attribute("shield_max") or 0
	cshield = user:get_attribute("shield") or 0
	nshield = tonumber(cshield)
	shieldnum = tonumber(mshield)
	if nshield  <= shieldnum and heal_cd < 1 then
 itemstack:take_item()
	user:set_attribute("healcool", 25)
		health = user:get_hp() 
		restoration = health+4
		user:set_hp(tonumber(restoration))
if restoration > 20 then
	silver = restoration - 20
local finalhp = nshield + silver
if finalhp > shieldnum then
finalhp = shieldnum
end
	user:set_attribute("shield", finalhp)
	local sh = user:get_attribute("shield") or 0
	user:hud_change(shl, "number", sh)
end
end
		return itemstack
	end, true
})

minetest.register_node("testventure:shroom_plant", {
		description = "".. core.colorize("#00eaff", "shroom plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_shroom_plant.png"},
	inventory_image = "testventure_shroom_plant.png",
	wield_image = "testventure_shroom_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	drop = "testventure:shroom 1",
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})


minetest.register_abm({
	nodenames = {"default:dirt_with_grass"},
	interval = 10,
	chance = 90000,
	action = function(pos, node)
		pos.y = pos.y+1
		if minetest.get_node(pos).name == "air" then
			node.name = "testventure:shroom_plant"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_abm({
	nodenames = {"testventure:shroom_plant"},
	interval = 15,
	chance = 25,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:shroom_plant" then
			node.name = "air"
			minetest.set_node(pos, node)
		end
	end
})


---
--- sunglow
---

minetest.register_craftitem("testventure:sunglow", {
		description = "".. core.colorize("#00eaff", "sunglow\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_sunglow.png",
	stack_max= 999,
})


minetest.register_node("testventure:sunglow_seeds", {
		description = "".. core.colorize("#00eaff", "Sunglow seeds\n")..core.colorize("#FFFFFF", "Plant them on grassy dirt to grow a sunglow"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sunglow_grow_1.png"},
	inventory_image = "testventure_sunglow_seeds.png",
	wield_image = "testventure_sunglow_seeds.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 1,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:sunglow_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:sunglow_grow_2", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sunglow_grow_2.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 1,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:sunglow_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:sunglow_grow_3", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sunglow_grow_3.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 1,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:sunglow_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:sunglow_done", {
		description = "".. core.colorize("#00eaff", "sunglow plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sunglow_plant.png"},
	inventory_image = "testventure_sunglow_plant.png",
	wield_image = "testventure_sunglow_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 8,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:sunglow_seeds'},rarity = 2,},
{items = {'testventure:sunglow_seeds'},rarity = 3,},
{items = {'testventure:sunglow_seeds'},rarity = 4,},
{items = {'testventure:sunglow_seeds'},rarity = 5,},
{items = {'testventure:sunglow'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_abm({
	nodenames = {"testventure:sunglow_plant"},
	interval = 15,
	chance = 25,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:sunglow_plant" then
			node.name = "air"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_abm({
	nodenames = {"testventure:sunglow_seeds"},
	interval = 25,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y-1
		if minetest.get_node(pos).name == "default:dirt_with_grass" then
		pos.y = pos.y+1
			node.name = "testventure:sunglow_grow_2"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:sunglow_grow_2"},
	interval = 25,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:sunglow_grow_2" then
			node.name = "testventure:sunglow_grow_3"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:sunglow_grow_3"},
	interval = 25,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:sunglow_grow_3" then
			node.name = "testventure:sunglow_done"
			minetest.set_node(pos, node)
		end
	end
})


minetest.register_node("testventure:sunglow_plant", {
		description = "".. core.colorize("#00eaff", "sunglow plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_sunglow_plant.png"},
	inventory_image = "testventure_sunglow_plant.png",
	wield_image = "testventure_sunglow_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 8,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:sunglow_seeds'},rarity = 2,},
{items = {'testventure:sunglow_seeds'},rarity = 3,},
{items = {'testventure:sunglow_seeds'},rarity = 4,},
{items = {'testventure:sunglow_seeds'},rarity = 5,},
{items = {'testventure:sunglow'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})


minetest.register_abm({
	nodenames = {"default:dirt_with_grass"},
	interval = 10,
	chance = 90000,
	action = function(pos, node)
		pos.y = pos.y+1
		if minetest.get_node(pos).name == "air" then
			node.name = "testventure:sunglow_plant"
			minetest.set_node(pos, node)
		end
	end
})

---
--- magical_rose
---

minetest.register_craftitem("testventure:magical_rose", {
		description = "".. core.colorize("#00eaff", "Magical rose\n")..core.colorize("#FFFFFF", "Crafting material"),
	inventory_image = "testventure_magical_rose.png",
	stack_max= 999,
})


minetest.register_node("testventure:magical_rose_seeds", {
		description = "".. core.colorize("#00eaff", "Magical rose seeds\n")..core.colorize("#FFFFFF", "Plant them on mud with jungle grass, to grow a magical rose"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_magical_rose_grow_1.png"},
	inventory_image = "testventure_magical_rose_seeds.png",
	wield_image = "testventure_magical_rose_seeds.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 1,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:magical_rose_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:magical_rose_grow_2", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_magical_rose_grow_2.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 1,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:magical_rose_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:magical_rose_grow_3", {
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_magical_rose_grow_3.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 1,
	buildable_to = true,
drop = {
		max_items = 1,
		items = {
{items = {'testventure:magical_rose_seeds'},rarity = 2,},
	}
},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_node("testventure:magical_rose_done", {
		description = "".. core.colorize("#00eaff", "Magical rose plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_magical_rose_plant.png"},
	inventory_image = "testventure_magical_rose_plant.png",
	wield_image = "testventure_magical_rose_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 8,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:magical_rose_seeds'},rarity = 2,},
{items = {'testventure:magical_rose_seeds'},rarity = 3,},
{items = {'testventure:magical_rose_seeds'},rarity = 4,},
{items = {'testventure:magical_rose_seeds'},rarity = 5,},
{items = {'testventure:magical_rose'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})
minetest.register_abm({
	nodenames = {"testventure:magical_rose_plant"},
	interval = 15,
	chance = 25,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:magical_rose_plant" then
			node.name = "air"
			minetest.set_node(pos, node)
		end
	end
})

minetest.register_abm({
	nodenames = {"testventure:magical_rose_seeds"},
	interval = 25,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y-1
		if minetest.get_node(pos).name == "testventure:jungle_mud" then
		pos.y = pos.y+1
			node.name = "testventure:magical_rose_grow_2"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:magical_rose_grow_2"},
	interval = 25,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:magical_rose_grow_2" then
			node.name = "testventure:magical_rose_grow_3"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:magical_rose_grow_3"},
	interval = 25,
	chance = 3,
	action = function(pos, node)
		pos.y = pos.y+0
		if minetest.get_node(pos).name == "testventure:magical_rose_grow_3" then
			node.name = "testventure:magical_rose_done"
			minetest.set_node(pos, node)
		end
	end
})


minetest.register_node("testventure:magical_rose_plant", {
		description = "".. core.colorize("#00eaff", "Magical rose plant\n")..core.colorize("#FFFFFF", "a plant"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.0,
	stack_max= 999,
	tiles = {"testventure_magical_rose_plant.png"},
	inventory_image = "testventure_magical_rose_plant.png",
	wield_image = "testventure_magical_rose_plant.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 9,
	buildable_to = true,
drop = {
		max_items = 5,
		items = {
{items = {'testventure:magical_rose_seeds'},rarity = 2,},
{items = {'testventure:magical_rose_seeds'},rarity = 3,},
{items = {'testventure:magical_rose_seeds'},rarity = 4,},
{items = {'testventure:magical_rose_seeds'},rarity = 5,},
{items = {'testventure:magical_rose'},rarity = 1,},
		}
	},
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1,not_in_creative_inventory=1},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.5, -0.25, 0.25, 0.0, 0.25},
		},
	},
	sounds = default.node_sound_leaves_defaults(),
})


minetest.register_abm({
	nodenames = {"testventure:jungle_mud"},
	interval = 10,
	chance = 36000,
	action = function(pos, node)
		pos.y = pos.y+1
		if minetest.get_node(pos).name == "air" then
			node.name = "testventure:magical_rose_plant"
			minetest.set_node(pos, node)
		end
	end
})



