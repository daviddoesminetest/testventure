minetest.override_item("3d_armor:helmet_diamond", {
		description = ("Diamond Helmet"),
		inventory_image = "3d_armor_inv_helmet_diamond.png",
		groups = {armor_head=1, armor_heal=10, armor_use=200},
		armor_groups = {fleshy=13},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
minetest.override_item("3d_armor:chestplate_diamond", {
		description = ("Diamond Chestplate"),
		inventory_image = "3d_armor_inv_chestplate_diamond.png",
		groups = {armor_torso=1, armor_heal=10, armor_use=200},
		armor_groups = {fleshy=18},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
minetest.override_item("3d_armor:leggings_diamond", {
		description = ("Diamond Leggings"),
		inventory_image = "3d_armor_inv_leggings_diamond.png",
		groups = {armor_legs=1, armor_heal=10, armor_use=200},
		armor_groups = {fleshy=18},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
minetest.override_item("3d_armor:boots_diamond", {
		description = ("Diamond Boots"),
		inventory_image = "3d_armor_inv_boots_diamond.png",
		groups = {armor_feet=1, armor_heal=10, armor_use=200},
		armor_groups = {fleshy=13},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

minetest.override_item("shields:shield_diamond", {
		description = ("Diamond Shield"),
		inventory_image = "shields_inv_shield_diamond.png",
		groups = {armor_shield=1, armor_heal=10, armor_use=200},
		armor_groups = {fleshy=13},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
---
--- darkwood
---

armor:register_armor("testventure:helmet_darkwood", {
			description = "".. core.colorize("#00eaff", "darkwood helmet\n")..core.colorize("#FFFFFF", "Protection level: 8\n") ..core.colorize("#FFFFFF", "Heal chance: 2.0"),
		inventory_image = "testventure_inv_helmet_darkwood.png",
		groups = {armor_head=1, armor_heal=2.0, armor_use=500},
		armor_groups = {fleshy=8},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_darkwood", {
			description = "".. core.colorize("#00eaff", "darkwood chestplate\n")..core.colorize("#FFFFFF", "Protection level: 13\n") ..core.colorize("#FFFFFF", "Heal chance: 2.0"),
		inventory_image = "testventure_inv_chestplate_darkwood.png",
		groups = {armor_torso=1, armor_heal=2.0, armor_use=500},
		armor_groups = {fleshy=13},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_darkwood", {
			description = "".. core.colorize("#00eaff", "darkwood leggings\n")..core.colorize("#FFFFFF", "Protection level: 13\n") ..core.colorize("#FFFFFF", "Heal chance: 2.0"),
		inventory_image = "testventure_inv_leggings_darkwood.png",
		groups = {armor_legs=1, armor_heal=2.0, armor_use=500},
		armor_groups = {fleshy=13},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_darkwood", {
			description = "".. core.colorize("#00eaff", "darkwood boots\n")..core.colorize("#FFFFFF", "Protection level: 8\n") ..core.colorize("#FFFFFF", "Heal chance: 2.0"),
		inventory_image = "testventure_inv_boots_darkwood.png",
		groups = {armor_feet=1, armor_heal=2.0, armor_use=500},
		armor_groups = {fleshy=8},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_darkwood", {
			description = "".. core.colorize("#00eaff", "darkwood shield\n")..core.colorize("#FFFFFF", "Protection level: 8\n") ..core.colorize("#FFFFFF", "Heal chance: 2.0"),
		inventory_image = "testventure_inv_shield_darkwood.png",
		groups = {armor_shield=1, armor_heal=2.0, armor_use=500},
		armor_groups = {fleshy=8},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

---
--- skywood
---

armor:register_armor("testventure:helmet_skywood", {
			description = "".. core.colorize("#00eaff", "skywood helmet\n")..core.colorize("#FFFFFF", "Protection level: 11\n")..core.colorize("#FFFFFF", "Walking speed bonus: 4%\n")  ..core.colorize("#FFFFFF", "Heal chance: 4.0"),
		inventory_image = "testventure_inv_helmet_skywood.png",
		groups = {armor_head=1, physics_speed=0.04, armor_heal=4.0, armor_use=300},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_skywood", {
			description = "".. core.colorize("#00eaff", "skywood chestplate\n")..core.colorize("#FFFFFF", "Protection level: 16\n")..core.colorize("#FFFFFF", "Walking speed bonus: 4%\n")  ..core.colorize("#FFFFFF", "Heal chance: 4.0"),
		inventory_image = "testventure_inv_chestplate_skywood.png",
		groups = {armor_torso=1, physics_speed=0.04, armor_heal=4.0, armor_use=300},
		armor_groups = {fleshy=16},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_skywood", {
			description = "".. core.colorize("#00eaff", "skywood leggings\n")..core.colorize("#FFFFFF", "Protection level: 16\n")..core.colorize("#FFFFFF", "Walking speed bonus: 4%\n")  ..core.colorize("#FFFFFF", "Heal chance: 4.0"),
		inventory_image = "testventure_inv_leggings_skywood.png",
		groups = {armor_legs=1, physics_speed=0.04, armor_heal=4.0, armor_use=300},
		armor_groups = {fleshy=16},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_skywood", {
			description = "".. core.colorize("#00eaff", "skywood boots\n")..core.colorize("#FFFFFF", "Protection level: 11\n")..core.colorize("#FFFFFF", "Walking speed bonus: 4%\n")  ..core.colorize("#FFFFFF", "Heal chance: 4.0"),
		inventory_image = "testventure_inv_boots_skywood.png",
		groups = {armor_feet=1, physics_speed=0.04, armor_heal=4.0, armor_use=300},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_skywood", {
			description = "".. core.colorize("#00eaff", "skywood shield\n")..core.colorize("#FFFFFF", "Protection level: 11\n") ..core.colorize("#FFFFFF", "Walking speed bonus: 4%\n")  ..core.colorize("#FFFFFF", "Heal chance: 4.0"),
		inventory_image = "testventure_inv_shield_skywood.png",
		groups = {armor_shield=1, physics_speed=0.04, armor_heal=4.0, armor_use=300},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})


---
--- aqua
---

armor:register_armor("testventure:helmet_aqua", {
			description = "".. core.colorize("#00eaff", "Aqua helmet\n")..core.colorize("#FFFFFF", "Protection level: 14\n") ..core.colorize("#FFFFFF", "Heal chance: 10.3\n")..core.colorize("#FFFFFF", "Set bonus: Reduces suffocation."),
		inventory_image = "testventure_inv_helmet_aqua.png",
		groups = {armor_head=1, armor_heal=10.3, armor_use=150},
		armor_groups = {fleshy=14},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_aqua", {
			description = "".. core.colorize("#00eaff", "Aqua chestplate\n")..core.colorize("#FFFFFF", "Protection level: 19\n") ..core.colorize("#FFFFFF", "Heal chance: 10.3\n")..core.colorize("#FFFFFF", "Set bonus: Reduces suffocation."),
		inventory_image = "testventure_inv_chestplate_aqua.png",
		groups = {armor_torso=1, armor_heal=10.3, armor_use=150},
		armor_groups = {fleshy=19},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_aqua", {
			description = "".. core.colorize("#00eaff", "Aqua leggings\n")..core.colorize("#FFFFFF", "Protection level: 19\n") ..core.colorize("#FFFFFF", "Heal chance: 10.3\n")..core.colorize("#FFFFFF", "Set bonus: Reduces suffocation."),
		inventory_image = "testventure_inv_leggings_aqua.png",
		groups = {armor_legs=1, armor_heal=10.3, armor_use=150},
		armor_groups = {fleshy=19},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_aqua", {
			description = "".. core.colorize("#00eaff", "Aqua boots\n")..core.colorize("#FFFFFF", "Protection level: 14\n") ..core.colorize("#FFFFFF", "Heal chance: 10.3\n")..core.colorize("#FFFFFF", "Set bonus: Reduces suffocation."),
		inventory_image = "testventure_inv_boots_aqua.png",
		groups = {armor_feet=1, armor_heal=10.3, armor_use=150},
		armor_groups = {fleshy=14},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_aqua", {
			description = "".. core.colorize("#00eaff", "Aqua shield\n")..core.colorize("#FFFFFF", "Protection level: 14\n") ..core.colorize("#FFFFFF", "Heal chance: 10.3\n")..core.colorize("#FFFFFF", "Set bonus: Reduces suffocation."),
		inventory_image = "testventure_inv_shield_aqua.png",
		groups = {armor_shield=1, armor_heal=10.3, armor_use=150},
		armor_groups = {fleshy=14},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

---
--- crimson
---

armor:register_armor("testventure:helmet_crimson", {
			description = "".. core.colorize("#00eaff", "crimson helmet\n")..core.colorize("#FFFFFF", "Protection level: 14.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n") ..core.colorize("#FFFFFF", "Melee damage bonus: 6%\n") ..core.colorize("#FFFFFF", "Set bonus: regenerates 0.7HP every second."),
		inventory_image = "testventure_inv_helmet_crimson.png",
		groups = {armor_melee_dmg=0.06, armor_head=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=14.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_crimson", {
			description = "".. core.colorize("#00eaff", "crimson chestplate\n")..core.colorize("#FFFFFF", "Protection level: 19.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Melee damage bonus: 9%\n")..core.colorize("#FFFFFF", "Set bonus: regenerates 0.7HP every second."),
		inventory_image = "testventure_inv_chestplate_crimson.png",
		groups = {armor_melee_dmg=0.09, armor_torso=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=19.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_crimson", {
			description = "".. core.colorize("#00eaff", "crimson leggings\n")..core.colorize("#FFFFFF", "Protection level: 19.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Melee damage bonus: 5%\n")..core.colorize("#FFFFFF", "Set bonus: regenerates 0.7HP every second."),
		inventory_image = "testventure_inv_leggings_crimson.png",
		groups = {armor_melee_dmg=0.05, armor_legs=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=19.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_crimson", {
			description = "".. core.colorize("#00eaff", "crimson boots\n")..core.colorize("#FFFFFF", "Protection level: 14.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Melee damage bonus: 5%\n")..core.colorize("#FFFFFF", "Set bonus: regenerates 0.7HP every second."),
		inventory_image = "testventure_inv_boots_crimson.png",
		groups = {armor_melee_dmg=0.05,armor_feet=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=14.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_crimson", {
			description = "".. core.colorize("#00eaff", "crimson shield\n")..core.colorize("#FFFFFF", "Protection level: 14.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Melee damage bonus: 10%\n")..core.colorize("#FFFFFF", "Set bonus: regenerates 0.7HP every second."),
		inventory_image = "testventure_inv_shield_crimson.png",
		groups = {armor_melee_dmg=0.1, armor_shield=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=14.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

---
--- shadow
---

armor:register_armor("testventure:helmet_shadow", {
			description = "".. core.colorize("#00eaff", "shadow helmet\n")..core.colorize("#FFFFFF", "Protection level: 14.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n") ..core.colorize("#FFFFFF", "Walking speed bonus: 14%\n") ..core.colorize("#FFFFFF", "Set bonus: mele damage increased by 60% during night."),
		inventory_image = "testventure_inv_helmet_shadow.png",
		groups = {physics_speed=0.14, armor_head=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=14.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_shadow", {
			description = "".. core.colorize("#00eaff", "shadow chestplate\n")..core.colorize("#FFFFFF", "Protection level: 19.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Walking speed bonus: 12%\n")..core.colorize("#FFFFFF", "Set bonus: mele damage increased by 60% during night."),
		inventory_image = "testventure_inv_chestplate_shadow.png",
		groups = {physics_speed=0.12, armor_torso=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=19.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_shadow", {
			description = "".. core.colorize("#00eaff", "shadow leggings\n")..core.colorize("#FFFFFF", "Protection level: 19.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Walking speed bonus: 18%\n")..core.colorize("#FFFFFF", "Set bonus: mele damage increased by 60% during night."),
		inventory_image = "testventure_inv_leggings_shadow.png",
		groups = {physics_speed=0.18, armor_legs=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=19.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_shadow", {
			description = "".. core.colorize("#00eaff", "shadow boots\n")..core.colorize("#FFFFFF", "Protection level: 14.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Walking speed bonus: 21%\n")..core.colorize("#FFFFFF", "Set bonus: mele damage increased by 60% during night."),
		inventory_image = "testventure_inv_boots_shadow.png",
		groups = {physics_speed=0.21,armor_feet=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=14.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_shadow", {
			description = "".. core.colorize("#00eaff", "shadow shield\n")..core.colorize("#FFFFFF", "Protection level: 14.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Walking speed bonus: 11% \n")..core.colorize("#FFFFFF", "Set bonus: mele damage increased by 60% during night."),
		inventory_image = "testventure_inv_shield_shadow.png",
		groups = {physics_speed=0.11, armor_shield=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=14.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

---
--- smaranium
---

armor:register_armor("testventure:helmet_smaranium", {
			description = "".. core.colorize("#00eaff", "smaranium helmet\n")..core.colorize("#FFFFFF", "Protection level: 14.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4"),
		inventory_image = "testventure_inv_helmet_smaranium.png",
		groups = {physics_speed=0.0, armor_head=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=14.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_smaranium", {
			description = "".. core.colorize("#00eaff", "smaranium chestplate\n")..core.colorize("#FFFFFF", "Protection level: 19.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4"),
		inventory_image = "testventure_inv_chestplate_smaranium.png",
		groups = {physics_speed=0.0, armor_torso=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=19.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_smaranium", {
			description = "".. core.colorize("#00eaff", "smaranium leggings\n")..core.colorize("#FFFFFF", "Protection level: 19.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4"),
		inventory_image = "testventure_inv_leggings_smaranium.png",
		groups = {physics_speed=0.0, armor_legs=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=19.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_smaranium", {
			description = "".. core.colorize("#00eaff", "smaranium boots\n")..core.colorize("#FFFFFF", "Protection level: 14.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Walking speed bonus: 13%"),
		inventory_image = "testventure_inv_boots_smaranium.png",
		groups = {physics_speed=0.0,armor_feet=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=14.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_smaranium", {
			description = "".. core.colorize("#00eaff", "smaranium shield\n")..core.colorize("#FFFFFF", "Protection level: 14.4\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4"),
		inventory_image = "testventure_inv_shield_smaranium.png",
		groups = {physics_speed=0.0, armor_shield=1, armor_heal=10.4, armor_use=100},
		armor_groups = {fleshy=14.4},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

---
--- black_silver
---

armor:register_armor("testventure:helmet_black_silver", {
			description = "".. core.colorize("#00eaff", "black silver helmet\n")..core.colorize("#FFFFFF", "Protection level: 14.7\n")..core.colorize("#FFFFFF", "Speed bonus: 7%\n")..core.colorize("#FFFFFF", "Ranged damage bonus: 9%\n")..core.colorize("#FFFFFF", "melee damage bonus: 3%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.55"),
		inventory_image = "testventure_inv_helmet_black_silver.png",
		groups = {physics_speed=0.07,armor_ranged_dmg=0.09,armor_melee_dmg=0.03, armor_head=1, armor_heal=10.5, armor_use=50},
		armor_groups = {fleshy=14.7},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_black_silver", {
			description = "".. core.colorize("#00eaff", "black silver chestplate\n")..core.colorize("#FFFFFF", "Protection level: 19.7\n")..core.colorize("#FFFFFF", "Speed bonus: 7%\n")..core.colorize("#FFFFFF", "Ranged damage bonus: 8%\n")..core.colorize("#FFFFFF", "melee damage bonus: 5%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.55"),
		inventory_image = "testventure_inv_chestplate_black_silver.png",
		groups = {physics_speed=0.07,armor_ranged_dmg=0.08,armor_melee_dmg=0.05, armor_torso=1, armor_heal=10.55, armor_use=50},
		armor_groups = {fleshy=19.7},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_black_silver", {
			description = "".. core.colorize("#00eaff", "black silver leggings\n")..core.colorize("#FFFFFF", "Protection level: 19.7\n")..core.colorize("#FFFFFF", "Speed bonus: 16%\n")..core.colorize("#FFFFFF", "Ranged damage bonus: 4%\n")..core.colorize("#FFFFFF", "melee damage bonus: 3%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.55"),
		inventory_image = "testventure_inv_leggings_black_silver.png",
		groups = {physics_speed=0.16,armor_ranged_dmg=0.04,armor_melee_dmg=0.03, armor_legs=1, armor_heal=10.55, armor_use=50},
		armor_groups = {fleshy=19.7},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_black_silver", {
			description = "".. core.colorize("#00eaff", "black silver boots\n")..core.colorize("#FFFFFF", "Protection level: 14.7\n")..core.colorize("#FFFFFF", "Speed bonus: 18%\n")..core.colorize("#FFFFFF", "Ranged damage bonus: 3%\n")..core.colorize("#FFFFFF", "melee damage bonus: 2%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.55"),
		inventory_image = "testventure_inv_boots_black_silver.png",
		groups = {physics_speed=0.18,armor_ranged_dmg=0.03,armor_melee_dmg=0.02,armor_feet=1, armor_heal=10.55, armor_use=50},
		armor_groups = {fleshy=14.7},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_black_silver", {
			description = "".. core.colorize("#00eaff", "black silver shield\n")..core.colorize("#FFFFFF", "Protection level: 14.7\n") ..core.colorize("#FFFFFF", "Speed bonus: 6%\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 9%\n") ..core.colorize("#FFFFFF", "melee damage bonus: 8%\n")   ..core.colorize("#FFFFFF", "Heal chance: 10.55"),
		inventory_image = "testventure_inv_shield_black_silver.png",
		groups = {physics_speed=0.06,armor_ranged_dmg=0.09,armor_melee_dmg=0.08, armor_shield=1, armor_heal=10.55, armor_use=50},
		armor_groups = {fleshy=14.7},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

---
--- heavenly
---

armor:register_armor("testventure:helmet_heavenly", {
			description = "".. core.colorize("#00eaff", "heavenly helmet\n")..core.colorize("#FFFFFF", "Protection level: 14.5\n") ..core.colorize("#FFFFFF", "Speed bonus: 10%\n") ..core.colorize("#FFFFFF", "Gravity reduction: 10%\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 10%\n")..core.colorize("#FFFFFF", "melee damage bonus: 10%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.5\n") ..core.colorize("#FFFFFF", "regenerates 1MP every second\n") ..core.colorize("#FFFFFF", "Set bonus: regenerates 10MP every second."),
		inventory_image = "testventure_inv_helmet_heavenly.png",
		groups = {physics_speed=0.1,physics_gravity=-0.1,armor_ranged_dmg=0.1,armor_melee_dmg=0.10, armor_head=1, armor_heal=10.5, armor_use=50, armor_mana_regen = 1},
		armor_groups = {fleshy=14.5},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_heavenly", {
			description = "".. core.colorize("#00eaff", "heavenly chestplate\n")..core.colorize("#FFFFFF", "Protection level: 19.5\n")..core.colorize("#FFFFFF", "Speed bonus: 10%\n")..core.colorize("#FFFFFF", "Gravity reduction: 10%\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 9%\n")..core.colorize("#FFFFFF", "melee damage bonus: 10%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.5\n") ..core.colorize("#FFFFFF", "regenerates 1MP every second\n") ..core.colorize("#FFFFFF", "Set bonus: regenerates 10MP every second."),
		inventory_image = "testventure_inv_chestplate_heavenly.png",
		groups = {physics_speed=0.1,physics_gravity=-0.1,armor_ranged_dmg=0.09,armor_melee_dmg=0.1, armor_torso=1, armor_heal=10.5, armor_use=50, armor_mana_regen = 1},
		armor_groups = {fleshy=19.5},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_heavenly", {
			description = "".. core.colorize("#00eaff", "heavenly leggings\n")..core.colorize("#FFFFFF", "Protection level: 19.5\n")..core.colorize("#FFFFFF", "Speed bonus: 19%\n")..core.colorize("#FFFFFF", "Gravity reduction: 10%\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 5%\n")..core.colorize("#FFFFFF", "melee damage bonus: 8%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.5\n") ..core.colorize("#FFFFFF", "regenerates 1MP every second\n") ..core.colorize("#FFFFFF", "Set bonus: regenerates 10MP every second."),
		inventory_image = "testventure_inv_leggings_heavenly.png",
		groups = {physics_speed=0.19,physics_gravity=-0.1,armor_ranged_dmg=0.05,armor_melee_dmg=0.08, armor_legs=1, armor_heal=10.5, armor_use=50, armor_mana_regen = 1},
		armor_groups = {fleshy=19.5},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_heavenly", {
			description = "".. core.colorize("#00eaff", "heavenly boots\n")..core.colorize("#FFFFFF", "Protection level: 14.5\n")..core.colorize("#FFFFFF", "Speed bonus: 21%\n")..core.colorize("#FFFFFF", "Gravity reduction: 10%\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 4%\n")..core.colorize("#FFFFFF", "melee damage bonus: 7%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.5\n") ..core.colorize("#FFFFFF", "regenerates 1MP every second\n")  ..core.colorize("#FFFFFF", "Set bonus: regenerates 10MP every second."),
		inventory_image = "testventure_inv_boots_heavenly.png",
		groups = {physics_speed=0.21,physics_gravity=-0.1,armor_ranged_dmg=0.04,armor_melee_dmg=0.07,armor_feet=1, armor_heal=10.5, armor_use=50, armor_mana_regen = 1},
		armor_groups = {fleshy=14.5},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_heavenly", {
			description = "".. core.colorize("#00eaff", "heavenly shield\n")..core.colorize("#FFFFFF", "Protection level: 14.5\n") ..core.colorize("#FFFFFF", "Speed bonus: 9%\n")..core.colorize("#FFFFFF", "Gravity reduction: 10%\n")  ..core.colorize("#FFFFFF", "Ranged damage bonus: 10%\n") ..core.colorize("#FFFFFF", "melee damage bonus: 13%\n")   ..core.colorize("#FFFFFF", "Heal chance: 10.5\n") ..core.colorize("#FFFFFF", "regenerates 1MP every second\n")  ..core.colorize("#FFFFFF", "Set bonus: regenerates 10MP every second."),
		inventory_image = "testventure_inv_shield_heavenly.png",
		groups = {physics_speed=0.09, physics_gravity=-0.1, armor_ranged_dmg=0.10,armor_melee_dmg=0.13, armor_shield=1, armor_heal=10.5, armor_use=50, armor_mana_regen = 1},
		armor_groups = {fleshy=14.5},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})


---
--- niobium
---

armor:register_armor("testventure:helmet_niobium", {
			description = "".. core.colorize("#2a00ff", "Niobium helmet\n")..core.colorize("#FFFFFF", "Protection level: 15\n")..core.colorize("#FFFFFF", "Speed bonus: 6%\n")..core.colorize("#FFFFFF", "Bonus to all damges: 8%\n") ..core.colorize("#FFFFFF", "Bonus to all crits: 1%\n") ..core.colorize("#FFFFFF", "Ammo & mana saving: 3%\n") ..core.colorize("#FFFFFF", "regenerates 2MP every second\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.75"),
		inventory_image = "testventure_inv_helmet_niobium.png",
		groups = {physics_speed=0.06,armor_ranged_dmg=0.08,armor_melee_dmg=0.08,armor_magic_dmg=0.08, armor_head=1, armor_heal=10.75,armor_ranged_crit=1,armor_melee_crit=1,armor_magic_crit=1,armor_ammo_save=3,armor_mana_save=0.03, armor_use=50, armor_mana_regen = 2},
		armor_groups = {fleshy=15},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_niobium", {
			description = "".. core.colorize("#2a00ff", "Niobium chestplate\n")..core.colorize("#FFFFFF", "Protection level: 20\n")..core.colorize("#FFFFFF", "Speed bonus: 6%\n")..core.colorize("#FFFFFF", "Bonus to all damges: 6%\n")..core.colorize("#FFFFFF", "Bonus to all crits: 1%\n")..core.colorize("#FFFFFF", "Ammo & mana saving: 3%\n") ..core.colorize("#FFFFFF", "regenerates 2MP every second\n")     ..core.colorize("#FFFFFF", "Heal chance: 10.75"),
		inventory_image = "testventure_inv_chestplate_niobium.png",
		groups = {physics_speed=0.06,armor_ranged_dmg=0.06,armor_melee_dmg=0.06,armor_magic_dmg=0.06, armor_torso=1, armor_heal=10.75,armor_ranged_crit=1,armor_magic_crit=1,armor_melee_crit=1,armor_ammo_save=3,armor_mana_save=0.03, armor_use=50, armor_mana_regen = 2},
		armor_groups = {fleshy=20},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_niobium", {
			description = "".. core.colorize("#2a00ff", "Niobium leggings\n")..core.colorize("#FFFFFF", "Protection level: 20\n")..core.colorize("#FFFFFF", "Speed bonus: 15%\n")..core.colorize("#FFFFFF", "Bonus to all damges: 3%\n")..core.colorize("#FFFFFF", "Bonus to all crits: 1%\n")..core.colorize("#FFFFFF", "Ammo & mana saving: 3%\n") ..core.colorize("#FFFFFF", "regenerates 2MP every second\n")     ..core.colorize("#FFFFFF", "Heal chance: 10.75"),
		inventory_image = "testventure_inv_leggings_niobium.png",
		groups = {physics_speed=0.15,armor_ranged_dmg=0.03,armor_melee_dmg=0.03,armor_magic_dmg=0.03, armor_legs=1, armor_heal=10.75,armor_ranged_crit=1,armor_melee_crit=1,armor_magic_crit=1,armor_ammo_save=3,armor_mana_save=0.03, armor_use=50, armor_mana_regen = 2},
		armor_groups = {fleshy=20},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_niobium", {
			description = "".. core.colorize("#2a00ff", "Niobium boots\n")..core.colorize("#FFFFFF", "Protection level: 15\n")..core.colorize("#FFFFFF", "Speed bonus: 17%\n")..core.colorize("#FFFFFF", "Bonus to all damges: 3%\n")..core.colorize("#FFFFFF", "Bonus to all crits: 1%\n")..core.colorize("#FFFFFF", "Ammo & mana saving: 3%\n") ..core.colorize("#FFFFFF", "regenerates 2MP every second\n")     ..core.colorize("#FFFFFF", "Heal chance: 10.75"),
		inventory_image = "testventure_inv_boots_niobium.png",
		groups = {physics_speed=0.17,armor_ranged_dmg=0.03,armor_melee_dmg=0.03,armor_magic_dmg=0.03,armor_feet=1, armor_heal=10.75,armor_ranged_crit=1,armor_melee_crit=1,armor_magic_crit=1,armor_ammo_save=3,armor_mana_save=0.03, armor_use=50, armor_mana_regen = 2},
		armor_groups = {fleshy=15},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_niobium", {
			description = "".. core.colorize("#2a00ff", "Niobium shield\n")..core.colorize("#FFFFFF", "Protection level: 15\n") ..core.colorize("#FFFFFF", "Speed bonus: 5%\n") ..core.colorize("#FFFFFF", "Bonus to all damges: 7%\n") ..core.colorize("#FFFFFF", "Bonus to all crits: 1%\n")..core.colorize("#FFFFFF", "Ammo & mana saving: 3%\n") ..core.colorize("#FFFFFF", "regenerates 2MP every second\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.75"),
		inventory_image = "testventure_inv_shield_niobium.png",
		groups = {physics_speed=0.05,armor_ranged_dmg=0.07,armor_melee_dmg=0.07,armor_magic_dmg=0.07, armor_shield=1, armor_heal=10.75,armor_ranged_crit=1,armor_melee_crit=1,armor_magic_crit=1,armor_ammo_save=3,armor_mana_save=0.03, armor_use=50, armor_mana_regen = 2},
		armor_groups = {fleshy=15},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})


---
--- amber
---

armor:register_armor("testventure:helmet_amber", {
			description = "".. core.colorize("#00eaff", "amber helmet\n")..core.colorize("#FFFFFF", "Protection level: 12\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n") ..core.colorize("#FFFFFF", "Melee damage bonus: 10%\n")..core.colorize("#FFFFFF", "Speed bonus: 10%\n")  ..core.colorize("#FFFFFF", "Set bonus: regenerates 1HP every second."),
		inventory_image = "testventure_inv_helmet_amber.png",
		groups = {physics_speed=0.1, armor_melee_dmg=0.10, armor_head=1, armor_heal=12.8, armor_use=200},
		armor_groups = {fleshy=12},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_amber", {
			description = "".. core.colorize("#00eaff", "amber chestplate\n")..core.colorize("#FFFFFF", "Protection level: 16\n") ..core.colorize("#FFFFFF", "Heal chance: 12.8\n")..core.colorize("#FFFFFF", "Melee damage bonus: 14%\n")..core.colorize("#FFFFFF", "Speed bonus: 9%\n") ..core.colorize("#FFFFFF", "Set bonus: regenerates 1HP every second."),
		inventory_image = "testventure_inv_chestplate_amber.png",
		groups = {physics_speed=0.09, armor_melee_dmg=0.14, armor_torso=1, armor_heal=12.8, armor_use=200},
		armor_groups = {fleshy=16},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_amber", {
			description = "".. core.colorize("#00eaff", "amber leggings\n")..core.colorize("#FFFFFF", "Protection level: 11\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Melee damage bonus: 9%\n")..core.colorize("#FFFFFF", "Speed bonus: 17%\n") ..core.colorize("#FFFFFF", "Set bonus: regenerates 1HP every second."),
		inventory_image = "testventure_inv_leggings_amber.png",
		groups = {physics_speed=0.17, armor_melee_dmg=0.09, armor_legs=1, armor_heal=12.8, armor_use=200},
		armor_groups = {fleshy=11},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_amber", {
			description = "".. core.colorize("#00eaff", "amber boots\n")..core.colorize("#FFFFFF", "Protection level: 9\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Melee damage bonus: 8%\n")..core.colorize("#FFFFFF", "Speed bonus: 18%\n") ..core.colorize("#FFFFFF", "Set bonus: regenerates 1HP every second."),
		inventory_image = "testventure_inv_boots_amber.png",
		groups = {physics_speed=0.18, armor_melee_dmg=0.08,armor_feet=1, armor_heal=12.8, armor_use=200},
		armor_groups = {fleshy=9},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_amber", {
			description = "".. core.colorize("#00eaff", "amber shield\n")..core.colorize("#FFFFFF", "Protection level: 12\n") ..core.colorize("#FFFFFF", "Heal chance: 10.4\n")..core.colorize("#FFFFFF", "Melee damage bonus: 15%\n")..core.colorize("#FFFFFF", "Speed bonus: 8% \n") ..core.colorize("#FFFFFF", "Set bonus: regenerates 1HP every second."),
		inventory_image = "testventure_inv_shield_amber.png",
		groups = {physics_speed=0.08, armor_melee_dmg=0.15, armor_shield=1, armor_heal=12.8, armor_use=200},
		armor_groups = {fleshy=12},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

---
--- specials/accessories
---


armor:register_armor("testventure:boots_slime", {
			description = "".. core.colorize("#00eaff", "Slime boots\n")..core.colorize("#FFFFFF", "Protection level: 9\n") ..core.colorize("#FFFFFF", "Heal chance: 6\n")..core.colorize("#FFFFFF", "Jump bonus: 100%\n")..core.colorize("#FFFFFF", "Gravity reduction: 21%"),
		inventory_image = "testventure_inv_boots_slime.png",
		groups = {physics_gravity=-0.21,physics_jump=1.0,armor_feet=1, armor_heal=6, armor_use=0},
		armor_groups = {fleshy=9.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:boots_mobility", {
			description = "".. core.colorize("#00eaff", "Boots of mobility\n")..core.colorize("#FFFFFF", "Protection level: 11\n") ..core.colorize("#FFFFFF", "Heal chance: 7\n") ..core.colorize("#FFFFFF", "Jump bonus: 100%\n") ..core.colorize("#FFFFFF", "Speed bonus: 100%\n")  ..core.colorize("#FFFFFF", "Gravity reduction: 20%"),
		inventory_image = "testventure_inv_boots_mobility.png",
		groups = {physics_gravity=-0.20,physics_speed=1.0,physics_jump=1.0,armor_feet=1, armor_heal=7, armor_use=0},
		armor_groups = {fleshy=11.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:boots_speed", {
			description = "".. core.colorize("#00eaff", "Speedy boots\n")..core.colorize("#FFFFFF", "Protection level: 6\n") ..core.colorize("#FFFFFF", "Heal chance: 4\n")..core.colorize("#FFFFFF", "Speed bonus: 100%"),
		inventory_image = "testventure_inv_boots_speed.png",
		groups = {physics_speed=1.0,armor_feet=1, armor_heal=4, armor_use=0},
		armor_groups = {fleshy=6.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:sunglasses", {
			description = "".. core.colorize("#00eaff", "Sunglasses\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 15%\n") ..core.colorize("#FFFFFF", "Heal chance: 10\n") ..core.colorize("#FFFFFF", "Protection level: 12\n")..core.colorize("#FFFFFF", "Coolness: 100%"),
		inventory_image = "testventure_sunglasses_inv.png",
		groups = {armor_ranged_dmg=0.15,armor_head=1, armor_heal=10, armor_use=0},
		armor_groups = {fleshy=12.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:goggles", {
			description = "".. core.colorize("#00eaff", "Goggles\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 5%\n")..core.colorize("#FFFFFF", "Heal chance: 4\n") ..core.colorize("#FFFFFF", "Protection level: 8"),
		inventory_image = "testventure_goggles_inv.png",
		groups = {armor_ranged_dmg=0.05,armor_head=1, armor_heal=4, armor_use=0},
		armor_groups = {fleshy=8.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:bloody_bullet_shell", {
			description = "".. core.colorize("#00eaff", "Bloody bullet shell\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 18%\n")..core.colorize("#FFFFFF", "Ranged crit chance bonus: 2%\n") ..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_bloody_bullet_shell_inv.png",
		groups = {armor_ranged_dmg=0.18,armor_ranged_crit=2, armor_accessory=1, armor_heal=0, armor_use=0},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:emerald_bracelets", {
			description = "".. core.colorize("#00eaff", "emerald bracelets\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 25%\n") ..core.colorize("#FFFFFF", "Ammo saving bonus: 5%\n") ..core.colorize("#FFFFFF", "Ranged crit bonus: 1%\n") ..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_emerald_bracelets_inv.png",
		groups = {armor_ranged_crit=1, armor_ammo_save=5, armor_ranged_dmg=0.25, armor_accessory=1, armor_heal=0, armor_use=0},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:ruby_bracelets", {
			description = "".. core.colorize("#00eaff", "Ruby bracelets\n") ..core.colorize("#FFFFFF", "Melee damage bonus: 25%\n")..core.colorize("#FFFFFF", "Melee crit bonus: 3%\n")..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_ruby_bracelets_inv.png",
		groups = {armor_melee_crit=1, armor_melee_dmg=0.25, armor_accessory=1, armor_heal=0, armor_use=0},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:sapphire_bracelets", {
			description = "".. core.colorize("#00eaff", "Sapphire bracelets\n") ..core.colorize("#FFFFFF", "Magic damage bonus: 25%\n") ..core.colorize("#FFFFFF", "Magic crit bonus: 1%\n") ..core.colorize("#FFFFFF", "Mana saving bonus: 10%\n")..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_sapphire_bracelets_inv.png",
		groups = {armor_mana_save=0.10, armor_magic_dmg=0.25, armor_accessory=1, armor_heal=0, armor_magic_crit=1, armor_use=0},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:encrusted_bracelets", {
			description = "".. core.colorize("#00eaff", "Encrusted bracelets\n") ..core.colorize("#FFFFFF", "Bonus to all damages: 22%\n") ..core.colorize("#FFFFFF", "Mana and ammo saving bonus: 8%\n")..core.colorize("#FFFFFF", "Bonus to all crits: 2%\n")..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_encrusted_bracelets_inv.png",
		groups = {armor_ranged_crit=2, armor_melee_crit=2, armor_mana_save=0.08, armor_ammo_save=8, armor_ranged_dmg=0.22, armor_melee_dmg=0.22, armor_magic_dmg=0.22, armor_magic_crit=2, armor_accessory=1, armor_heal=0, armor_use=0},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:spiked_bracelets", {
			description = "".. core.colorize("#2a00ff", "Spiked bracelets\n") ..core.colorize("#FFFFFF", "Melee damage bonus: 33%\n")..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_spiked_bracelets_inv.png",
		groups = {armor_melee_dmg=0.33, armor_accessory=1, armor_heal=0, armor_use=0},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:magical_scope", {
			description = "".. core.colorize("#00eaff", "Magical scope\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 25%\n")..core.colorize("#FFFFFF", "Ranged crit chance bonus: 2%\n") ..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_magical_scope_inv.png",
		groups = {armor_ranged_dmg=0.25,armor_ranged_crit=2, armor_accessory=1, armor_heal=0, armor_use=0},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:bloody_scope", {
			description = "".. core.colorize("#00eaff", "Bloody scope\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 38%\n") ..core.colorize("#FFFFFF", "Ranged crit chance bonus: 3%\n") ..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_bloody_scope_inv.png",
		groups = {armor_ranged_dmg=0.38,armor_ranged_crit=3, armor_accessory=1, armor_heal=0, armor_use=0},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:regen_amulet", {
			description = "".. core.colorize("#00eaff", "Amulet of regeneration\n") ..core.colorize("#FFFFFF", "Regenerates 0.4 HP every second\n")..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_regen_amulet_inv.png",
		groups = {armor_accessory=1, armor_heal=0, armor_use=0, armor_regen = 4},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:mana_amulet", {
			description = "".. core.colorize("#00eaff", "Amulet of sorcery\n") ..core.colorize("#FFFFFF", "Regenerates 7MP every second\n")..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_mana_amulet_inv.png",
		groups = {armor_accessory=1, armor_heal=0, armor_use=0, armor_mana_regen=7},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:restoration_amulet", {
			description = "".. core.colorize("#00eaff", "Amulet of restoration\n") ..core.colorize("#FFFFFF", "Regenerates 0.3 HP and 6MP every second\n")..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_restoration_amulet_inv.png",
		groups = {armor_accessory=1, armor_heal=4, armor_use=0, armor_regen = 3, armor_mana_regen=6},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:adventurer_amulet", {
			description = "".. core.colorize("#00eaff", "Adventurer's amulet\n") ..core.colorize("#FFFFFF", "Regenerates 0.3 HP and 6MP every second\n")..core.colorize("#FFFFFF", "Heal chance: 4\n") ..core.colorize("#FFFFFF", "Jump bonus: 115%\n")..core.colorize("#FFFFFF", "Speed bonus: 125%\n")  ..core.colorize("#FFFFFF", "Gravity reduction: 12%\n")..core.colorize("#FFFFFF", "Accessory"),
		inventory_image = "testventure_adventurer_amulet_inv.png",
		groups = {armor_accessory=1, physics_gravity=-0.12,physics_speed=1.25,physics_jump=1.15,armor_heal=4, armor_use=0,armor_regen = 3, armor_mana_regen = 6},
		armor_groups = {fleshy=0.0},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

---
--- frost
---

armor:register_armor("testventure:helmet_frost", {
			description = "".. core.colorize("#00eaff", "Frost helmet\n")..core.colorize("#FFFFFF", "Protection level: 13.3\n")..core.colorize("#FFFFFF", "Speed bonus: 8%\n")..core.colorize("#FFFFFF", "Ranged damage bonus: 15%\n") ..core.colorize("#FFFFFF", "melee damage bonus: 5%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.55\n") ..core.colorize("#FFFFFF", "Ammo saving: 4%\n")..core.colorize("#FFFFFF", "Ranged crit chance bonus: 1%\n")   ..core.colorize("#FFFFFF", "Set bonus: Increases ranged damage by 45%"),
		inventory_image = "testventure_inv_helmet_frost.png",
		groups = {physics_speed=0.08,armor_ranged_dmg=0.15,armor_melee_dmg=0.05,armor_ammo_save=4,armor_ranged_crit=1 , armor_head=1, armor_heal=10.5, armor_use=50},
		armor_groups = {fleshy=13.3},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:chestplate_frost", {
			description = "".. core.colorize("#00eaff", "Frost chestplate\n")..core.colorize("#FFFFFF", "Protection level: 18.3\n")..core.colorize("#FFFFFF", "Speed bonus: 8%\n")..core.colorize("#FFFFFF", "Ranged damage bonus: 14%\n")..core.colorize("#FFFFFF", "melee damage bonus: 7%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.55\n")..core.colorize("#FFFFFF", "Ammo saving: 4%\n")..core.colorize("#FFFFFF", "Ranged crit chance bonus: 1%\n")  ..core.colorize("#FFFFFF", "Set bonus: Increases ranged damage by 45%"),
		inventory_image = "testventure_inv_chestplate_frost.png",
		groups = {physics_speed=0.08,armor_ranged_dmg=0.14,armor_melee_dmg=0.07,armor_ammo_save=4,armor_ranged_crit=1 , armor_torso=1, armor_heal=10.55, armor_use=50},
		armor_groups = {fleshy=18.3},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:leggings_frost", {
			description = "".. core.colorize("#00eaff", "Frost leggings\n")..core.colorize("#FFFFFF", "Protection level: 18.3\n")..core.colorize("#FFFFFF", "Speed bonus: 17%\n")..core.colorize("#FFFFFF", "Ranged damage bonus: 10%\n")..core.colorize("#FFFFFF", "melee damage bonus: 5%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.55\n")..core.colorize("#FFFFFF", "Ammo saving: 4%\n")..core.colorize("#FFFFFF", "Ranged crit chance bonus: 1%\n")  ..core.colorize("#FFFFFF", "Set bonus: Increases ranged damage by 45%"),
		inventory_image = "testventure_inv_leggings_frost.png",
		groups = {physics_speed=0.17,armor_ranged_dmg=0.10,armor_melee_dmg=0.05,armor_ammo_save=4,armor_ranged_crit=1 , armor_legs=1, armor_heal=10.55, armor_use=50},
		armor_groups = {fleshy=18.3},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})
armor:register_armor("testventure:boots_frost", {
			description = "".. core.colorize("#00eaff", "Frost boots\n")..core.colorize("#FFFFFF", "Protection level: 13.3\n")..core.colorize("#FFFFFF", "Speed bonus: 19%\n")..core.colorize("#FFFFFF", "Ranged damage bonus: 9%\n")..core.colorize("#FFFFFF", "melee damage bonus: 4%\n")    ..core.colorize("#FFFFFF", "Heal chance: 10.55\n")..core.colorize("#FFFFFF", "Ammo saving: 4%\n")..core.colorize("#FFFFFF", "Ranged crit chance bonus: 1%\n")  ..core.colorize("#FFFFFF", "Set bonus: Increases ranged damage by 45%"),
		inventory_image = "testventure_inv_boots_frost.png",
		groups = {physics_speed=0.19,armor_ranged_dmg=0.09,armor_melee_dmg=0.04,armor_ammo_save=4,armor_ranged_crit=1 ,armor_feet=1, armor_heal=10.55, armor_use=50},
		armor_groups = {fleshy=13.3},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})

armor:register_armor("testventure:shield_frost", {
			description = "".. core.colorize("#00eaff", "Frost shield\n")..core.colorize("#FFFFFF", "Protection level: 13.3\n") ..core.colorize("#FFFFFF", "Speed bonus: 7%\n") ..core.colorize("#FFFFFF", "Ranged damage bonus: 15%\n") ..core.colorize("#FFFFFF", "melee damage bonus: 10%\n")   ..core.colorize("#FFFFFF", "Heal chance: 10.55 \n")..core.colorize("#FFFFFF", "Ammo saving: 4%\n") ..core.colorize("#FFFFFF", "Ranged crit chance bonus: 1%\n") ..core.colorize("#FFFFFF", "Set bonus: Increases ranged damage by 45%"),
		inventory_image = "testventure_inv_shield_frost.png",
		groups = {physics_speed=0.07,armor_ranged_dmg=0.15,armor_melee_dmg=0.10,armor_ammo_save=4,armor_ranged_crit=1 ,armor_shield=1, armor_heal=10.55, armor_use=50},
		armor_groups = {fleshy=13.3},
		damage_groups = {cracky=2, snappy=1, choppy=1, level=3},
	})



