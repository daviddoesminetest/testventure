minetest.register_node("testventure:thorny_jungle_bush", {
		description = "".. core.colorize("#00eaff", "Thorny jungle bush\n")..core.colorize("#FFFFFF", "A placable, harmful block"),
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 2.2,
	tiles = {"testventure_thorny_jungle_bush.png"},
	inventory_image = "testventure_thorny_jungle_bush.png",
	wield_image = "testventure_thorny_jungle_bush.png",
	paramtype = "light",
	stack_max= 999,
	sunlight_propagates = true,
	walkable = false,
	liquidtype = "source",
	liquid_range= 0,
	liquid_viscosity = 10,
	damage_per_second = 2,
	liquid_alternative_flowing = "testventure:thorny_jungle_bush",
	liquid_alternative_source = "testventure:thorny_jungle_bush",
	liquid_renewable = false,
	groups = {snappy = 3, flora = 1, flammable = 1},
	sounds = default.node_sound_leaves_defaults(),

})

minetest.register_node("testventure:jungle_plant_1", {
		description = "".. core.colorize("#00eaff", "Jungle plant\n")..core.colorize("#FFFFFF", "A placable block"),
	drawtype = "plantlike",
	waving = 1,
	tiles = {"testventure_jungle_plant_1.png"},
	-- Use texture of a taller grass stage in inventory
	inventory_image = "testventure_jungle_plant_3.png",
	wield_image = "testventure_jungle_plant_3.png",
	paramtype = "light",
	stack_max= 999,
	visual_scale = 1.3,
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy = 3, flora = 1, attached_node = 1, grass = 1, flammable = 1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-6 / 16, -0.5, -6 / 16, 6 / 16, -5 / 16, 6 / 16},
	},

	on_place = function(itemstack, placer, pointed_thing)
		-- place a random grass node
		local stack = ItemStack("testventure:jungle_plant_" .. math.random(1,10))
		local ret = minetest.item_place(stack, placer, pointed_thing)
		return ItemStack("testventure:jungle_plant_1 " ..
			itemstack:get_count() - (1 - ret:get_count()))
	end,
})

for i = 2, 10 do
	minetest.register_node("testventure:jungle_plant_" .. i, {
		description = "Grass",
		drawtype = "plantlike",
		waving = 1,
		tiles = {"testventure_jungle_plant_" .. i .. ".png"},
		inventory_image = "testventure_jungle_plant_" .. i .. ".png",
		wield_image = "testventure_jungle_plant_" .. i .. ".png",
		paramtype = "light",
		visual_scale = 1.3,
		sunlight_propagates = true,
		walkable = false,
		buildable_to = true,
		drop = "testventure:jungle_plant_1",
		groups = {snappy = 3, flora = 1, attached_node = 1,
			not_in_creative_inventory = 1, grass = 1, flammable = 1},
		sounds = default.node_sound_leaves_defaults(),
		selection_box = {
			type = "fixed",
			fixed = {-6 / 16, -0.5, -6 / 16, 6 / 16, -3 / 16, 6 / 16},
		},
	})
end

minetest.register_node("testventure:jungle_mud", {
		description = "".. core.colorize("#00eaff", "Jungle mud\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_jungle_grass_top.png", "testventure_mud.png",
		{name = "testventure_mud.png^testventure_jungle_grass_side.png",
			tileable_vertical = false}},
	groups = {crumbly = 3},
drop = {
		max_items = 2,
		items = {
{items = {'testventure:jungle_grass_seeds'},rarity = 25,},
{items = {'testventure:mud'},rarity = 1,},
		}
	},
	stack_max= 999,
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_grass_footstep", gain = 0.25},
	}),
})

minetest.register_node("testventure:junglestone", {
		description = "".. core.colorize("#00eaff", "Junglestone\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_junglestone.png"},
	stack_max= 999,
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem("testventure:jungle_grass_seeds", {
		description = "".. core.colorize("#00eaff", "Jungle grass seeds\n")..core.colorize("#FFFFFF", "Use them on mud, to plant jungle grass on it"),
	inventory_image = "testventure_jungle_grass_seeds.png",
	stack_max= 999,
})

minetest.register_on_punchnode(function(pos, node, puncher, pointed_thing)
	if puncher:get_wielded_item():get_name() == "testventure:jungle_grass_seeds"
	and node.name == "testventure:mud" then
	if puncher:get_inventory():remove_item('main', "testventure:jungle_grass_seeds") 
then
		minetest.set_node(pos,{name="testventure:jungle_mud"}) 
	end
	end
end)

minetest.register_abm({
	nodenames = {"testventure:jungle_mud"},
	interval = 20,
	chance = 25,
	action = function(pos, node)
		pos.z = pos.z+1
		if minetest.get_node(pos).name == "testventure:mud" then
			node.name = "testventure:jungle_mud"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:jungle_mud"},
	interval = 20,
	chance = 25,
	action = function(pos, node)
		pos.z = pos.z-1
		if minetest.get_node(pos).name == "testventure:mud" then
			node.name = "testventure:jungle_mud"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:jungle_mud"},
	interval = 20,
	chance = 25,
	action = function(pos, node)
		pos.x = pos.x+1
		if minetest.get_node(pos).name == "testventure:mud" then
			node.name = "testventure:jungle_mud"
			minetest.set_node(pos, node)
		end
	end
})
minetest.register_abm({
	nodenames = {"testventure:jungle_mud"},
	interval = 20,
	chance = 25,
	action = function(pos, node)
		pos.x = pos.x-1
		if minetest.get_node(pos).name == "testventure:mud" then
			node.name = "testventure:jungle_mud"
			minetest.set_node(pos, node)
		end
	end
})


minetest.register_node("testventure:rich_mahogany_leaves", {
		description = "".. core.colorize("#00eaff", "Rich mahogany leaves\n")..core.colorize("#FFFFFF", "A placable block"),
	waving = 1,
	tiles = {"testventure_rich_mahogany_leaves.png"},
	stack_max= 999,
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, flammable = 2, leaves = 1, leafdecay = 3},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("testventure:vine", {
		description = "".. core.colorize("#00eaff", "Vine\n")..core.colorize("#FFFFFF", "Range: 5.0\n")..core.colorize("#FFFFFF", "A placable block, that can be climbed"),
	range = 6.0,
	drawtype = "plantlike",
	walkable = false,
	climbable = true,
	paramtype = "light",
	sunlight_propagates = true,
	visual_scale = 1.5,
	tiles = {"testventure_vine.png"},
	groups = {snappy = 3},
	stack_max= 999,
	inventory_image = "testventure_vine.png",
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.2, -0.5, -0.2, 0.2, 0.5, 0.2},
		},
	},
	sounds = default.node_sound_stone_defaults(),
})



minetest.register_node("testventure:rich_mahogany_tree", {
		description = "".. core.colorize("#00eaff", "Rich mahogany tree\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_rich_mahogany_top.png", "testventure_rich_mahogany_top.png", "testventure_rich_mahogany_side.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	stack_max= 999,
	groups = {tree = 1, choppy = 2, oddly_breakable_by_hand = 1, flammable = 2},
	sounds = default.node_sound_wood_defaults(),

	on_place = minetest.rotate_node
})

minetest.register_node("testventure:rich_mahogany_wood", {
		description = "".. core.colorize("#00eaff", "Rich mahogany wood\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_rich_mahogany_wood.png"},
	is_ground_content = false,
	stack_max= 999,
	groups = {choppy = 3,oddly_breakable_by_hand=2, flammable = 2},
	sounds = default.node_sound_wood_defaults(),
})

default.register_leafdecay({
	trunks = {"testventure:rich_mahogany_tree"},
	leaves = {"testventure:rich_mahogany_leaves"},
	radius = 8,
})