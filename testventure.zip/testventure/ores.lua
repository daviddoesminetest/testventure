minetest.register_node("testventure:niobium_ore", {
		description = "".. core.colorize("#2a00ff", "Niobium Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_stone.png^testventure_niobium_ore.png"},
	groups = {cracky = 5,is_ore=1,progress_ore=1},
	drop = "testventure:niobium_lump 1",
	light_source = 4,
	on_blast = function() end,
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:amethyst_ore", {
		description = "".. core.colorize("#00eaff", "amethyst Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_stone.png^testventure_amethyst_ore.png"},
	groups = {cracky = 1,is_ore=1,common_ore=1},
	drop = "testventure:amethyst 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:topaz_ore", {
		description = "".. core.colorize("#00eaff", "topaz Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_stone.png^testventure_topaz_ore.png"},
	groups = {cracky = 1,is_ore=1,common_ore=1},
	drop = "testventure:topaz 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:emerald_ore", {
		description = "".. core.colorize("#00eaff", "emerald Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_stone.png^testventure_emerald_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:emerald 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:sapphire_ore", {
		description = "".. core.colorize("#00eaff", "sapphire Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_stone.png^testventure_sapphire_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:sapphire 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:ruby_ore", {
		description = "".. core.colorize("#00eaff", "ruby Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_stone.png^testventure_ruby_ore.png"},
	groups = {cracky = 1,is_ore=1,uncommon_ore=1},
	drop = "testventure:ruby 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("testventure:smaranium_ore", {
		description = "".. core.colorize("#00eaff", "Smaranium Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_stone.png^testventure_smaranium_ore.png"},
	groups = {cracky = 1,is_ore=1,rare_ore=1},
	drop = "testventure:smaranium_lump 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:black_silver_ore", {
		description = "".. core.colorize("#00eaff", "Black silver Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"default_stone.png^testventure_black_silver_ore.png"},
	groups = {cracky = 4,is_ore=1,rare_ore=1},
	drop = "testventure:black_silver_lump 1",
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:eternal_ice_ore", {
		description = "".. core.colorize("#00eaff", "Eternal ice Ore\n")..core.colorize("#FFFFFF", "An ore"),
	tiles = {"testventure_icestone.png^testventure_eternal_ice_ore.png"},
	groups = {cracky = 4,is_ore=1,rare_ore=1},
	light_source = 8,
	drop = "testventure:eternal_ice_shards",
	sounds = default.node_sound_stone_defaults(),
})

