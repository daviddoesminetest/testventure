local reg_timer = 0
minetest.register_globalstep(function(dtime, player)
	reg_timer = reg_timer + dtime;
	if reg_timer >= 1.0 then
	reg_timer = 0
	for _, player in pairs(minetest.get_connected_players()) do
	local name = player:get_player_name()
	local armor_regen = armor.def[name].regen
	local armor_mana_regen = armor.def[name].mana_regen
mana.add(player:get_player_name(), armor_mana_regen)
meta = player:get_meta()
regen_power = meta:get_int("regen_amount") or 0
meta:set_int("regen_amount", regen_power + 1 + armor_regen)

---------amberregen-------------------
	local inv = minetest.get_inventory({type="player", name=player:get_player_name()})
local name = player:get_player_name()
		timer = 0
		local armor = minetest.get_inventory({type="detached", name = name .. "_armor"})
		if armor then
			local set_part_a = ItemStack("testventure:helmet_amber")
			local set_part_b = ItemStack("testventure:chestplate_amber")
			local set_part_c = ItemStack("testventure:leggings_amber")
			local set_part_d = ItemStack("testventure:boots_amber")
			local set_part_e = ItemStack("testventure:shield_amber")
			if armor:contains_item("armor", set_part_a)
			and armor:contains_item("armor", set_part_b)
			and armor:contains_item("armor", set_part_c)
			and armor:contains_item("armor", set_part_d)
			and armor:contains_item("armor", set_part_e)
			then
 meta = player:get_meta()
	regen_power = meta:get_int("regen_amount") or 0
	meta:set_int("regen_amount", regen_power + 10)
end end 

---------crimsonregen-------------------
	local inv = minetest.get_inventory({type="player", name=player:get_player_name()})
local name = player:get_player_name()
		timer = 0
		local armor = minetest.get_inventory({type="detached", name = name .. "_armor"})
		if armor then
			local set_part_a = ItemStack("testventure:helmet_crimson")
			local set_part_b = ItemStack("testventure:chestplate_crimson")
			local set_part_c = ItemStack("testventure:leggings_crimson")
			local set_part_d = ItemStack("testventure:boots_crimson")
			local set_part_e = ItemStack("testventure:shield_crimson")
			if armor:contains_item("armor", set_part_a)
			and armor:contains_item("armor", set_part_b)
			and armor:contains_item("armor", set_part_c)
			and armor:contains_item("armor", set_part_d)
			and armor:contains_item("armor", set_part_e)
			then
 meta = player:get_meta()
	regen_power = meta:get_int("regen_amount") or 0
	meta:set_int("regen_amount", regen_power + 7)
end end  
------------heavenly----------------
	local inv = minetest.get_inventory({type="player", name=player:get_player_name()})
local name = player:get_player_name()
		timer = 0
		local armor = minetest.get_inventory({type="detached", name = name .. "_armor"})
		if armor then
local set_part_a = ItemStack( "testventure:helmet_heavenly")
local set_part_b = ItemStack("testventure:chestplate_heavenly")
local set_part_c = ItemStack("testventure:leggings_heavenly")
local set_part_d = ItemStack("testventure:boots_heavenly")
local set_part_e = ItemStack("testventure:shield_heavenly")
			if armor:contains_item("armor", set_part_a)
			and armor:contains_item("armor", set_part_b)
			and armor:contains_item("armor", set_part_c)
			and armor:contains_item("armor", set_part_d)
			and armor:contains_item("armor", set_part_e)
			then
mana.add(player:get_player_name(), 10)
end end

-----------------amber sword-------------

	local wielded_item = player:get_wielded_item():get_name()
	if wielded_item == "testventure:amber_sword" then
 meta = player:get_meta()
	regen_power = meta:get_int("regen_amount") or 0
	meta:set_int("regen_amount", regen_power + 5)
end

---------regen potion------------
	for playername, has_regen in pairs(testventure.regen) do
			if has_regen then
 meta = player:get_meta()
	regen_power = meta:get_int("regen_amount") or 0
	meta:set_int("regen_amount", regen_power + 5)
end end

---------frost ranged dmg-------------------
	local inv = minetest.get_inventory({type="player", name=player:get_player_name()})
local name = player:get_player_name()
		timer = 0
		local armor = minetest.get_inventory({type="detached", name = name .. "_armor"})
		if armor then
			local set_part_a = ItemStack("testventure:helmet_frost")
			local set_part_b = ItemStack("testventure:chestplate_frost")
			local set_part_c = ItemStack("testventure:leggings_frost")
			local set_part_d = ItemStack("testventure:boots_frost")
			local set_part_e = ItemStack("testventure:shield_frost")
			if armor:contains_item("armor", set_part_a)
			and armor:contains_item("armor", set_part_b)
			and armor:contains_item("armor", set_part_c)
			and armor:contains_item("armor", set_part_d)
			and armor:contains_item("armor", set_part_e)
			then
 	meta = player:get_meta()
	srd = meta:get_int("ranged_dmg_meta") or 0
	srd_apl = meta:get_int("srd_applied") or 0
	if srd_apl < 1 then 
	meta:set_int("ranged_dmg_meta", srd + 45)
	meta:set_int("srd_applied", 45)
	end
	else
	srd = meta:get_int("ranged_dmg_meta") or 0
	srd_apl = meta:get_int("srd_applied") or 0
	if srd_apl > 0 then 
 	meta = player:get_meta()
	meta:set_int("ranged_dmg_meta", srd - srd_apl)
	meta:set_int("srd_applied", 0)
	end
	
end end  

end end end)


