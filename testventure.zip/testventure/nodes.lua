---orebrix---

minetest.register_node("testventure:cloudantite_bricks", {
		description = "".. core.colorize("#00eaff", "Cloudantite Bricks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_cloudantite_bricks.png"},
	stack_max= 999,
	groups = {cracky = 2},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("testventure:niobium_bricks", {
		description = "".. core.colorize("#2a00ff", "Niobium Bricks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_niobium_bricks.png"},
	stack_max= 999,
	groups = {cracky = 2},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("testventure:black_silver_bricks", {
		description = "".. core.colorize("#00eaff", "Black silver Bricks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_black_silver_bricks.png"},
	stack_max= 999,
	groups = {cracky = 2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:shadowsteel_bricks", {
		description = "".. core.colorize("#00eaff", "Shadowsteel Bricks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_shadowsteel_bricks.png"},
	stack_max= 999,
	groups = {cracky = 2},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("testventure:crimrubite_bricks", {
		description = "".. core.colorize("#00eaff", "Crimrubite Bricks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_crimrubite_bricks.png"},
	stack_max= 999,
	groups = {cracky = 2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:smaranium_bricks", {
		description = "".. core.colorize("#00eaff", "Smaranium Bricks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_smaranium_bricks.png"},
	stack_max= 999,
	groups = {cracky = 2},
	sounds = default.node_sound_stone_defaults(),
})

---



minetest.register_node("testventure:bloodstone_bricks", {
		description = "".. core.colorize("#00eaff", "Bloodstone Bricks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_bloodstone_bricks.png"},
	stack_max= 999,
	groups = {cracky = 2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:mud", {
		description = "".. core.colorize("#00eaff", "Mud\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_mud.png"},
	stack_max= 999,
	groups = {crumbly = 3},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("testventure:wooden_support", {
		description = "".. core.colorize("#00eaff", "Wooden support\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_wooden_support.png"},
	stack_max= 999,
	groups = {choppy = 3,oddly_breakable_by_hand=2},
	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("testventure:planked_rocks", {
		description = "".. core.colorize("#00eaff", "Planked rocks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_planked_rocks.png"},
	stack_max= 999,
	groups = {choppy = 3,cracky = 3},
	sounds = default.node_sound_wood_defaults(),
})


minetest.register_node("testventure:flare_block", {
		description = "" ..core.colorize("#00eaff","Flare blocks\n") ..core.colorize("#FFFFFF", "YOU HACKER, YOU!"),
	drawtype = "airlike",
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	pointable = false,
	sunlight_propagates = true,
	light_source = 13,
	on_construct = function(pos)
		minetest.get_node_timer(pos):start(0.5)
	end,
	on_timer = function(pos, elapsed)
		minetest.get_node_timer(pos):start(0.5)
	for i=1,7 do
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-0.5,0.5), y=math.random(1.0,2.0), z=math.random(-0.5,0.5)},
		expirationtime = 1.5,
		size = 9,
		collisiondetection = true,
		vertical = false,
		texture = "testventure_flare_spark.png",
		glow = 30,
	})
	end
	if math.random(1, 1000) == 1 then
		minetest.swap_node(pos, {name = "air"})
	end
	end,
	drop = "",
	groups = {snappy = 3, not_in_creative_inventory=1},
})

minetest.register_node("testventure:swordstone", {
		description = "" ..core.colorize("#00eaff","Swordstone\n") ..core.colorize("#FFFFFF", "Contains a cool sword!"),
	drawtype = "mesh",
	mesh = "testventure_swordstone.obj",
	tiles = {"testventure_swordstone.png"},
	paramtype = "light",
	sunlight_propagates = true,
	light_source = 10,
	sounds = default.node_sound_glass_defaults(),
	paramtype2 = "facedir",
drop = {
		max_items = 1,
		items = {
{items = {'testventure:enchanted_cutlass'},rarity = 12,},
{items = {'testventure:energy_sword'},rarity = 8,},
{items = {'testventure:greatsword'},rarity = 4,},
{items = {'testventure:fancy_dagger'},rarity = 1,},
		}
	},
	on_place = minetest.rotate_node,
	groups = {cracky = 2},
})

----
---- slime
----

minetest.register_node("testventure:magic_slime_block", {
		description = "".. core.colorize("#00eaff", "Magical slime block\n") ..core.colorize("#FFFFFF", "Reduces falling damage by 75% and glows\n")..core.colorize("#FFFFFF", "You will regenerate 10MP/sec while near this block\n")  ..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_magic_slime_block.png"},
	groups = {oddly_breakable_by_hand = 3, fall_damage_add_percent=-75},
	light_source = 12,
	stack_max= 999,
	sounds = default.node_sound_dirt_defaults(),
})
minetest.register_node("testventure:slime_block", {
		description = "".. core.colorize("#00eaff", "Slime block\n")..core.colorize("#FFFFFF", "Reduces falling damage by 60%\n") ..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_slime_block.png"},
	groups = {oddly_breakable_by_hand = 3, fall_damage_add_percent=-60},
	stack_max= 999,
	sounds = default.node_sound_dirt_defaults(),
})
minetest.register_node("testventure:sandy_slime_block", {
		description = "".. core.colorize("#00eaff", "Sandy slime block\n")..core.colorize("#FFFFFF", "Works like quicksand\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_sandy_slime_block.png"},
	groups = {oddly_breakable_by_hand = 3},
	stack_max= 999,
		drawtype = "glasslike",
		drowning = 1,
		walkable = false,
		liquidtype = "source",
		liquid_range= 0,
		liquid_viscosity = 15,
liquid_alternative_flowing = "testventure:sandy_slime_block",
liquid_alternative_source = "testventure:sandy_slime_block",
		liquid_renewable = false,
	post_effect_color = {a = 245, r = 130, g = 90, b = 20},
	sounds = default.node_sound_dirt_defaults(),
})
minetest.register_node("testventure:crimson_slime_block", {
		description = "".. core.colorize("#00eaff", "Crimson Slime block\n")..core.colorize("#FFFFFF", "Works like quicksand and causes 3 dmg per second\n") ..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_crimson_slime_block.png"},
	groups = {oddly_breakable_by_hand = 3},
	stack_max= 999,
		drawtype = "glasslike",
		walkable = false,
		damage_per_second = 3,
		liquidtype = "source",
		liquid_range= 0,
		liquid_viscosity = 20,
liquid_alternative_flowing = "testventure:crimson_slime_block",
liquid_alternative_source = "testventure:crimson_slime_block",
		liquid_renewable = false,
	post_effect_color = {a = 245, r = 69, g = 0, b = 0},
	sounds = default.node_sound_dirt_defaults(),
})
minetest.register_node("testventure:pink_slime_block", {
		description = "".. core.colorize("#00eaff", "Pink Slime block\n")..core.colorize("#FFFFFF", "Reduces falling damage by 80% and is extremelly bouncy\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_pink_slime_block.png"},
	groups = {oddly_breakable_by_hand = 3, fall_damage_add_percent=-80, bouncy = 125},
	stack_max= 999,
	sounds = default.node_sound_dirt_defaults(),
})
minetest.register_node("testventure:frozen_slime_block", {
		description = "".. core.colorize("#00eaff", "Frozen Slime block\n")..core.colorize("#FFFFFF", "Works like extra-thick quicksand and it also glows.\n") ..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_frozen_slime_block.png"},
	groups = {oddly_breakable_by_hand = 3},
	stack_max= 999,
	light_source = 10,
		drowning = 1,
		walkable = false,
		liquidtype = "source",
		liquid_range= 0,
		liquid_viscosity = 25,
liquid_alternative_flowing = "testventure:frozen_slime_block",
liquid_alternative_source = "testventure:frozen_slime_block",
		liquid_renewable = false,
	sounds = default.node_sound_dirt_defaults(),
})
----
---- buildin' materials
----

minetest.register_node("testventure:darkwood", {
		description = "".. core.colorize("#00eaff", "Darkwood\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_darkwood.png"},
	groups = {choppy = 3},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:grass_rope", {
		description = "".. core.colorize("#00eaff", "Grass rope\n")..core.colorize("#FFFFFF", "Range: 6.0\n")..core.colorize("#FFFFFF", "A placable block, that can be climbed"),
	range = 6.0,
	drawtype = "plantlike",
	walkable = false,
	climbable = true,
	paramtype = "light",
	sunlight_propagates = true,
	tiles = {"testventure_grass_rope_block.png"},
	groups = {snappy = 3},
	stack_max= 999,
	inventory_image = "testventure_grass_rope.png",
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.2, -0.5, -0.2, 0.2, 0.5, 0.2},
		},
	},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:rope", {
		description = "".. core.colorize("#00eaff", "Rope\n")..core.colorize("#FFFFFF", "Range: 7.5\n")..core.colorize("#FFFFFF", "A placable block, that can be climbed"),
	range = 7.5,
	drawtype = "plantlike",
	walkable = false,
	climbable = true,
	paramtype = "light",
	sunlight_propagates = true,
	tiles = {"testventure_rope_block.png"},
	groups = {snappy = 3},
	stack_max= 999,
	inventory_image = "testventure_rope_inv.png",
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.2, -0.5, -0.2, 0.2, 0.5, 0.2},
		},
	},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:icestone", {
		description = "".. core.colorize("#00eaff", "Icestone\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_icestone.png"},
	groups = {cracky = 3, slippery=5},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:marble", {
		description = "".. core.colorize("#00eaff", "Marble\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_marble.png"},
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:gneis", {
		description = "".. core.colorize("#00eaff", "Gneis\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_gneis.png"},
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:marble_bricks", {
		description = "".. core.colorize("#00eaff", "Marble bricks\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_marble_bricks.png"},
	groups = {cracky = 2},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:slush", {
		description = "".. core.colorize("#00eaff", "Slush\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_slush.png"},
	groups = {crumbly = 2, oddly_breakable_by_hand = 2, falling_node = 1,},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:aquastone_brick", {
		description = "".. core.colorize("#00eaff", "Aquastone Brick\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_aquastone_brick.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:purple_encrusted_block", {
		description = "".. core.colorize("#00eaff", "Purple encrusted block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_purple_encrusted_block.png"},
	light_source = 5,
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:red_encrusted_block", {
		description = "".. core.colorize("#00eaff", "red encrusted block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_red_encrusted_block.png"},
	light_source = 5,
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:blue_encrusted_block", {
		description = "".. core.colorize("#00eaff", "blue encrusted block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_blue_encrusted_block.png"},
	light_source = 5,
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:green_encrusted_block", {
		description = "".. core.colorize("#00eaff", "green encrusted block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_green_encrusted_block.png"},
	light_source = 5,
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:yellow_encrusted_block", {
		description = "".. core.colorize("#00eaff", "yellow encrusted block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_yellow_encrusted_block.png"},
	light_source = 5,
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:orange_encrusted_block", {
		description = "".. core.colorize("#00eaff", "orange encrusted block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_orange_encrusted_block.png"},
	light_source = 5,
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:cyan_encrusted_block", {
		description = "".. core.colorize("#00eaff", "cyan encrusted block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_cyan_encrusted_block.png"},
	light_source = 5,
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:white_encrusted_block", {
		description = "".. core.colorize("#00eaff", "white encrusted block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_white_encrusted_block.png"},
	light_source = 5,
	groups = {cracky = 3},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:amethyst_block", {
		description = "".. core.colorize("#00eaff", "amethyst block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_amethyst_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:topaz_block", {
		description = "".. core.colorize("#00eaff", "topaz block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_topaz_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:emerald_block", {
		description = "".. core.colorize("#00eaff", "emerald block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_emerald_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:sapphire_block", {
		description = "".. core.colorize("#00eaff", "sapphire block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_sapphire_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:ruby_block", {
		description = "".. core.colorize("#00eaff", "ruby block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_ruby_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_glass_defaults(),
})
minetest.register_node("testventure:niobium_block", {
		description = "".. core.colorize("#2a00ff", "Niobium block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_niobium_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:crimrubite_block", {
		description = "".. core.colorize("#00eaff", "Crimrubite block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_crimrubite_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:shadowsteel_block", {
		description = "".. core.colorize("#00eaff", "Shadowsteel block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_shadowsteel_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("testventure:smaranium_block", {
		description = "".. core.colorize("#00eaff", "Smaranium block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_smaranium_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:cloudantite_block", {
		description = "".. core.colorize("#00eaff", "Cloudantite block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_cloudantite_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("testventure:black_silver_block", {
		description = "".. core.colorize("#00eaff", "Black silver block\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {"testventure_black_silver_block.png"},
	groups = {cracky = 1},
	stack_max= 999,
	sounds = default.node_sound_stone_defaults(),
})

---- etc

booty_table = {
  "default:gold_ingot 3",
  "default:steel_ingot 4",
  "default:bronze_ingot 3",
  "default:coal_lump 6",
  "default:diamond 1",
  "default:mese_crystal 1",
  "testventure:health_potion_small 3",
  "testventure:health_potion 1",
  "testventure:mana_potion_small 3",
  "testventure:mana_potion 1",
  "testventure:stone_arrow 40",
  "testventure:steel_arrow 20",
  "testventure:sharpshooting_potion 1",
  "testventure:swiftness_potion 1",
  "testventure:ironskin_potion 1",
  "testventure:regen_potion 1",
  "testventure:strenght_potion 1",
  "testventure:manaregen_potion 1",
  "testventure:spelunkin_potion 1",
  "testventure:teleportation_potion 1",
  "testventure:glowing_potion 1",
  "testventure:force_potion 1",
  "testventure:jumping_potion 1",
  "testventure:antigravity_potion 1",
  "testventure:mining_potion 1",
  "testventure:invincibility_potion 1",
  "testventure:oxygen_potion 1",
  "testventure:featherweight_potion 1",
  "testventure:wealth_potion 1",
  "testventure:recall_potion 1",
  "testventure:grenade 5",
  "testventure:bomb 3",
  "testventure:dynamite 1",
  "testventure:musketball 15",
  "testventure:shuriken 25",
  "testventure:throwing_knife 16",
  "testventure:coin_gold 1",
  "testventure:coin_silver 35",
  "testventure:coin_copper 90",
  "testventure:rope 35",
  "testventure:flare 25",
}
good_booty_table = {
  "testventure:spear 1",
  "testventure:flare_gun 1",
  "testventure:handgun 1",
  "testventure:regen_amulet 1",
  "testventure:boots_speed 1",
  "testventure:coin_gold 10",
  "testventure:extractinator 1",
}


minetest.register_on_dignode(function(pos, oldnode, digger)
	if digger ~= nil and digger:is_player() then
	if oldnode.name == "testventure:treasure" then
	for i=1,math.random(3,5) do
local booty = minetest.add_item(pos, booty_table[math.random(#booty_table)])
end
end
end
end)

minetest.register_on_dignode(function(pos, oldnode, digger)
	if digger ~= nil and digger:is_player() then
	if oldnode.name == "testventure:treasure" then
	if math.random(1, 2) == 1 then
local booty = minetest.add_item(pos, good_booty_table[math.random(#good_booty_table)])
end
end
end
end)

minetest.register_node("testventure:treasure", {
		description = "".. core.colorize("#00eaff", "Treasure\n")..core.colorize("#FFFFFF", "Contains some booty!"),
	tiles = {
		"testventure_treasure_top.png", "testventure_treasure_top.png",
		"testventure_treasure_side.png", "testventure_treasure_side.png",
		"testventure_treasure_side.png", "testventure_treasure_front.png"
	},
	groups = {oddly_breakable_by_hand = 3},
	paramtype2 = "facedir",
	drop = "",
	stack_max= 999,
	on_blast = function() end,
	sounds = default.node_sound_stone_defaults(),
})


extract_table = {
  "testventure:coin_copper 1",
  "testventure:coin_copper 5",
  "testventure:coin_copper 25",
  "testventure:coin_copper 60",
  "testventure:coin_silver 1",
  "testventure:coin_silver 5",
  "testventure:coin_silver 12",
  "testventure:coin_silver 25",
  "default:coal_lump 1",
  "default:tin_lump 1",
  "default:copper_lump 1",
  "default:iron_lump 1",
  "default:gold_lump 1",
  "default:mese_crystal 1",
  "default:mese_fragment 1",
  "default:diamond 1",
  "default:flint 1",
  "testventure:smaranium_lump 1",
  "testventure:amethyst 1",
  "testventure:topaz 1",
  "testventure:emerald 1",
  "testventure:sapphire 1",
  "testventure:ruby 1",
  "testventure:amber 1",
  "testventure:primitive_javelin 12",
}

rare_extract_table = {
  "testventure:coin_gold 50",
  "testventure:comrad_kalashnikov 1",
}

minetest.register_node("testventure:extractinator", {
		description = "".. core.colorize("#00eaff", "Extractinator\n")..core.colorize("#FFFFFF", "Punch it with a block of gravel or slush, to extract something more useful\n")..core.colorize("#FFFFFF", "A placable block"),
	tiles = {
		"testventure_extractinator_top.png", "testventure_extractinator_side.png",
		"testventure_extractinator_side.png", "testventure_extractinator_side.png",
		"testventure_extractinator_side.png", "testventure_extractinator_front.png"
	},
	groups = {oddly_breakable_by_hand = 3},
	stack_max= 999,
	paramtype2 = "facedir",
	on_blast = function() end,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_on_punchnode(function(pos, node, puncher, pointed_thing)
	if puncher:get_wielded_item():get_name() == "default:gravel" 
	and node.name == "testventure:extractinator" 
	then	 
	if puncher:get_inventory():remove_item('main', "default:gravel") 
then
	pos.y = pos.y + 1.5
local extract = minetest.add_item(pos, extract_table[math.random(#extract_table)])
	if math.random(1, 200) == 1 then
local booty = minetest.add_item(pos, rare_extract_table[math.random(#rare_extract_table)])
end
	end
	end
end)

minetest.register_on_punchnode(function(pos, node, puncher, pointed_thing)
	if puncher:get_wielded_item():get_name() == "testventure:slush"
	and node.name == "testventure:extractinator" 
	then	 
	if puncher:get_inventory():remove_item('main', "testventure:slush") 
then
	pos.y = pos.y + 1.5
local extract = minetest.add_item(pos, extract_table[math.random(#extract_table)])
	if math.random(1, 200) == 1 then
local booty = minetest.add_item(pos, rare_extract_table[math.random(#rare_extract_table)])
end
	end
	end
end)
