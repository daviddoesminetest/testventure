--
-- falling star
--

minetest.register_craftitem("testventure:sword_fallingstar", {
			description = "".. core.colorize("#00eaff", "The falling star\n")..core.colorize("#FFFFFF", "Melee damage: 19\n")..core.colorize("#FFFFFF", "Critical chance: 7%\n")..core.colorize("#FFFFFF", "Knockback: 9\n")..core.colorize("#FFFFFF", "Full punch interval: 0.65\n")..core.colorize("#FFFFFF", "Range: 4.50\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV2): [1]=0.5, [2]=0.25, [3]=0.125"),
	inventory_image = "testventure_fallingstar.png",
	wield_scale = {x=1.65,y=1.65,z=1.0},
	stack_max = 1,
	range = 4.50,
	tool_capabilities = {
		full_punch_interval = 0.65,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=0.5, [2]=0.25, [3]=0.125}, uses=125, maxlevel=2},
		},
		damage_groups = {fleshy=19, knockback=9, critical=7},
	},
	sound = {breaks = "default_tool_breaks"},
})

local timer = 0
minetest.register_globalstep(function(dtime, player)
	timer = timer + dtime;
	if timer >= 0.4 then
	for _, player in pairs(minetest.get_connected_players()) do
			local inv = player:get_inventory()
			local controls = player:get_player_control()
			if controls.LMB then
			timer = 0
	local wielded_item = player:get_wielded_item():get_name()
		if wielded_item == "testventure:sword_fallingstar" then
		local pos = player:getpos()
		local dir = player:get_look_dir()
		local yaw = player:get_look_yaw()
		if pos and dir and yaw then
			pos.y = pos.y + 10.6
			local obj = minetest.add_entity(pos, "testventure:wstar_projectile")
			if obj then
				minetest.sound_play("testventure_throw", {object=obj})
				obj:setvelocity({x=dir.x * 15, y=dir.y * 15, z=dir.z * 15})
				obj:setacceleration({x=math.random(-2, 2), y=-15,z=math.random(-2, 2)})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or player
end end end end end end end end)

local testventure_wstar_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_wstar_projectile.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
	local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 2)
	for k, obj in pairs(objs) do
	if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:wstar_projectile" and obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = math.random(20, 30)
	base_crit = 15
	base_kb = 8
	dmg_bonus = dmg_bonus or 1
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 1 + base_crit + crit_bonus then
local damage = base_dmg * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else

local damage = base_dmg  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
	base_dmg = math.random(20, 30)
	base_crit = 15
	base_kb = 8
	dmg_bonus = dmg_bonus or 1
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 1 + crit_bonus then
local damage = base_dmg * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = base_dmg  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end

		local tiem = 0.05
		if self.timer >= 0.05 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-3, 3), y=math.random(-3, 3), z=math.random(-3, 3)},
		expirationtime = 0.9,
		size = math.random(1, 3),
		collisiondetection = false,
		vertical = false,
		texture = "testventure_star.png",
		glow = 45,
	})
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = 0,
		expirationtime = 0.04,
		size = 10,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_whitestar.png",
		glow = 45,
	})
		tiem = tiem + 0.2 
			end
		if self.timer >= 5.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
	for i=1,30 do
	minetest.add_particle({
		pos = self.lastpos,
		velocity = 0,
          	acceleration = {x=math.random(-8, 8), y=math.random(-8, 8), z=math.random(-6, 6)},
		size = math.random(2, 4), 
		expirationtime = math.random(1.0, 2.0),
		collisiondetection = false,
		vertical = false,
		texture = "testventure_star.png",
		glow = 30,
	})
		end
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end
minetest.register_entity("testventure:wstar_projectile", testventure_wstar_projectile)

--
-- endarkener sword
--

minetest.register_craftitem("testventure:endarkener", {
			description = "".. core.colorize("#00eaff", "Endarkener\n")..core.colorize("#FFFFFF", "Melee damage: 24\n")..core.colorize("#FFFFFF", "Critical chance: 12%\n") ..core.colorize("#FFFFFF", "Knockback: 12\n") ..core.colorize("#FFFFFF", "Full punch interval: 1.2\n")..core.colorize("#FFFFFF", "Range: 5.0\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.0, [2]=0.4, [3]=0.10\n")..core.colorize("#FFFFFF", "Shoots darkness projectiles"),
	inventory_image = "testventure_endarkener.png",
	wield_scale = {x=2.0,y=2.0,z=1.0},
	range = 5.0,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 1.2,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.0, [2]=0.4, [3]=0.10}, uses=100, maxlevel=3},
		},
		damage_groups = {fleshy=24, knockback=12,critical=12},
	},
	sound = {breaks = "default_tool_breaks"},
})

local testventure_darkness_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_darkness_projectile.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
	if obj:get_luaentity().name ~= "testventure:darkness_projectile" and 	
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = math.random(18, 24)
	base_crit = 12
	base_kb = 8
	dmg_bonus = melee_dmg or 1
	crit_bonus = melee_crit or 0
if math.random(1, 100) <= 1 + base_crit + crit_bonus then
local damage = base_dmg * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else

local damage = base_dmg  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
	base_dmg = math.random(18, 24)
	base_crit = 12
	base_kb = 8
	dmg_bonus = melee_dmg or 1
	crit_bonus = melee_crit or 0
if math.random(1, 100) <= 1 + crit_bonus then
local damage = base_dmg * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = base_dmg  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		local tiem = 0.05
		if self.timer >= 0.05 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-5, 5), y=math.random(-5, 5), z=math.random(-5, 5)},
		expirationtime = 0.75,
		size = 4,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_dark_particle.png",
		glow = 25,
	})
		tiem = tiem + 0.1 
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:darkness_projectile", testventure_darkness_projectile )

--
-- swordsicle 
--

minetest.register_craftitem("testventure:swordsicle", {
			description = "".. core.colorize("#00eaff", "Swordsicle\n")..core.colorize("#FFFFFF", "Melee damage: 19\n")..core.colorize("#FFFFFF", "Critical chance: 10%\n") ..core.colorize("#FFFFFF", "Knockback: 8\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.8\n")..core.colorize("#FFFFFF", "Range: 4.75\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.0, [2]=0.4, [3]=0.10\n")..core.colorize("#FFFFFF", "Shoots frost projectiles"),
	inventory_image = "testventure_swordsicle.png",
	wield_scale = {x=2.0,y=2.0,z=1.0},
	range = 4.75,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.0, [2]=0.4, [3]=0.10}, uses=100, maxlevel=3},
		},
		damage_groups = {fleshy=19, knockback=8,critical=10},
	},
	sound = {breaks = "default_tool_breaks"},
})


local testventure_frost_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_frost_projectile.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.2 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
if obj:get_luaentity().name ~= 
"testventure:frost_projectile" and 	
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = math.random(15, 19)
	base_crit = 10
	base_kb = 8
	dmg_bonus = melee_dmg or 1
	crit_bonus = melee_crit or 0
if math.random(1, 100) <= 1 + base_crit + crit_bonus then
local damage = base_dmg * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = base_dmg  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
	base_dmg = math.random(15, 19)
	base_crit = 10
	base_kb = 8
	dmg_bonus = dmg_bonus or 1
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 1 + crit_bonus then
local damage = base_dmg * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = base_dmg  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		local tiem = 0.05
		if self.timer >= 0.05 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-5, 5), y=math.random(-5, 5), z=math.random(-5, 5)},
		expirationtime = 0.75,
		size = 4,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_frost_particle.png",
		glow = 25,
	})
		tiem = tiem + 0.1 
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:frost_projectile", testventure_frost_projectile )



--
-- energy sword
--

energy_particle_table = {
  'testventure_energy_particle_a.png',
  'testventure_energy_particle_b.png',
  'testventure_energy_particle_c.png',
  'testventure_energy_particle_d.png',
}

minetest.register_craftitem("testventure:energy_sword", {
			description = "".. core.colorize("#00eaff", "energy sword\n")..core.colorize("#FFFFFF", "Melee damage: 15\n")..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Knockback: 5\n") ..core.colorize("#FFFFFF", "Full punch interval: 0.65\n")..core.colorize("#FFFFFF", "Range: 4.20\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=1.0, [2]=0.4, [3]=0.10\n")..core.colorize("#FFFFFF", "Shoots energy projectiles"),
	inventory_image = "testventure_energy_sword.png",
	wield_scale = {x=1.2,y=1.2,z=1.0},
	range = 4.20,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 0.65,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=1.0, [2]=0.4, [3]=0.10}, uses=100, maxlevel=3},
		},
		damage_groups = {fleshy=15, knockback=5,critical=5},
	},
	sound = {breaks = "default_tool_breaks"},
})

local testventure_energy_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}
testventure_energy_projectile.on_step = function(self, dtime, node, pos)
	self.timer = self.timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.25 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 1)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
if obj:get_luaentity().name ~= 
"testventure:energy_projectile" and 	
	obj:get_luaentity().name ~= 
"testventure:shadowball" and
	obj:get_luaentity().name ~= 
"testventure:sky_arrow" and    
	obj:get_luaentity().name ~= 
"testventure:bloodstone_boulder" and
	obj:get_luaentity().name ~= 
"testventure:sh_sniper_bullet" and
obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = math.random(13, 18)
	base_crit = 5
	base_kb = 3
	dmg_bonus = dmg_bonus or 1
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= 1 + base_crit + crit_bonus then
local damage = base_dmg * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb * 2},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
					self.object:remove()
					else
local damage = base_dmg  * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback = 1 + base_kb},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
					self.object:remove()
				end
			end
			else
if math.random(1, 100) <= 1 + crit_bonus then
local damage = base_dmg * 2 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			self.object:remove()
				else
local damage = base_dmg  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
				self.object:remove()
				end
			end
		local tiem = 0.05
		if self.timer >= 0.05 + tiem then
 energy_particle = energy_particle_table[math.random(#energy_particle_table)]
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-2, 2), y=math.random(-2, 2), z=math.random(-2, 2)},
		expirationtime = 0.70,
		size = 4,
		collisiondetection = false,
		vertical = false,
		texture = energy_particle,
		glow = 45,
	})
		tiem = tiem + 0.1 
			end
		if self.timer >= 4.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:energy_projectile", testventure_energy_projectile )


---
--- enchanted cutlass
---


minetest.register_craftitem("testventure:enchanted_cutlass", {
			description = "".. core.colorize("#00eaff", "Enchanted cutlass\n")..core.colorize("#FFFFFF", "Melee damage: 16\n")..core.colorize("#FFFFFF", "Critical chance: 5%\n") ..core.colorize("#FFFFFF", "Knockback: 1\n")..core.colorize("#FFFFFF", "Range: 3.8\n")..core.colorize("#FFFFFF", "Digging speed (Snappy LV3): [1]=0.25, [2]=0.1, [3]=0.05\n")..core.colorize("#FFFFFF", "Is rapidly auto-swung while holding mouse down"),
	inventory_image = "testventure_enchanted_cutlass.png",
	wield_scale = {x=2.0,y=2.0,z=1.0},
	range = 3.8,
	stack_max = 1,
	tool_capabilities = {
		full_punch_interval = 0.01,
		max_drop_level=3,
		groupcaps={
			snappy = {times={[1]=0.25, [2]=0.1, [3]=0.05}, uses=100, maxlevel=3},
		},
		damage_groups = {fleshy=16, knockback=1,critical=5},
	},
	sound = {breaks = "default_tool_breaks"},
})

e_swing_table = {
  'testventure_c_slash_a.png',
  'testventure_c_slash_b.png',
  'testventure_c_slash_c.png',
  'testventure_c_slash_d.png',
  'testventure_c_slash_e.png',
}


local cltimer = 0
minetest.register_globalstep(function(dtime, player)
	cltimer = cltimer + dtime;
	if cltimer >= 0.1 then
	for _, player in pairs(minetest.get_connected_players()) do
			local inv = player:get_inventory()
			local controls = player:get_player_control()
			if controls.LMB then
      e_swing = e_swing_table[math.random(#e_swing_table)]
			cltimer = 0
	local wielded_item = player:get_wielded_item():get_name()
		if wielded_item == "testventure:enchanted_cutlass" then
minetest.sound_play("testventure_throw", {object=player})
		local pos = player:getpos()
		local dir = player:get_look_dir()
		local yaw = player:get_look_yaw()
		if pos and dir and yaw then
			pos.y = pos.y + 1.35
	minetest.add_particle({
		pos = pos,
		velocity = {x=dir.x * 20, y=dir.y * 20, z=dir.z * 20} ,
          	acceleration = {x=math.random(-69,69), y=math.random(-69,69), z=math.random(-69,69)},
		expirationtime = 0.10,
		size = 25,
		collisiondetection = false,
		vertical = false,
		texture = e_swing,
		glow = 100,
	})
			end
		end
	end
end
end
	end)


---
--- well guns, but actually, no..
---

--- flamethrower

	minetest.register_craftitem("testventure:flamethrower", {
	stack_max= 1,
	wield_scale = {x=2.0,y=2.0,z=1.0},
		description = "" ..core.colorize("#00eaff"," flamethrower\n")..core.colorize("#FFFFFF", "Ranged damage: 10-15\n")..core.colorize("#FFFFFF", "Accuracy: 50%\n")..core.colorize("#FFFFFF", "knockback: 0\n") ..core.colorize("#FFFFFF", "Critical chance: 1%\n") ..core.colorize("#FFFFFF", "Uses slimeballs as ammo\n") ..core.colorize("#FFFFFF", "Rate of fire: 0.075\n") ..core.colorize("#FFFFFF", "Projectile velocity: 20\n")..core.colorize("#FFFFFF", "Shoots fire, which has 66,7% chance to penetrate enemies"),
	range = 0,
	inventory_image = "testventure_flamethrower.png",
})

local timer = 0
minetest.register_globalstep(function(dtime, player)
	timer = timer + dtime;
	if timer >= 0.075 then
	for _, player in pairs(minetest.get_connected_players()) do
			local inv = player:get_inventory()
			local controls = player:get_player_control()
			if controls.LMB then
	local wielded_item = player:get_wielded_item():get_name()
		if wielded_item == "testventure:flamethrower" then
		local inv = player:get_inventory()
		if inv:contains_item("main", "testventure:slimeball")then
		local name = player:get_player_name()
		local ammo_save = armor.def[name].ammo_save
	if math.random(1, 100) >= 0 + ammo_save then
	inv:remove_item("main", "testventure:slimeball")
end
		timer = 0
		local pos = player:getpos()
		local dir = player:get_look_dir()
		local yaw = player:get_look_yaw()
		if pos and dir and yaw then
	base_dmg = math.random(10,15)
	base_crit = 1
	bow_timer = 0.0
	dmg_bonus = armor.def[name].ranged_dmg + 1
	crit_bonus = armor.def[name].ranged_crit
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:ft_flame_projectile")
			if obj then
				minetest.sound_play("testventure_weak_gun", {object=obj})
				obj:setvelocity({x=dir.x * 20, y=dir.y * 20, z=dir.z * 20})
				obj:setacceleration({x=math.random(-5.0,5.0), y=math.random(0.0,5.0), z=math.random(-5.0,5.0)})
				obj:setyaw(yaw + math.pi)
				local ent = obj:get_luaentity()
				if ent then
					ent.player = ent.player or player
		
			end
		end
	end
end
end
	end
		end
			end
				end)

local testventure_ft_flame_projectile = {
	physical = false,
	timer = 0,
	visual = "sprite",
	visual_size = {x=0.5, y=0.5},
	textures = {"testventure_invisible.png"},
	lastpos= {},
	collisionbox = {0, 0, 0, 0, 0, 0},
}

testventure_ft_flame_projectile.on_step = function(self, dtime, node, pos)
	bow_timer = bow_timer or 0
	self.timer = self.timer + bow_timer + dtime
	local tiem = 0.002
	local pos = self.object:getpos()
	local node = minetest.get_node(pos)

	if self.timer > 0.18 then
		local objs = minetest.get_objects_inside_radius({x = pos.x, y = pos.y, z = pos.z}, 2)
		for k, obj in pairs(objs) do
			if obj:get_luaentity() ~= nil then
				if obj:get_luaentity().name ~= "testventure:ft_flame_projectile" and obj:get_luaentity().name ~= "__builtin:item" then
	base_dmg = base_dmg or 0
	base_critdmg = base_critdmg or 0
	base_crit = base_crit or 0
	dmg_bonus = dmg_bonus or 0
	crit_bonus = crit_bonus or 0
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = base_dmg * 3.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback=0},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			if math.random(1, 3) == 1 then
			self.object:remove()
			end
			self.timer = 0.00
					else
local damage = base_dmg * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
damage_groups= {fleshy = damage, knockback=0},
					}, nil)
					minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
			if math.random(1, 3) == 1 then
			self.object:remove()
			end
			self.timer = 0.00
				end
			end
			else
if math.random(1, 100) <= base_crit + crit_bonus then
local damage = base_dmg * 3.0 * dmg_bonus
					obj:punch(self.object, 1.0, {
						full_punch_interval = 1.0,
						damage_groups= {fleshy = damage},
					}, nil)
					minetest.sound_play("crit", {pos = self.lastpos, gain = 0.8})
		local entpos ={x=self.object:getpos().x, y=1+self.object:getpos().y, z=self.object:getpos().z} 
	minetest.add_particle({
		pos = entpos,
		velocity = 0,
          acceleration = {x=0, y=5, z=0},
		expirationtime = 0.75,
		size = 12,
		collisiondetection = false,
		vertical = false,
		texture = "testventure_crit.png",
		glow = 30,
	})
			if math.random(1, 3) == 1 then
			self.object:remove()
			end
			self.timer = 0.00
				else
local damage = base_dmg  * dmg_bonus
				obj:punch(self.object, 1.0, {
					full_punch_interval = 1.0,
					damage_groups= {fleshy = damage},
				}, nil)
				minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
			if math.random(1, 3) == 1 then
			self.object:remove()
			end
				self.timer = 0.00
				end
			end
		local tiem = 0.00
		if self.timer >= 0.02 + tiem then
	minetest.add_particle({
		pos = pos,
		velocity = 0,
          acceleration = {x=math.random(-2.0,2.0), y=math.random(-2.0,2.0), z=math.random(-2.0,2.0)},
		expirationtime = 1.0,
		size = 15,
		collisiondetection = true,
		vertical = false,
		texture = "testventure_spark.png",
		glow = 30,
	})
		tiem = tiem + 0.2 
			end
		if self.timer >= 1.0 then
		self.object:remove()
			end
	if self.lastpos.x ~= nil then
		if minetest.registered_nodes[node.name].walkable then
			if not minetest.setting_getbool("creative_mode") then
			minetest.sound_play("default_dig_cracky", {pos = self.lastpos, gain = 0.8})
		end
		self.object:remove()
	end
	end
	self.lastpos= {x = pos.x, y = pos.y, z = pos.z}
end
end
end

minetest.register_entity("testventure:ft_flame_projectile", testventure_ft_flame_projectile)


--- flare gun

minetest.register_tool("testventure:flare_gun", {
		description = "" ..core.colorize("#00eaff"," Flare gun\n")..core.colorize("#ffffff", "Shoots flares to provide light"),
	range = 0,
	wield_scale = {x=1.0,y=1.0,z=1.0},
	inventory_image = "testventure_flare_gun.png",
	on_use = function(itemstack, user, pointed_thing)
 meta = user:get_meta()
 c_down = meta:get_int("cooldown") or 0
		if c_down >= 200 then
		meta:set_int("cooldown", 0)
		local inv = user:get_inventory()
		if inv:contains_item("main", "testventure:flare") then
		inv:remove_item("main", "testventure:flare")
		timer = 0
		local pos = user:getpos()
		local dir = user:get_look_dir()
		local yaw = user:get_look_yaw()
		if pos and dir and yaw then
			pos.y = pos.y + 1.6
			local obj = minetest.add_entity(pos, "testventure:flare_projectile")
			if obj then
				obj:setyaw(yaw + math.pi)
				minetest.sound_play("testventure_weak_gun", {object=obj})
				obj:setvelocity({x=dir.x * 15, y=dir.y * 15, z=dir.z * 15})
				obj:setacceleration({x=0, y=-1.5, z=0})
			local ent = obj:get_luaentity()
			if ent then
			ent.player = ent.player or user
			end
			end
		end
		end
	end
	end,
})


